import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    // If id is provided, return a single playbook (used by duplicate action)
    if (id) {
      const playbook = await db.playbook.findUnique({ where: { id } });
      if (!playbook) return NextResponse.json({ error: 'Playbook not found' }, { status: 404 });
      return NextResponse.json(playbook);
    }
    const playbooks = await db.playbook.findMany({ orderBy: { updatedAt: 'desc' } });
    return NextResponse.json(playbooks);
  } catch (error) {
    console.error('Playbooks GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch playbooks' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const playbook = await db.playbook.create({
      data: {
        name: body.name || 'New Playbook',
        description: body.description || '',
        category: body.category || 'incident_response',
        steps: JSON.stringify(body.steps || []),
        triggers: JSON.stringify(body.triggers || []),
        status: body.status || 'active',
        tags: JSON.stringify(body.tags || []),
        workflowId: body.workflowId || null,
      }
    });
    return NextResponse.json(playbook, { status: 201 });
  } catch (error) {
    console.error('Playbook POST error:', error);
    return NextResponse.json({ error: 'Failed to create playbook' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });

    const updateData: Record<string, unknown> = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.description !== undefined) updateData.description = data.description;
    if (data.category !== undefined) updateData.category = data.category;
    if (data.steps !== undefined) updateData.steps = JSON.stringify(data.steps);
    if (data.triggers !== undefined) updateData.triggers = JSON.stringify(data.triggers);
    if (data.status !== undefined) updateData.status = data.status;
    if (data.tags !== undefined) updateData.tags = JSON.stringify(data.tags);
    if (data.workflowId !== undefined) updateData.workflowId = data.workflowId || null;

    const playbook = await db.playbook.update({ where: { id }, data: updateData });
    return NextResponse.json(playbook);
  } catch (error) {
    console.error('Playbook PUT error:', error);
    return NextResponse.json({ error: 'Failed to update playbook' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
    await db.playbook.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Playbook DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete playbook' }, { status: 500 });
  }
}
