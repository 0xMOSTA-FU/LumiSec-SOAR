// Workflow execution API
//
// SECURITY FIX (AUDIT-2 finding #1 — CRITICAL):
// Previously this route had ZERO authentication. Anyone with network access
// could execute ANY workflow (triggering outbound HTTP calls to Slack,
// VirusTotal, firewalls, email) and list all execution logs across all
// tenants — exposing trigger payloads, secrets in logs, and integration
// responses. This was the #1 critical finding.
//
// Now enforces:
//   1. extractAuthContext() — must be authenticated (no anonymous)
//   2. requirePermission(WORKFLOW_EXECUTE) for POST, WORKFLOW_READ for GET
//   3. tenantId scoping on GET (superadmin sees all)
//   4. Workflow must belong to caller's tenant (or caller is superadmin)
//   5. Per-caller rate limit (prevent workflow-execution DoS)
//   6. Zod input validation
//   7. Audit log entry on every execution

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { runWorkflow } from '@/lib/executors/engine';
import { forwardSoarEvent, isExternalBackendEnabled } from '@/lib/external-api';
import {
  extractAuthContext,
  requirePermission,
  PERMISSIONS,
  AuthenticationError,
  AuthorizationError,
} from '@/lib/auth';
import { writeAudit } from '@/lib/audit';
import { rateLimit, rateLimitResponse } from '@/lib/rate-limit';
import { recordWorkflowStart } from '@/lib/soar/observability/metrics';
import { logger } from '@/lib/logger';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ExecuteSchema = z.object({
  workflowId: z.string().min(1),
  trigger: z.record(z.string(), z.unknown()).optional().default({}),
});

export async function POST(request: NextRequest) {
  try {
    const ctx = await extractAuthContext(request);
    if (ctx.authMethod === 'anonymous') {
      throw new AuthenticationError('Authentication required');
    }
    requirePermission(ctx, PERMISSIONS.WORKFLOW_EXECUTE);

    // Per-caller rate limit — workflow execution is expensive.
    const rl = rateLimit(ctx.userId || ctx.actorIp || 'anon', 'workflow:execute');
    const rlResp = rateLimitResponse(rl);
    if (rlResp) return rlResp;

    const body = await request.json();
    const parsed = ExecuteSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Validation failed', details: parsed.error.flatten() },
        { status: 400 },
      );
    }
    const { workflowId, trigger } = parsed.data;

    // Tenant ownership check: the workflow must belong to the caller's tenant.
    // Superadmin (tenantId=null) can execute any workflow.
    const workflow = await db.workflow.findUnique({ where: { id: workflowId } });
    if (!workflow) {
      return NextResponse.json({ error: 'Workflow not found' }, { status: 404 });
    }
    if (ctx.tenantId && workflow.tenantId && workflow.tenantId !== ctx.tenantId) {
      return NextResponse.json({ error: 'Workflow not found' }, { status: 404 });
    }
    if (workflow.status !== 'active') {
      return NextResponse.json(
        { error: `Workflow is not active (status=${workflow.status}). Activate it first.` },
        { status: 409 },
      );
    }

    // Create execution record immediately
    const execution = await db.workflowExecution.create({
      data: {
        workflowId,
        tenantId: ctx.tenantId || workflow.tenantId || null,
        status: 'running',
        triggerType: 'api',
        trigger: JSON.stringify(trigger || {}),
        result: JSON.stringify({}),
        startedBy: ctx.userId || ctx.email || ctx.actorIp || 'unknown',
        requestId: ctx.requestId,
        logs: JSON.stringify([
          { time: new Date().toISOString(), message: 'Workflow execution started', level: 'info' },
        ]),
      },
    });

    // Record metric
    recordWorkflowStart(workflowId, ctx.tenantId || 'default');

    // Audit log
    await writeAudit(ctx, {
      action: 'workflow.execute',
      resource: 'workflow',
      resourceId: workflowId,
      description: `Executed workflow "${workflow.name}" (execution ${execution.id})`,
      metadata: { executionId: execution.id, trigger },
    });

    // Run the real engine in the background (do not await full completion)
    // but await long enough to capture initial logs / first node result
    runWorkflow({
      executionId: execution.id,
      workflowId,
      triggerPayload: trigger || {},
      tenantId: ctx.tenantId || workflow.tenantId,
      startedBy: ctx.userId || ctx.email,
      requestId: ctx.requestId,
    }).catch(e => logger.error({ err: e, executionId: execution.id, workflowId }, 'runWorkflow error'));

    // Forward SOAR event to the external backend (best-effort, non-blocking)
    if (isExternalBackendEnabled()) {
      forwardSoarEvent({
        type: 'workflow_executed',
        payload: { executionId: execution.id, workflowId, trigger },
        ts: new Date().toISOString(),
      }).catch(() => {/* swallow — external backend is best-effort */});
    }

    // Small delay so initial logs get persisted before we respond
    await new Promise(r => setTimeout(r, 800));

    return NextResponse.json(
      { ...execution, message: 'Execution started - poll GET for live logs' },
      { status: 201 },
    );
  } catch (error) {
    if (error instanceof AuthenticationError) {
      return NextResponse.json({ error: error.message }, { status: 401 });
    }
    if (error instanceof AuthorizationError) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    logger.error({ err: error }, 'Execution POST error');
    return NextResponse.json({ error: 'Failed to create execution' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const ctx = await extractAuthContext(req);
    if (ctx.authMethod === 'anonymous') {
      throw new AuthenticationError('Authentication required');
    }
    requirePermission(ctx, PERMISSIONS.WORKFLOW_READ);

    // Scope to caller's tenant. Superadmin (tenantId=null) sees all.
    const where = ctx.tenantId ? { tenantId: ctx.tenantId } : {};
    const executions = await db.workflowExecution.findMany({
      where,
      orderBy: { startedAt: 'desc' },
      take: 50,
      include: { workflow: { select: { name: true } } },
    });
    return NextResponse.json(executions);
  } catch (error) {
    if (error instanceof AuthenticationError) {
      return NextResponse.json({ error: error.message }, { status: 401 });
    }
    if (error instanceof AuthorizationError) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    logger.error({ err: error }, 'Executions GET error');
    return NextResponse.json({ error: 'Failed to fetch executions' }, { status: 500 });
  }
}
