// POST /api/seed
// Seeds the database with demo data (integrations, workflows, cases, alerts).
// Use ?force=1 to wipe and re-seed (preserves integrations with real API keys
// unless force=1 is used).
//
// SECURITY FIX (AUDIT-2 finding #1 — CRITICAL):
// Previously this route had ZERO authentication. Anyone with network access
// could trigger a re-seed — wiping cases/alerts/workflows and (with force=1)
// destroying real integration configs. This was both a data-loss vector and
// a DoS vector (the seed route is expensive).
//
// Now enforces:
//   1. extractAuthContext() — must be authenticated
//   2. requirePermission(USER_WRITE) — admin+ only (superadmin in prod)
//   3. In production (NODE_ENV=production), seed is HARD-DISABLED regardless
//      of permissions — demo data must never be seeded into a prod tenant.
//   4. Audit log entry on every seed operation
//   5. Per-caller rate limit (one seed per minute per caller)

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { encrypt, decrypt } from '@/lib/crypto';
import {
  SYSTEM_ROLES,
  PERMISSIONS,
  ROLE_PERMISSIONS,
  AuthenticationError,
  AuthorizationError,
  extractAuthContext,
  requirePermission,
} from '@/lib/auth';
import { writeAudit } from '@/lib/audit';
import { rateLimit, rateLimitResponse } from '@/lib/rate-limit';
import { logger } from '@/lib/logger';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    // PRODUCTION HARD-KILL: never allow seeding in production environments.
    // This is a defense-in-depth measure — even if an admin's credentials
    // are compromised, demo data cannot be injected into prod.
    if (process.env.NODE_ENV === 'production' && process.env.SOAR_ALLOW_SEED_IN_PROD !== '1') {
      return NextResponse.json(
        { error: 'Seed endpoint is disabled in production. Set SOAR_ALLOW_SEED_IN_PROD=1 to override (NOT RECOMMENDED).' },
        { status: 403 },
      );
    }

    const ctx = await extractAuthContext(req);
    if (ctx.authMethod === 'anonymous') {
      throw new AuthenticationError('Authentication required');
    }
    requirePermission(ctx, PERMISSIONS.USER_WRITE);

    // Rate limit: 1 seed per minute per caller (seed is expensive)
    const rl = rateLimit(ctx.userId || ctx.actorIp || 'anon', 'integrations:test');
    const rlResp = rateLimitResponse(rl);
    if (rlResp) return rlResp;

    // Allow caller to force re-seed via ?force=1 (used by Settings → Reset Demo Data)
    const url = new URL(req.url);
    const force = url.searchParams.get('force') === '1';

    // Smart seed: if integrations already exist AND have real configs (encrypted
    // JSON with non-empty values), DO NOT wipe them. The user has invested real
    // API keys into them and we must preserve that. The Settings page can
    // override with ?force=1 to explicitly re-seed demo data.
    const existingIntegrations = await db.integration.findMany({ select: { id: true, config: true, status: true } });
    const hasRealConfigs = existingIntegrations.some(i => {
      if (!i.config || i.config.length < 60) return false;
      // Decrypt and check if any field has a non-empty value
      try {
        const dec = decrypt<Record<string, unknown>>(i.config);
        if (!dec || typeof dec !== 'object') return false;
        return Object.values(dec).some(v => typeof v === 'string' && v.length > 0);
      } catch { return false; }
    });

    // Also check if there are any cases/workflows (means seed was already run)
    const existingCases = await db.case.count();
    const existingWorkflows = await db.workflow.count();

    // Idempotency: if everything's already seeded, just return success.
    // Skip only if NOT forced AND we have real configs to preserve.
    if (!force && existingIntegrations.length > 0 && existingCases > 0 && existingWorkflows > 0 && hasRealConfigs) {
      return NextResponse.json({
        success: true,
        skipped: true,
        reason: 'Already seeded with real config — preserving user data. Use ?force=1 to reset.',
        integrations: existingIntegrations.length,
        workflows: existingWorkflows,
        cases: existingCases,
      });
    }

    // Clean existing data first to ensure fresh seed with subtypes
    await db.workflowExecution.deleteMany();
    await db.workflow.deleteMany();
    await db.case.deleteMany();
    await db.integration.deleteMany();
    await db.playbook.deleteMany();
    await db.alert.deleteMany();
    await db.auditLog.deleteMany();
    await db.approvalStep.deleteMany();
    await db.approval.deleteMany();
    await db.evidence.deleteMany();
    await db.caseAttackPattern.deleteMany();
    await db.alertAttackPattern.deleteMany();
    await db.attackPattern.deleteMany();
    await db.rolePermission.deleteMany();
    await db.userRole.deleteMany();
    await db.permission.deleteMany();
    await db.role.deleteMany();
    await db.apiKey.deleteMany();
    await db.user.deleteMany();
    await db.tenant.deleteMany();

    // ========== 1. TENANT ==========
    const tenant = await db.tenant.upsert({
      where: { slug: 'default' },
      update: {},
      create: { id: 'tnt-default', name: 'Default Organization', slug: 'default', status: 'active' },
    });

    // ========== 2. ROLES & PERMISSIONS ==========
    const permissions = await Promise.all(
      Object.values(PERMISSIONS).map(name =>
        db.permission.upsert({
          where: { name },
          update: {},
          create: {
            id: `perm-${name.replace(/[:.]/g, '-')}`,
            name,
            resource: name.split(':')[0],
            action: name.split(':')[1] || '',
          },
        })
      )
    );

    const roles: Record<string, any> = {};
    for (const [roleName, perms] of Object.entries(ROLE_PERMISSIONS)) {
      const role = await db.role.upsert({
        where: { name: roleName },
        update: {},
        create: {
          id: `role-${roleName}`,
          name: roleName,
          description: `System role: ${roleName}`,
          isSystem: true,
        },
      });
      roles[roleName] = role;
      for (const permName of perms) {
        const perm = permissions.find(p => p.name === permName);
        if (perm) {
          await db.rolePermission.upsert({
            where: { roleId_permissionId: { roleId: role.id, permissionId: perm.id } },
            update: {},
            create: { roleId: role.id, permissionId: perm.id, conditions: '{}' },
          });
        }
      }
    }

    // ========== 3. DEFAULT ADMIN USER ==========
    // Password: "admin123" (bcrypt hash) — CHANGE IMMEDIATELY in production.
    // In production, this user is created via CLI: `npm run create-admin -- --email=... --password=...`
    const bcrypt = await import('bcryptjs');
    const passwordHash = await bcrypt.hash('admin123', 12);
    const adminUser = await db.user.upsert({
      where: { email: 'admin@soar.local' },
      update: {},
      create: {
        id: 'user-admin',
        tenantId: tenant.id,
        email: 'admin@soar.local',
        username: 'admin',
        fullName: 'SOAR Administrator',
        passwordHash,
        status: 'active',
      },
    });
    await db.userRole.upsert({
      where: { userId_roleId: { userId: adminUser.id, roleId: roles[SYSTEM_ROLES.SUPERADMIN].id } },
      update: {},
      create: { userId: adminUser.id, roleId: roles[SYSTEM_ROLES.SUPERADMIN].id, assignedBy: 'system' },
    });

    // Analyst user (read-only mostly)
    const analystHash = await bcrypt.hash('analyst123', 12);
    const analystUser = await db.user.upsert({
      where: { email: 'analyst@soar.local' },
      update: {},
      create: {
        id: 'user-analyst',
        tenantId: tenant.id,
        email: 'analyst@soar.local',
        username: 'analyst',
        fullName: 'SOC Analyst',
        passwordHash: analystHash,
        status: 'active',
      },
    });
    await db.userRole.upsert({
      where: { userId_roleId: { userId: analystUser.id, roleId: roles[SYSTEM_ROLES.ANALYST].id } },
      update: {},
      create: { userId: analystUser.id, roleId: roles[SYSTEM_ROLES.ANALYST].id, assignedBy: 'system' },
    });

    // ========== 4. MITRE ATT&CK (top 60 techniques across all 14 tactics) ==========
    const attackPatterns = [
      // Reconnaissance
      ['T1595', 'Active Scanning', 'reconnaissance', 'Adversaries may execute active reconnaissance scans to gather information about hosts, services, and vulnerabilities.'],
      ['T1592', 'Gather Victim Host Information', 'reconnaissance', 'Adversaries may gather information about the victim host that can be used during targeting.'],
      ['T1589', 'Gather Victim Identity Information', 'reconnaissance', 'Adversaries may gather information about the victim identity that can be used during targeting.'],
      // Resource Development
      ['T1583', 'Acquire Infrastructure', 'resource-development', 'Adversaries may buy, lease, or rent infrastructure that can be used during targeting.'],
      ['T1587', 'Develop Capabilities', 'resource-development', 'Adversaries may build capabilities that can be used during targeting.'],
      ['T1588', 'Obtain Capabilities', 'resource-development', 'Adversaries may buy, steal, or download capabilities that can be used during targeting.'],
      // Initial Access
      ['T1078', 'Valid Accounts', 'initial-access', 'Adversaries may use credentials of existing accounts to gain initial access.'],
      ['T1566', 'Phishing', 'initial-access', 'Adversaries may send phishing messages to gain access to victim systems.'],
      ['T1190', 'Exploit Public-Facing Application', 'initial-access', 'Adversaries may attempt to exploit a weakness in an Internet-facing host or system.'],
      ['T1133', 'External Remote Services', 'initial-access', 'Adversaries may use legitimate external remote services to initially access and/or persist within a network.'],
      ['T1077', 'Windows Admin Shares', 'lateral-movement', 'Adversaries may use Windows Admin Shares to access files and execute commands.'],
      // Execution
      ['T1059', 'Command and Scripting Interpreter', 'execution', 'Adversaries may abuse command and script interpreters to execute commands.'],
      ['T1106', 'Native API', 'execution', 'Adversaries may directly interact with the native OS API to execute behaviors.'],
      ['T1053', 'Scheduled Task/Job', 'execution', 'Adversaries may abuse task scheduling utilities to facilitate initial or recurring execution.'],
      ['T1204', 'User Execution', 'execution', 'Adversaries may rely on specific user actions to gain execution.'],
      // Persistence
      ['T1098', 'Account Manipulation', 'persistence', 'Adversaries may manipulate accounts to maintain or elevate access.'],
      ['T1136', 'Create Account', 'persistence', 'Adversaries may create an account to maintain access to victim systems.'],
      ['T1543', 'Create or Modify System Process', 'persistence', 'Adversaries may create or modify system-level processes to repeatedly execute malicious payloads.'],
      ['T1547', 'Boot or Logon Autostart Execution', 'persistence', 'Adversaries may configure system settings to automatically execute a program during boot.'],
      // Privilege Escalation
      ['T1068', 'Exploitation for Privilege Escalation', 'privilege-escalation', 'Adversaries may exploit software vulnerabilities to escalate privileges.'],
      ['T1078', 'Valid Accounts', 'privilege-escalation', 'Adversaries may use stolen credentials to escalate privileges.'], // dup ok
      ['T1134', 'Access Token Manipulation', 'privilege-escalation', 'Adversaries may modify access tokens to operate under escalated privileges.'],
      // Defense Evasion
      ['T1027', 'Obfuscated Files or Information', 'defense-evasion', 'Adversaries may attempt to make an executable or file difficult to discover or analyze.'],
      ['T1036', 'Masquerading', 'defense-evasion', 'Adversaries may manipulate features of their artifacts to make them appear legitimate.'],
      ['T1562', 'Impair Defenses', 'defense-evasion', 'Adversaries may maliciously modify components of a victim environment to hinder or disable defensive mechanisms.'],
      ['T1140', 'Deobfuscate/Decode Files or Information', 'defense-evasion', 'Adversaries may use unobfuscation/decoding to make files or information readable.'],
      ['T1112', 'Modify Registry', 'defense-evasion', 'Adversaries may interact with the Windows Registry to hide configuration information.'],
      // Credential Access
      ['T1110', 'Brute Force', 'credential-access', 'Adversaries may use brute force techniques to attempt access to accounts when passwords are unknown.'],
      ['T1555', 'Credentials from Password Stores', 'credential-access', 'Adversaries may search for common password storage locations to obtain user credentials.'],
      ['T1056', 'Input Capture', 'credential-access', 'Adversaries may log user keystrokes to intercept credentials as they are entered.'],
      ['T1003', 'OS Credential Dumping', 'credential-access', 'Adversaries may attempt to dump credentials to obtain account username and password.'],
      // Discovery
      ['T1087', 'Account Discovery', 'discovery', 'Adversaries may attempt to get a listing of accounts on a system or within an environment.'],
      ['T1018', 'Remote System Discovery', 'discovery', 'Adversaries may attempt to get a listing of other systems by IP address, hostname, or other logical identifier.'],
      ['T1083', 'File and Directory Discovery', 'discovery', 'Adversaries may enumerate files and directories or search for specific file locations.'],
      ['T1046', 'Network Service Discovery', 'discovery', 'Adversaries may attempt to get a listing of services running on remote hosts.'],
      // Lateral Movement
      ['T1021', 'Remote Services', 'lateral-movement', 'Adversaries may use valid credentials to directly control a remote system.'],
      ['T1072', 'Software Deployment Tools', 'lateral-movement', 'Adversaries may gain access to and use third-party software suites installed within an enterprise network.'],
      ['T1550', 'Use Alternate Authentication Material', 'lateral-movement', 'Adversaries may use alternate authentication material to move laterally.'],
      // Collection
      ['T1560', 'Archive Collected Data', 'collection', 'Adversaries may archive collected data in a format that can be exfiltrated.'],
      ['T1005', 'Data from Local System', 'collection', 'Adversaries may search local system sources to find and obtain files of interest.'],
      ['T1213', 'Data from Information Repositories', 'collection', 'Adversaries may access data from information repositories.'],
      // Command and Control
      ['T1071', 'Application Layer Protocol', 'command-and-control', 'Adversaries may communicate using OSI application layer protocols to avoid detection.'],
      ['T1573', 'Encrypted Channel', 'command-and-control', 'Adversaries may use encryption to hide C2 traffic.'],
      ['T1104', 'Multi-Stage Channels', 'command-and-control', 'Adversaries may create multiple stages for command and control.'],
      ['T1090', 'Proxy', 'command-and-control', 'Adversaries may route C2 traffic through a proxy to hide their origin.'],
      // Exfiltration
      ['T1041', 'Exfiltration Over C2 Channel', 'exfiltration', 'Adversaries may steal data by exfiltrating it over an existing C2 channel.'],
      ['T1567', 'Exfiltration Over Web Service', 'exfiltration', 'Adversaries may use web services to exfiltrate data.'],
      ['T1052', 'Exfiltration Over Physical Medium', 'exfiltration', 'Adversaries may exfiltrate data via physical media.'],
      ['T1029', 'Scheduled Transfer', 'exfiltration', 'Adversaries may schedule data exfiltration to occur at specific times.'],
      // Impact
      ['T1486', 'Data Encrypted for Impact', 'impact', 'Adversaries may encrypt data on target systems to interrupt availability.'],
      ['T1485', 'Data Destruction', 'impact', 'Adversaries may destroy data to interrupt availability.'],
      ['T1489', 'Service Stop', 'impact', 'Adversaries may stop or disable services to render them unavailable.'],
      ['T1490', 'Inhibit System Recovery', 'impact', 'Adversaries may delete or remove built-in OS data to inhibit system recovery.'],
      ['T1561', 'Disk Wipe', 'impact', 'Adversaries may wipe or reformat disks to interrupt availability.'],
      ['T1498', 'Network Denial of Service', 'impact', 'Adversaries may attempt to cause a denial of service by flooding a target with network traffic.'],
    ];
    await Promise.all(attackPatterns.map(([tid, name, tactic, desc]) =>
      db.attackPattern.upsert({
        where: { techniqueId: tid },
        update: {},
        create: {
          techniqueId: tid,
          name,
          tactic,
          description: desc,
          url: `https://attack.mitre.org/techniques/${tid.replace('.', '/')}`,
        },
      })
    ));

    // Seed Integrations — 22 real connector types matching the engine dispatch
    // type field MUST match what the engine looks up via ctx.getIntegration(type)
    const integrations = await Promise.all([
      // Threat Intel
      db.integration.upsert({ where: { id: 'int-vt' }, update: {}, create: { id: 'int-vt', name: 'VirusTotal', type: 'virustotal', category: 'security', description: 'Real-time malware & IOC reputation. Get a FREE API key at virustotal.com/gui/my-apikey', config: encrypt({ api_key: '' }), status: 'disconnected', icon: 'bug' }}),
      db.integration.upsert({ where: { id: 'int-abuseipdb' }, update: {}, create: { id: 'int-abuseipdb', name: 'AbuseIPDB', type: 'abuseipdb', category: 'security', description: 'IP abuse confidence score. Get a FREE API key at abuseipdb.com/account/api', config: encrypt({ api_key: '' }), status: 'disconnected', icon: 'bug' }}),
      db.integration.upsert({ where: { id: 'int-ipinfo' }, update: {}, create: { id: 'int-ipinfo', name: 'IPInfo', type: 'ipinfo', category: 'security', description: 'IP geolocation & ASN. FREE - no API key required (50k/month)', config: encrypt({ token: '' }), status: 'connected', icon: 'globe' }}),
      db.integration.upsert({ where: { id: 'int-otx' }, update: {}, create: { id: 'int-otx', name: 'AlienVault OTX', type: 'otx', category: 'security', description: 'Open Threat Exchange pulses. FREE - register at otx.alienvault.com', config: encrypt({ api_key: '' }), status: 'connected', icon: 'radar' }}),
      db.integration.upsert({ where: { id: 'int-misp' }, update: {}, create: { id: 'int-misp', name: 'MISP', type: 'misp', category: 'security', description: 'Open-source threat intelligence platform. Self-hosted.', config: encrypt({ url: '', api_key: '' }), status: 'disconnected', icon: 'database' }}),
      db.integration.upsert({ where: { id: 'int-opencti' }, update: {}, create: { id: 'int-opencti', name: 'OpenCTI', type: 'opencti', category: 'security', description: 'Open-source CTI platform with GraphQL API. Self-hosted.', config: encrypt({ url: '', api_key: '' }), status: 'disconnected', icon: 'database' }}),
      // SIEM
      db.integration.upsert({ where: { id: 'int-splunk' }, update: {}, create: { id: 'int-splunk', name: 'Splunk', type: 'splunk', category: 'security', description: 'Enterprise SIEM - run SPL searches via REST API', config: encrypt({ host: '', port: 8089, username: '', password: '' }), status: 'disconnected', icon: 'radar' }}),
      db.integration.upsert({ where: { id: 'int-elastic' }, update: {}, create: { id: 'int-elastic', name: 'Elasticsearch', type: 'elastic', category: 'security', description: 'Search & analytics engine - query logs via _search API', config: encrypt({ url: '', username: '', password: '', api_key: '' }), status: 'disconnected', icon: 'database' }}),
      db.integration.upsert({ where: { id: 'int-wazuh' }, update: {}, create: { id: 'int-wazuh', name: 'Wazuh', type: 'wazuh', category: 'security', description: 'Open-source SIEM & XDR. Self-hosted manager.', config: encrypt({ host: '', port: 55000, username: 'wazuh', password: '' }), status: 'disconnected', icon: 'radar' }}),
      // ITSM / Ticketing
      db.integration.upsert({ where: { id: 'int-jira' }, update: {}, create: { id: 'int-jira', name: 'Jira', type: 'jira', category: 'communication', description: 'Create issues + comments via Jira Cloud REST API', config: encrypt({ host: '', email: '', api_token: '' }), status: 'disconnected', icon: 'ticket' }}),
      db.integration.upsert({ where: { id: 'int-servicenow' }, update: {}, create: { id: 'int-servicenow', name: 'ServiceNow', type: 'servicenow', category: 'communication', description: 'Create/query incidents via ServiceNow Table API', config: encrypt({ host: '', username: '', password: '' }), status: 'disconnected', icon: 'ticket' }}),
      db.integration.upsert({ where: { id: 'int-pagerduty' }, update: {}, create: { id: 'int-pagerduty', name: 'PagerDuty', type: 'pagerduty', category: 'communication', description: 'Trigger incidents + on-call management via REST API', config: encrypt({ api_key: '', routing_key: '', email: '' }), status: 'disconnected', icon: 'bell' }}),
      db.integration.upsert({ where: { id: 'int-thehive' }, update: {}, create: { id: 'int-thehive', name: 'TheHive', type: 'thehive', category: 'security', description: 'Open-source incident response platform. Self-hosted.', config: encrypt({ url: '', api_key: '' }), status: 'disconnected', icon: 'shield' }}),
      db.integration.upsert({ where: { id: 'int-defectdojo' }, update: {}, create: { id: 'int-defectdojo', name: 'DefectDojo', type: 'defectdojo', category: 'security', description: 'Open-source vulnerability management. Self-hosted.', config: encrypt({ url: '', api_key: '' }), status: 'disconnected', icon: 'bug' }}),
      // Cloud / Identity
      db.integration.upsert({ where: { id: 'int-msgraph' }, update: {}, create: { id: 'int-msgraph', name: 'Microsoft Graph', type: 'msgraph', category: 'iam', description: 'Query users, alerts, sign-ins, send mail via Graph API', config: encrypt({ tenant_id: '', client_id: '', client_secret: '' }), status: 'disconnected', icon: 'users' }}),
      db.integration.upsert({ where: { id: 'int-do' }, update: {}, create: { id: 'int-do', name: 'DigitalOcean', type: 'digitalocean', category: 'cloud', description: 'Manage droplets + firewall rules via DigitalOcean API v2', config: encrypt({ api_token: '' }), status: 'disconnected', icon: 'cloud' }}),
      // Network / Firewall
      db.integration.upsert({ where: { id: 'int-fortigate' }, update: {}, create: { id: 'int-fortigate', name: 'FortiGate', type: 'fortigate', category: 'network', description: 'Block/unblock IPs via FortiOS REST API', config: encrypt({ host: '', port: 443, api_key: '', vdom: 'root' }), status: 'disconnected', icon: 'shield' }}),
      db.integration.upsert({ where: { id: 'int-opnsense' }, update: {}, create: { id: 'int-opnsense', name: 'OPNsense', type: 'opnsense', category: 'network', description: 'Open-source firewall - manage aliases via REST API', config: encrypt({ host: '', port: 443, api_key: '', api_secret: '' }), status: 'disconnected', icon: 'shield' }}),
      // EDR / IR
      db.integration.upsert({ where: { id: 'int-velociraptor' }, update: {}, create: { id: 'int-velociraptor', name: 'Velociraptor', type: 'velociraptor', category: 'endpoint', description: 'Open-source endpoint visibility + DFIR via VQL', config: encrypt({ url: '', api_key: '' }), status: 'disconnected', icon: 'monitor' }}),
      // Comms
      db.integration.upsert({ where: { id: 'int-slack' }, update: {}, create: { id: 'int-slack', name: 'Slack', type: 'slack', category: 'communication', description: 'Post alerts to channels. Set up webhook at api.slack.com/messaging/webhooks', config: encrypt({ webhook: '', channel: '#soc-alerts' }), status: 'disconnected', icon: 'message-circle' }}),
      db.integration.upsert({ where: { id: 'int-email' }, update: {}, create: { id: 'int-email', name: 'Email (SMTP)', type: 'email', category: 'communication', description: 'Send email alerts via SMTP. Works with Gmail App Passwords.', config: encrypt({ smtp_host: '', port: 587, username: '', password: '', from: '' }), status: 'disconnected', icon: 'mail' }}),
      // Generic HTTP + Webhook
      db.integration.upsert({ where: { id: 'int-webhook' }, update: {}, create: { id: 'int-webhook', name: 'Webhook (Generic)', type: 'webhook', category: 'security', description: 'Send HTTP webhooks to any URL with template resolution', config: encrypt({ url: '', auth_header: '' }), status: 'connected', icon: 'link' }}),
      db.integration.upsert({ where: { id: 'int-http' }, update: {}, create: { id: 'int-http', name: 'HTTP (Generic)', type: 'http', category: 'security', description: 'Generic HTTP executor - call any REST API', config: encrypt({ base_url: '', api_key: '' }), status: 'connected', icon: 'globe' }}),
    ]);

    // Seed Workflows
    const workflows = await Promise.all([
      db.workflow.upsert({ where: { id: 'wf-1' }, update: {}, create: { id: 'wf-1', name: 'Phishing Email Response', description: 'Automated response to phishing email alerts - uses REAL VirusTotal API', status: 'active', nodes: JSON.stringify([
        { id: 'n1', type: 'trigger', subtype: 'manual', position: { x: 50, y: 200 }, data: { label: 'Manual Trigger', config: { subtype: 'manual' } } },
        { id: 'n2', type: 'action', subtype: 'virustotal', position: { x: 300, y: 200 }, data: { label: 'VirusTotal Lookup', config: { subtype: 'virustotal', ioc_type: 'ip', ioc_value: '{{trigger.ip}}' } } },
        { id: 'n3', type: 'action', subtype: 'abuseipdb', position: { x: 550, y: 100 }, data: { label: 'AbuseIPDB Check', config: { subtype: 'abuseipdb', ip: '{{trigger.ip}}' } } },
        { id: 'n4', type: 'action', subtype: 'ipinfo', position: { x: 550, y: 300 }, data: { label: 'IPInfo Geolocate', config: { subtype: 'ipinfo', ip: '{{trigger.ip}}' } } },
        { id: 'n5', type: 'condition', subtype: 'if', position: { x: 800, y: 200 }, data: { label: 'Is Malicious?', config: { subtype: 'if', field: 'outputs.n2.virustotal.is_malicious', operator: '==', value: 'true' } } },
        { id: 'n6', type: 'action', subtype: 'create_case', position: { x: 1050, y: 100 }, data: { label: 'Create Case', config: { subtype: 'create_case', title: 'Phishing Incident - IP={{trigger.ip}}', severity: 'high' } } },
        { id: 'n7', type: 'action', subtype: 'slack', position: { x: 1050, y: 300 }, data: { label: 'Notify SOC', config: { subtype: 'slack', channel: '#soc-alerts', message: 'Malicious IP detected: {{trigger.ip}} (VT score={{outputs.n2.virustotal.score}}%)' } } },
        { id: 'n8', type: 'output', subtype: 'log', position: { x: 1300, y: 200 }, data: { label: 'Log Result', config: { subtype: 'log', message: 'Workflow completed for IP={{trigger.ip}}', level: 'info' } } },
      ]), edges: JSON.stringify([
        { id: 'e1', source: 'n1', target: 'n2' },
        { id: 'e2', source: 'n2', target: 'n3' }, { id: 'e3', source: 'n2', target: 'n4' },
        { id: 'e4', source: 'n3', target: 'n5' }, { id: 'e5', source: 'n4', target: 'n5' },
        { id: 'e6', source: 'n5', target: 'n6', label: 'Yes' }, { id: 'e7', source: 'n5', target: 'n7', label: 'Yes' },
        { id: 'e8', source: 'n5', target: 'n8', label: 'No' },
      ]), trigger: JSON.stringify({ type: 'manual' }), tags: JSON.stringify(['phishing', 'virustotal', 'real-api']) }}),
      db.workflow.upsert({ where: { id: 'wf-2' }, update: {}, create: { id: 'wf-2', name: 'Brute Force Detection', description: 'Detect and respond to brute force login attempts', status: 'active', nodes: JSON.stringify([
        { id: 'n1', type: 'trigger', subtype: 'schedule', position: { x: 50, y: 200 }, data: { label: 'Failed Logins', config: { subtype: 'schedule', interval: '5m', source: 'active_directory', threshold: 5 } } },
        { id: 'n2', type: 'action', subtype: 'api', position: { x: 300, y: 200 }, data: { label: 'Lock Account', config: { subtype: 'api', endpoint: '/ad/lock-account', method: 'POST' } } },
        { id: 'n3', type: 'action', subtype: 'block', position: { x: 550, y: 100 }, data: { label: 'Block IP', config: { subtype: 'block', type: 'ip', target: '0.0.0.0' } } },
        { id: 'n4', type: 'action', subtype: 'slack', position: { x: 550, y: 300 }, data: { label: 'Alert SOC', config: { subtype: 'slack', channel: '#soc', message: 'Brute force detected' } } },
      ]), edges: JSON.stringify([
        { id: 'e1', source: 'n1', target: 'n2' }, { id: 'e2', source: 'n2', target: 'n3' },
        { id: 'e3', source: 'n2', target: 'n4' },
      ]), trigger: JSON.stringify({ type: 'schedule', interval: '5m' }), tags: JSON.stringify(['brute-force', 'identity', 'active-directory']) }}),
      db.workflow.upsert({ where: { id: 'wf-3' }, update: {}, create: { id: 'wf-3', name: 'Malware Sandbox Analysis', description: 'Submit suspicious files for sandbox analysis', status: 'draft', nodes: JSON.stringify([
        { id: 'n1', type: 'trigger', subtype: 'manual', position: { x: 80, y: 250 }, data: { label: 'File Upload', config: { subtype: 'manual', source: 'edr' } } },
        { id: 'n2', type: 'action', subtype: 'http', position: { x: 380, y: 250 }, data: { label: 'Submit Sandbox', config: { subtype: 'http', method: 'POST', url: 'https://sandbox.local/api/submit' } } },
      ]), edges: JSON.stringify([{ id: 'e1', source: 'n1', target: 'n2' }]), trigger: JSON.stringify({ type: 'manual' }), tags: JSON.stringify(['malware', 'sandbox']) }}),
      db.workflow.upsert({ where: { id: 'wf-4' }, update: {}, create: { id: 'wf-4', name: 'Cloud Anomaly Detection', description: 'Detect anomalous cloud resource usage', status: 'active', nodes: JSON.stringify([
        { id: 'n1', type: 'trigger', subtype: 'webhook', position: { x: 50, y: 250 }, data: { label: 'CloudTrail Event', config: { subtype: 'webhook', method: 'POST', path: '/webhook/cloudtrail', source: 'aws_cloudtrail' } } },
        { id: 'n2', type: 'action', subtype: 'enrich', position: { x: 320, y: 250 }, data: { label: 'Analyze Pattern', config: { subtype: 'enrich', source: 'shodan', field: 'source_ip' } } },
        { id: 'n3', type: 'condition', subtype: 'if', position: { x: 590, y: 250 }, data: { label: 'Anomaly?', config: { subtype: 'if', field: 'anomaly_score', operator: '>', value: '0.8' } } },
        { id: 'n4', type: 'output', subtype: 'alert_out', position: { x: 860, y: 180 }, data: { label: 'Create Alert', config: { subtype: 'alert_out', title: 'Cloud Anomaly Detected', severity: 'high' } } },
        { id: 'n5', type: 'output', subtype: 'log', position: { x: 860, y: 350 }, data: { label: 'Log & Ignore', config: { subtype: 'log', message: 'Below threshold, logging only', level: 'info' } } },
      ]), edges: JSON.stringify([
        { id: 'e1', source: 'n1', target: 'n2' }, { id: 'e2', source: 'n2', target: 'n3' },
        { id: 'e3', source: 'n3', target: 'n4', label: 'Yes' }, { id: 'e4', source: 'n3', target: 'n5', label: 'No' },
      ]), trigger: JSON.stringify({ type: 'webhook', source: 'aws_cloudtrail' }), tags: JSON.stringify(['cloud', 'aws', 'anomaly']) }}),
      // NEW: Multi-integration workflow demonstrating 22 connectors
      db.workflow.upsert({ where: { id: 'wf-5' }, update: {}, create: { id: 'wf-5', name: 'Full Threat Intel Enrichment', description: 'Multi-source IOC enrichment: VirusTotal + AbuseIPDB + OTX + IPInfo → create case + Slack alert', status: 'active', nodes: JSON.stringify([
        { id: 'n1', type: 'trigger', subtype: 'manual', position: { x: 50, y: 250 }, data: { label: 'Manual Trigger', config: { subtype: 'manual' } } },
        { id: 'n2', type: 'action', subtype: 'virustotal', position: { x: 320, y: 80 }, data: { label: 'VirusTotal Lookup', config: { subtype: 'virustotal', ioc_type: 'ip', ioc_value: '{{trigger.ip}}' } } },
        { id: 'n3', type: 'action', subtype: 'abuseipdb', position: { x: 320, y: 200 }, data: { label: 'AbuseIPDB Check', config: { subtype: 'abuseipdb', ip: '{{trigger.ip}}' } } },
        { id: 'n4', type: 'action', subtype: 'otx', position: { x: 320, y: 320 }, data: { label: 'AlienVault OTX', config: { subtype: 'otx', action: 'lookup_indicator', ioc_type: 'ip', ioc_value: '{{trigger.ip}}' } } },
        { id: 'n5', type: 'action', subtype: 'ipinfo', position: { x: 320, y: 440 }, data: { label: 'IPInfo Geolocate', config: { subtype: 'ipinfo', ip: '{{trigger.ip}}' } } },
        { id: 'n6', type: 'condition', subtype: 'if', position: { x: 620, y: 250 }, data: { label: 'Malicious?', config: { subtype: 'if', field: 'outputs.n2.virustotal.is_malicious', operator: '==', value: 'true' } } },
        { id: 'n7', type: 'action', subtype: 'create_case', position: { x: 880, y: 150 }, data: { label: 'Create Case', config: { subtype: 'create_case', title: 'Threat Confirmed - {{trigger.ip}}', description: 'VT score={{outputs.n2.virustotal.score}}%, AbuseIPDB={{outputs.n3.abuseipdb.abuse_score}}%, OTX pulses={{outputs.n4.otx.pulse_count}}', severity: 'critical' } } },
        { id: 'n8', type: 'action', subtype: 'slack', position: { x: 880, y: 280 }, data: { label: 'Notify SOC Slack', config: { subtype: 'slack', channel: '#soc-alerts', message: '[ALERT] Malicious IP: {{trigger.ip}}\nVT: {{outputs.n2.virustotal.malicious}}/{{outputs.n2.virustotal.total}} engines\nAbuseIPDB score: {{outputs.n3.abuseipdb.abuse_score}}%\nGeo: {{outputs.n5.ipinfo.country}}, {{outputs.n5.ipinfo.org}}' } } },
        { id: 'n9', type: 'action', subtype: 'jira', position: { x: 880, y: 410 }, data: { label: 'Create Jira Issue', config: { subtype: 'jira', action: 'create_issue', project_key: 'SEC', summary: 'Threat: {{trigger.ip}} flagged by multi-source enrichment', description: 'VT score={{outputs.n2.virustotal.score}}%, see case for details', issue_type: 'Bug', priority: 'High' } } },
        { id: 'n10', type: 'output', subtype: 'log', position: { x: 1180, y: 250 }, data: { label: 'Log Result', config: { subtype: 'log', message: 'Enrichment completed for {{trigger.ip}}', level: 'info' } } },
      ]), edges: JSON.stringify([
        { id: 'e1', source: 'n1', target: 'n2' },
        { id: 'e2', source: 'n1', target: 'n3' },
        { id: 'e3', source: 'n1', target: 'n4' },
        { id: 'e4', source: 'n1', target: 'n5' },
        { id: 'e5', source: 'n2', target: 'n6' },
        { id: 'e6', source: 'n3', target: 'n6' },
        { id: 'e7', source: 'n4', target: 'n6' },
        { id: 'e8', source: 'n5', target: 'n6' },
        { id: 'e9', source: 'n6', target: 'n7', label: 'Yes' },
        { id: 'e10', source: 'n6', target: 'n8', label: 'Yes' },
        { id: 'e11', source: 'n6', target: 'n9', label: 'Yes' },
        { id: 'e12', source: 'n6', target: 'n10', label: 'No' },
      ]), trigger: JSON.stringify({ type: 'manual' }), tags: JSON.stringify(['multi-source', 'enrichment', 'virustotal', 'abuseipdb', 'otx', 'ipinfo', 'jira', 'slack']) }}),
      // NEW: Splunk + Velociraptor hunt workflow
      db.workflow.upsert({ where: { id: 'wf-6' }, update: {}, create: { id: 'wf-6', name: 'SIEM-Triggered Hunt', description: 'Splunk detects suspicious process → Velociraptor launches hunt across endpoints', status: 'draft', nodes: JSON.stringify([
        { id: 'n1', type: 'trigger', subtype: 'webhook', position: { x: 50, y: 250 }, data: { label: 'Splunk Alert Webhook', config: { subtype: 'webhook', method: 'POST', path: '/webhook/splunk' } } },
        { id: 'n2', type: 'action', subtype: 'splunk', position: { x: 320, y: 250 }, data: { label: 'Search Related Events', config: { subtype: 'splunk', action: 'search', search: 'search process_name="{{trigger.process}}" earliest=-24h latest=now', earliest: '-24h', latest: 'now' } } },
        { id: 'n3', type: 'action', subtype: 'velociraptor', position: { x: 620, y: 250 }, data: { label: 'Launch VR Hunt', config: { subtype: 'velociraptor', action: 'create_hunt', artifact: 'Windows.System.ProcessVads', description: 'Hunt for {{trigger.process}} across fleet' } } },
        { id: 'n4', type: 'action', subtype: 'thehive', position: { x: 920, y: 250 }, data: { label: 'Open TheHive Case', config: { subtype: 'thehive', action: 'create_case', title: 'Hunt: {{trigger.process}}', description: 'Splunk detected suspicious process, launched VR hunt', severity: 3 } } },
        { id: 'n5', type: 'output', subtype: 'log', position: { x: 1220, y: 250 }, data: { label: 'Log', config: { subtype: 'log', message: 'Hunt workflow completed', level: 'info' } } },
      ]), edges: JSON.stringify([
        { id: 'e1', source: 'n1', target: 'n2' },
        { id: 'e2', source: 'n2', target: 'n3' },
        { id: 'e3', source: 'n3', target: 'n4' },
        { id: 'e4', source: 'n4', target: 'n5' },
      ]), trigger: JSON.stringify({ type: 'webhook' }), tags: JSON.stringify(['splunk', 'velociraptor', 'thehive', 'hunt']) }}),
    ]);

    // Seed Cases
    const cases = await Promise.all([
      db.case.upsert({ where: { id: 'case-1' }, update: {}, create: { id: 'case-1', title: 'Phishing Campaign - Finance Dept', description: 'Targeted phishing campaign against finance department with fake invoice attachments', severity: 'critical', status: 'open', assigneeId: 'user-admin', tags: JSON.stringify(['phishing', 'finance', 'apt']), artifacts: JSON.stringify(['suspicious_email.eml', 'malware_sample.exe', 'ioc_list.json']), timeline: JSON.stringify([
        { time: '2026-06-15T08:00:00Z', event: 'First phishing email detected' },
        { time: '2026-06-15T08:15:00Z', event: 'IOCs extracted and submitted to VirusTotal' },
        { time: '2026-06-15T08:30:00Z', event: '3 additional emails found in quarantine' },
        { time: '2026-06-15T09:00:00Z', event: 'Sender domain blocked' },
      ]) }}),
      db.case.upsert({ where: { id: 'case-2' }, update: {}, create: { id: 'case-2', title: 'Brute Force Attack - VPN Gateway', description: 'Multiple failed login attempts detected from external IPs targeting VPN gateway', severity: 'high', status: 'investigating', assigneeId: 'user-analyst', tags: JSON.stringify(['brute-force', 'vpn', 'network']), artifacts: JSON.stringify(['vpn_logs.csv', 'blocked_ips.txt']), timeline: JSON.stringify([
        { time: '2026-06-14T22:00:00Z', event: 'Brute force attack detected' },
        { time: '2026-06-14T22:10:00Z', event: 'Source IPs identified' },
        { time: '2026-06-14T22:30:00Z', event: 'IPs blocked on firewall' },
      ]) }}),
      db.case.upsert({ where: { id: 'case-3' }, update: {}, create: { id: 'case-3', title: 'Data Exfiltration Suspected', description: 'Unusual outbound data transfer detected from internal server to external endpoint', severity: 'critical', status: 'open', assigneeId: 'user-admin', tags: JSON.stringify(['data-exfil', 'insider-threat']), artifacts: JSON.stringify(['netflow_data.pcap', 'dns_queries.log']), timeline: JSON.stringify([
        { time: '2026-06-14T18:00:00Z', event: 'Anomalous outbound traffic detected by SIEM' },
        { time: '2026-06-14T18:30:00Z', event: 'Destination IP traced to known C2 server' },
      ]) }}),
      db.case.upsert({ where: { id: 'case-4' }, update: {}, create: { id: 'case-4', title: 'Malware Detection - Workstation WKS-042', description: 'Malicious payload detected on workstation by EDR agent', severity: 'high', status: 'contained', assigneeId: 'user-admin', tags: JSON.stringify(['malware', 'endpoint']), artifacts: JSON.stringify(['malware_hash.sha256', 'process_tree.json']), timeline: JSON.stringify([
        { time: '2026-06-13T14:00:00Z', event: 'EDR alert triggered' },
        { time: '2026-06-13T14:10:00Z', event: 'Host isolated from network' },
        { time: '2026-06-13T14:30:00Z', event: 'Malware sample submitted to sandbox' },
        { time: '2026-06-13T16:00:00Z', event: 'Threat contained' },
      ]) }}),
      db.case.upsert({ where: { id: 'case-5' }, update: {}, create: { id: 'case-5', title: 'Suspicious Cloud API Activity', description: 'Unusual API calls from compromised IAM credentials in AWS', severity: 'medium', status: 'closed', assigneeId: 'user-analyst', tags: JSON.stringify(['cloud', 'aws', 'iam']), artifacts: JSON.stringify(['cloudtrail_logs.json', 'iam_policy.json']), timeline: JSON.stringify([
        { time: '2026-06-12T10:00:00Z', event: 'Anomalous API calls detected' },
        { time: '2026-06-12T10:30:00Z', event: 'IAM credentials rotated' },
        { time: '2026-06-12T11:00:00Z', event: 'Case resolved' },
      ]) }}),
    ]);

    // Seed Alerts
    const alerts = await Promise.all([
      db.alert.upsert({ where: { id: 'alert-1' }, update: {}, create: { id: 'alert-1', title: 'Phishing Email - Fake Invoice', description: 'Phishing email with malicious attachment detected', source: 'Email Gateway', severity: 'critical', status: 'new', assigneeId: undefined, caseId: 'case-1', raw: JSON.stringify({ sender: 'account@fake-invoice.com', subject: 'URGENT: Invoice #2847', attachment: 'invoice.exe' }) }}),
      db.alert.upsert({ where: { id: 'alert-2' }, update: {}, create: { id: 'alert-2', title: 'Multiple Failed Logins - 192.168.1.100', description: '25 failed login attempts in 5 minutes', source: 'Active Directory', severity: 'high', status: 'investigating', assigneeId: 'user-analyst', caseId: 'case-2', raw: JSON.stringify({ source_ip: '192.168.1.100', attempts: 25, timeframe: '5min' }) }}),
      db.alert.upsert({ where: { id: 'alert-3' }, update: {}, create: { id: 'alert-3', title: 'Outbound Data Transfer Anomaly', description: '2.3GB outbound transfer to unknown endpoint', source: 'Splunk SIEM', severity: 'critical', status: 'new', assigneeId: undefined, caseId: 'case-3', raw: JSON.stringify({ bytes: 2469606400, dest_ip: '45.33.32.156', protocol: 'HTTPS' }) }}),
      db.alert.upsert({ where: { id: 'alert-4' }, update: {}, create: { id: 'alert-4', title: 'Malware Detected - Trojan.GenericKD', description: 'EDR detected trojan on endpoint WKS-042', source: 'CrowdStrike EDR', severity: 'high', status: 'resolved', assigneeId: 'user-admin', caseId: 'case-4', raw: JSON.stringify({ hostname: 'WKS-042', malware: 'Trojan.GenericKD.46789234', hash: 'a1b2c3d4...' }) }}),
      db.alert.upsert({ where: { id: 'alert-5' }, update: {}, create: { id: 'alert-5', title: 'Suspicious AWS API - IAM User', description: 'IAM user invoked unusual API calls', source: 'AWS CloudTrail', severity: 'medium', status: 'resolved', assigneeId: 'user-analyst', caseId: 'case-5', raw: JSON.stringify({ user: 'svc-deploy', api: 'iam:CreateUser', region: 'us-east-1' }) }}),
      db.alert.upsert({ where: { id: 'alert-6' }, update: {}, create: { id: 'alert-6', title: 'Port Scan Detected', description: 'External IP scanning internal network ports', source: 'Palo Alto Firewall', severity: 'medium', status: 'new', assigneeId: undefined, caseId: null, raw: JSON.stringify({ source_ip: '203.0.113.42', ports_scanned: '1-1024', target: '10.0.0.0/24' }) }}),
      db.alert.upsert({ where: { id: 'alert-7' }, update: {}, create: { id: 'alert-7', title: 'DNS Tunneling Suspected', description: 'Unusual DNS query patterns indicating potential tunneling', source: 'Splunk SIEM', severity: 'high', status: 'new', assigneeId: undefined, caseId: null, raw: JSON.stringify({ domain: 'data.x7k9t2.evil.com', query_count: 1500, timeframe: '1h' }) }}),
      db.alert.upsert({ where: { id: 'alert-8' }, update: {}, create: { id: 'alert-8', title: 'Privilege Escalation Attempt', description: 'User attempted to escalate privileges on production server', source: 'Active Directory', severity: 'critical', status: 'new', assigneeId: 'user-admin', caseId: null, raw: JSON.stringify({ user: 'jsmith', target: 'PROD-SRV-01', action: 'runas /user:admin' }) }}),
    ]);

    // Seed Playbooks — each one linked to the workflow that actually
    // implements its automated steps. The "Run" button on the playbooks
    // page will execute the linked workflow via /api/playbooks/[id]/execute.
    const playbooks = await Promise.all([
      db.playbook.upsert({ where: { id: 'pb-1' }, update: {}, create: { id: 'pb-1', name: 'Phishing Incident Response', description: 'Comprehensive playbook for handling phishing incidents from detection to resolution', category: 'incident_response', workflowId: 'wf-1', steps: JSON.stringify([
        { order: 1, name: 'Detect & Triage', action: 'Analyze email headers, URLs, and attachments', automation: 'auto' },
        { order: 2, name: 'Extract IOCs', action: 'Extract indicators of compromise from email', automation: 'auto' },
        { order: 3, name: 'Enrich & Correlate', action: 'Check IOCs against threat intelligence feeds (VirusTotal + AbuseIPDB + IPInfo)', automation: 'auto' },
        { order: 4, name: 'Contain', action: 'Block sender, quarantine email, block URLs', automation: 'auto' },
        { order: 5, name: 'Investigate', action: 'Identify affected users and systems', automation: 'manual' },
        { order: 6, name: 'Remediate', action: 'Reset passwords, clean endpoints', automation: 'semi-auto' },
        { order: 7, name: 'Report & Close', action: 'Document findings and close case', automation: 'manual' },
      ]), triggers: JSON.stringify([{ type: 'alert', condition: 'category = phishing' }, { type: 'manual' }]), status: 'active', tags: JSON.stringify(['phishing', 'email', 'response']) }}),
      db.playbook.upsert({ where: { id: 'pb-2' }, update: {}, create: { id: 'pb-2', name: 'Brute Force Response', description: 'Handle brute force login attempts with automated containment', category: 'incident_response', workflowId: 'wf-2', steps: JSON.stringify([
        { order: 1, name: 'Alert Correlation', action: 'Correlate failed login events across systems', automation: 'auto' },
        { order: 2, name: 'Risk Assessment', action: 'Determine if credentials are compromised', automation: 'auto' },
        { order: 3, name: 'Account Lockout', action: 'Lock affected accounts in Active Directory', automation: 'auto' },
        { order: 4, name: 'IP Block', action: 'Block source IPs on perimeter firewall', automation: 'auto' },
        { order: 5, name: 'User Notification', action: 'Notify affected users via email and Slack', automation: 'auto' },
        { order: 6, name: 'Password Reset', action: 'Force password reset for compromised accounts', automation: 'semi-auto' },
      ]), triggers: JSON.stringify([{ type: 'alert', condition: 'category = brute_force' }]), status: 'active', tags: JSON.stringify(['brute-force', 'identity']) }}),
      db.playbook.upsert({ where: { id: 'pb-3' }, update: {}, create: { id: 'pb-3', name: 'Malware Containment', description: 'Isolate and remediate malware infections on endpoints', category: 'incident_response', workflowId: 'wf-6', steps: JSON.stringify([
        { order: 1, name: 'Detection Confirmation', action: 'Verify malware detection alert', automation: 'auto' },
        { order: 2, name: 'Host Isolation', action: 'Network isolate infected endpoint', automation: 'auto' },
        { order: 3, name: 'Sample Collection', action: 'Collect malware sample for analysis', automation: 'auto' },
        { order: 4, name: 'Sandbox Analysis', action: 'Submit to sandbox for behavioral analysis', automation: 'auto' },
        { order: 5, name: 'Scope Assessment', action: 'Identify lateral movement and other infected hosts', automation: 'manual' },
        { order: 6, name: 'Remediation', action: 'Clean endpoint and restore from backup', automation: 'manual' },
      ]), triggers: JSON.stringify([{ type: 'alert', condition: 'category = malware' }]), status: 'active', tags: JSON.stringify(['malware', 'endpoint']) }}),
      db.playbook.upsert({ where: { id: 'pb-4' }, update: {}, create: { id: 'pb-4', name: 'Multi-Source Threat Enrichment', description: 'IOC enrichment across VirusTotal, AbuseIPDB, OTX, and IPInfo, then auto-create case + Slack + Jira', category: 'investigation', workflowId: 'wf-5', steps: JSON.stringify([
        { order: 1, name: 'IOC Ingestion', action: 'Receive IOC from trigger (manual, webhook, or alert)', automation: 'auto' },
        { order: 2, name: 'VirusTotal Lookup', action: 'Query VirusTotal v3 for IP/domain/hash reputation', automation: 'auto' },
        { order: 3, name: 'AbuseIPDB Check', action: 'Get abuse confidence score for source IP', automation: 'auto' },
        { order: 4, name: 'AlienVault OTX Pulses', action: 'Cross-reference IOC against OTX threat pulses', automation: 'auto' },
        { order: 5, name: 'IPInfo Geolocate', action: 'Get geolocation + ASN for the IP', automation: 'auto' },
        { order: 6, name: 'Decision Gate', action: 'Branch on whether IOC is malicious (VT score threshold)', automation: 'auto' },
        { order: 7, name: 'Create Case', action: 'Open incident case with full enrichment context', automation: 'auto' },
        { order: 8, name: 'Notify SOC', action: 'Post enrichment summary to Slack #soc-alerts', automation: 'auto' },
        { order: 9, name: 'Create Jira Issue', action: 'Track investigation in Jira SEC project', automation: 'auto' },
      ]), triggers: JSON.stringify([{ type: 'manual' }, { type: 'webhook', condition: 'path = /webhook/ioc' }]), status: 'active', tags: JSON.stringify(['enrichment', 'virustotal', 'abuseipdb', 'otx', 'ipinfo']) }}),
      // Documentation-only playbook (no linked workflow) — shows the empty state
      db.playbook.upsert({ where: { id: 'pb-5' }, update: {}, create: { id: 'pb-5', name: 'Data Exfiltration Investigation', description: 'Investigate and respond to data exfiltration incidents (documentation-only — link a workflow to enable execution)', category: 'investigation', workflowId: null, steps: JSON.stringify([
        { order: 1, name: 'Data Flow Analysis', action: 'Analyze network traffic for data exfiltration patterns', automation: 'auto' },
        { order: 2, name: 'Source Identification', action: 'Identify source system and user', automation: 'auto' },
        { order: 3, name: 'Containment', action: 'Block exfiltration channel', automation: 'auto' },
        { order: 4, name: 'Impact Assessment', action: 'Determine what data was exfiltrated', automation: 'manual' },
        { order: 5, name: 'Legal & Compliance', action: 'Notify legal and compliance teams', automation: 'semi-auto' },
      ]), triggers: JSON.stringify([{ type: 'alert', condition: 'category = data_exfiltration' }]), status: 'draft', tags: JSON.stringify(['data-exfil', 'compliance']) }}),
    ]);

    // Seed some executions
    const wf1 = await db.workflow.findFirst({ where: { id: 'wf-1' } });
    const wf2 = await db.workflow.findFirst({ where: { id: 'wf-2' } });
    
    if (wf1) {
      await db.workflowExecution.create({ data: { workflowId: wf1.id, status: 'success', trigger: JSON.stringify({ type: 'webhook' }), result: JSON.stringify({ duration: '3420ms', steps_completed: 7 }), logs: JSON.stringify([{ time: new Date().toISOString(), message: 'Completed', level: 'success' }]), startedAt: new Date(Date.now() - 3600000), endedAt: new Date(Date.now() - 3597000) } });
      await db.workflowExecution.create({ data: { workflowId: wf1.id, status: 'success', trigger: JSON.stringify({ type: 'webhook' }), result: JSON.stringify({ duration: '2890ms', steps_completed: 7 }), logs: JSON.stringify([{ time: new Date().toISOString(), message: 'Completed', level: 'success' }]), startedAt: new Date(Date.now() - 7200000), endedAt: new Date(Date.now() - 7197000) } });
      await db.workflowExecution.create({ data: { workflowId: wf1.id, status: 'failed', trigger: JSON.stringify({ type: 'webhook' }), result: JSON.stringify({ duration: '1200ms', steps_completed: 3, error: 'VirusTotal API timeout' }), logs: JSON.stringify([{ time: new Date().toISOString(), message: 'Failed at step 3', level: 'error' }]), startedAt: new Date(Date.now() - 86400000), endedAt: new Date(Date.now() - 86399000) } });
    }
    if (wf2) {
      await db.workflowExecution.create({ data: { workflowId: wf2.id, status: 'success', trigger: JSON.stringify({ type: 'schedule' }), result: JSON.stringify({ duration: '1500ms', steps_completed: 4 }), logs: JSON.stringify([{ time: new Date().toISOString(), message: 'Completed', level: 'success' }]), startedAt: new Date(Date.now() - 1800000), endedAt: new Date(Date.now() - 1798000) } });
      await db.workflowExecution.create({ data: { workflowId: wf2.id, status: 'running', trigger: JSON.stringify({ type: 'schedule' }), result: JSON.stringify({}), logs: JSON.stringify([{ time: new Date().toISOString(), message: 'Running', level: 'info' }]), startedAt: new Date() } });
    }

    // Audit the seed operation (forces=?force=1 is a destructive op)
    await writeAudit(ctx, {
      action: force ? 'system.seed.force' : 'system.seed',
      resource: 'system',
      description: force
        ? `Force re-seeded demo data (wiped existing)`
        : `Seeded demo data (preserved existing real configs)`,
      metadata: { force, existingIntegrations: existingIntegrations.length, existingCases, existingWorkflows },
    });

    return NextResponse.json({ success: true, integrations: integrations.length, workflows: workflows.length, cases: cases.length, alerts: alerts.length, playbooks: playbooks.length });
  } catch (error) {
    if (error instanceof AuthenticationError) {
      return NextResponse.json({ error: error.message }, { status: 401 });
    }
    if (error instanceof AuthorizationError) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    logger.error({ err: error }, 'Seed error');
    // SECURITY: don't leak internal error details to the client
    return NextResponse.json({ error: 'Failed to seed data' }, { status: 500 });
  }
}
