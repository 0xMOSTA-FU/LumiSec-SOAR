'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, GitBranch, FolderOpen, Puzzle, BookOpen, Bell,
  Play, Plus, Search, Settings, Moon, Sun, ChevronRight,
  Shield, AlertTriangle, CheckCircle2, XCircle, Clock, Activity,
  Zap, Eye, MoreVertical, Trash2, Edit3, ExternalLink, Filter,
  ArrowUpRight, ArrowDownRight, CircleDot, MessageSquare,
  Server, Cloud, Users, Mail, Bug, Radar, Monitor, Ticket, Database,
  X, Save, Pause, RotateCcw, Send, Link2, Tag, User,
  TrendingUp, BarChart3, Globe, FileText,
  ChevronLeft, Copy, Download, RefreshCw,
  Lightbulb, ArrowLeft
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import WorkflowBuilder from './WorkflowBuilder';
import { AnalyticsView, ThreatOpsView, IncidentDetailView } from './SecurityScreens';
import { useToast } from '@/hooks/use-toast';

// ========== TYPES ==========
type Page = 'dashboard' | 'workflows' | 'workflow-builder' | 'cases' | 'integrations' | 'playbooks' | 'alerts' | 'settings' | 'analytics' | 'threat-ops' | 'incident-detail';

interface WorkflowNode {
  id: string;
  type: 'trigger' | 'action' | 'condition' | 'output';
  position: { x: number; y: number };
  data: { label: string; config: Record<string, unknown>; description?: string };
}

interface WorkflowEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
}

interface Workflow {
  id: string;
  name: string;
  description?: string;
  status: string;
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  trigger: Record<string, unknown>;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  executions?: { id: string; status: string; startedAt: string }[];
}

interface CaseItem {
  id: string;
  title: string;
  description?: string;
  severity: string;
  status: string;
  assignee?: string;
  tags: string[];
  artifacts: string[];
  timeline: { time: string; event: string }[];
  createdAt: string;
  updatedAt: string;
}

interface Integration {
  id: string;
  name: string;
  type: string;
  category: string;
  description?: string;
  config: Record<string, unknown>;
  status: string;
  icon: string;
  createdAt: string;
  updatedAt: string;
}

interface Playbook {
  id: string;
  name: string;
  description?: string;
  category: string;
  steps: { order: number; name: string; action: string; automation: string }[];
  triggers: { type: string; condition: string }[];
  status: string;
  tags: string[];
  workflowId?: string | null;
  createdAt: string;
  updatedAt: string;
}

interface AlertItem {
  id: string;
  title: string;
  description?: string;
  source: string;
  severity: string;
  status: string;
  assignee?: string;
  caseId?: string;
  raw: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}

interface DashboardMetrics {
  openCases: number;
  criticalCases: number;
  activeWorkflows: number;
  newAlerts: number;
  connectedIntegrations: number;
  runningExecutions: number;
  recentAlerts: number;
  recentCases: number;
  recentExecutions: number;
  totalWorkflows: number;
  totalCases: number;
  totalAlerts: number;
  totalPlaybooks: number;
  // Counts from the external Node.js + MongoDB backend
  externalIncidents?: number;
  externalAssets?: number;
  externalBackendOk?: boolean;
}

// ========== HELPERS ==========
const getIconForIntegration = (icon: string) => {
  const map: Record<string, React.ReactNode> = {
    radar: <Radar className="h-5 w-5" />, shield: <Shield className="h-5 w-5" />,
    bug: <Bug className="h-5 w-5" />, 'message-circle': <MessageSquare className="h-5 w-5" />,
    ticket: <Ticket className="h-5 w-5" />, monitor: <Monitor className="h-5 w-5" />,
    cloud: <Cloud className="h-5 w-5" />, database: <Database className="h-5 w-5" />,
    mail: <Mail className="h-5 w-5" />, users: <Users className="h-5 w-5" />,
    server: <Server className="h-5 w-5" />, globe: <Globe className="h-5 w-5" />,
  };
  return map[icon] || <Puzzle className="h-5 w-5" />;
};

const severityColor = (sev: string) => {
  switch (sev) {
    case 'critical': return 'bg-red-500/10 text-red-600 border-red-500/20';
    case 'high': return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
    case 'medium': return 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20';
    case 'low': return 'bg-green-500/10 text-green-600 border-green-500/20';
    default: return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
  }
};

const statusColor = (status: string) => {
  switch (status) {
    case 'open': case 'new': case 'running': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
    case 'investigating': case 'active': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
    case 'connected': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
    case 'contained': case 'draft': return 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20';
    case 'resolved': case 'success': case 'closed': return 'bg-green-500/10 text-green-600 border-green-500/20';
    case 'failed': case 'disconnected': case 'error': return 'bg-red-500/10 text-red-600 border-red-500/20';
    default: return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
  }
};

const formatDate = (d: string) => {
  try { return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); }
  catch { return d; }
};

// ========== MAIN APP ==========
export default function SOARApp() {
  const [page, setPage] = useState<Page>('dashboard');
  // Persist sidebar + darkMode in localStorage so they survive reloads
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [seeded, setSeeded] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Data
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [cases, setCases] = useState<CaseItem[]>([]);
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [playbooks, setPlaybooks] = useState<Playbook[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [activityFeed, setActivityFeed] = useState<{ type: string; message: string; time: string; severity: string }[]>([]);
  const [severityDist, setSeverityDist] = useState({ critical: 0, high: 0, medium: 0, low: 0 });

  // Workflow Builder state
  const [editingWorkflow, setEditingWorkflow] = useState<Workflow | null>(null);
  // Currently selected incident id (case or alert) — drives the IncidentDetailView
  const [selectedIncidentId, setSelectedIncidentId] = useState<string | null>(null);

  // Dialog states
  const [showNewWorkflow, setShowNewWorkflow] = useState(false);
  const [showNewCase, setShowNewCase] = useState(false);
  const [showNewAlert, setShowNewAlert] = useState(false);
  const [showNewPlaybook, setShowNewPlaybook] = useState(false);
  const [showNewIntegration, setShowNewIntegration] = useState(false);
  // Playbook → Workflow link dialog: holds the playbook id being linked, or null
  const [linkingPlaybookId, setLinkingPlaybookId] = useState<string | null>(null);
  // Playbook run dialog: holds the playbook being run, so the user can supply
  // a trigger payload (e.g. {"ip":"8.8.8.8"}) before the workflow starts.
  const [runningPlaybook, setRunningPlaybook] = useState<Playbook | null>(null);

  // Integration config modal
  const [configuringIntegration, setConfiguringIntegration] = useState<string | null>(null);
  const [testingId, setTestingId] = useState<string | null>(null);
  const { toast } = useToast();

  // Toggle dark mode + persist
  useEffect(() => {
    // Read persisted prefs on first mount — fall back to OS preference for dark mode
    try {
      const savedDark = localStorage.getItem('soar:darkMode');
      const savedSidebar = localStorage.getItem('soar:sidebarCollapsed');
      if (savedDark !== null) {
        setDarkMode(savedDark === 'true');
      } else if (typeof window !== 'undefined' && window.matchMedia) {
        // Respect OS color scheme on first visit (no saved preference)
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        setDarkMode(prefersDark);
      }
      if (savedSidebar !== null) setSidebarCollapsed(savedSidebar === 'true');
    } catch {/* ignore */}
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    try { localStorage.setItem('soar:darkMode', String(darkMode)); } catch {/* ignore */}
  }, [darkMode]);

  useEffect(() => {
    try { localStorage.setItem('soar:sidebarCollapsed', String(sidebarCollapsed)); } catch {/* ignore */}
  }, [sidebarCollapsed]);

  // Seed & fetch data — accepts optional force flag to override the smart-skip
  // behavior (used by the Settings → "Reset Demo Data" button).
  const seedData = useCallback(async (opts?: { force?: boolean }) => {
    try {
      const url = opts?.force ? '/api/seed?force=1' : '/api/seed';
      await fetch(url, { method: 'POST' });
      setSeeded(true);
    } catch (e) { console.error('Seed error', e); }
  }, []);

  const fetchDashboard = useCallback(async () => {
    try {
      const res = await fetch('/api/dashboard');
      const data = await res.json();
      if (data.metrics) setMetrics(data.metrics);
      if (data.severityDistribution) setSeverityDist(data.severityDistribution);
      if (data.activityFeed) setActivityFeed(data.activityFeed);
    } catch (e) { console.error('Dashboard fetch error', e); }
  }, []);

  const fetchWorkflows = useCallback(async () => {
    try {
      const res = await fetch('/api/workflows');
      const data = await res.json();
      setWorkflows(data.map((w: Record<string, unknown>) => ({
        ...w,
        nodes: typeof w.nodes === 'string' ? JSON.parse(w.nodes as string) : w.nodes,
        edges: typeof w.edges === 'string' ? JSON.parse(w.edges as string) : w.edges,
        trigger: typeof w.trigger === 'string' ? JSON.parse(w.trigger as string) : w.trigger,
        tags: typeof w.tags === 'string' ? JSON.parse(w.tags as string) : w.tags,
      })));
    } catch (e) { console.error('Workflows fetch error', e); }
  }, []);

  const fetchCases = useCallback(async () => {
    try {
      const res = await fetch('/api/cases');
      const data = await res.json();
      setCases(data.map((c: Record<string, unknown>) => ({
        ...c,
        tags: typeof c.tags === 'string' ? JSON.parse(c.tags as string) : c.tags,
        artifacts: typeof c.artifacts === 'string' ? JSON.parse(c.artifacts as string) : c.artifacts,
        timeline: typeof c.timeline === 'string' ? JSON.parse(c.timeline as string) : c.timeline,
      })));
    } catch (e) { console.error('Cases fetch error', e); }
  }, []);

  const fetchIntegrations = useCallback(async () => {
    try {
      const res = await fetch('/api/integrations');
      const data = await res.json();
      setIntegrations(data.map((i: Record<string, unknown>) => ({
        ...i,
        config: typeof i.config === 'string' ? JSON.parse(i.config as string) : i.config,
      })));
    } catch (e) { console.error('Integrations fetch error', e); }
  }, []);

  const fetchPlaybooks = useCallback(async () => {
    try {
      const res = await fetch('/api/playbooks');
      const data = await res.json();
      setPlaybooks(data.map((p: Record<string, unknown>) => ({
        ...p,
        steps: typeof p.steps === 'string' ? JSON.parse(p.steps as string) : p.steps,
        triggers: typeof p.triggers === 'string' ? JSON.parse(p.triggers as string) : p.triggers,
        tags: typeof p.tags === 'string' ? JSON.parse(p.tags as string) : p.tags,
        workflowId: p.workflowId ?? null,
      })));
    } catch (e) { console.error('Playbooks fetch error', e); }
  }, []);

  const fetchAlerts = useCallback(async () => {
    try {
      const res = await fetch('/api/alerts');
      const data = await res.json();
      setAlerts(data.map((a: Record<string, unknown>) => ({
        ...a,
        raw: typeof a.raw === 'string' ? JSON.parse(a.raw as string) : a.raw,
      })));
    } catch (e) { console.error('Alerts fetch error', e); }
  }, []);

  useEffect(() => {
    const init = async () => {
      if (!seeded) await seedData();
      await Promise.all([fetchDashboard(), fetchWorkflows(), fetchCases(), fetchIntegrations(), fetchPlaybooks(), fetchAlerts()]);
      setLoading(false);
    };
    init();
  }, [seeded, seedData, fetchDashboard, fetchWorkflows, fetchCases, fetchIntegrations, fetchPlaybooks, fetchAlerts]);

  // ========== ACTIONS ==========
  const executeWorkflow = async (id: string) => {
    try {
      const res = await fetch('/api/workflow-executions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ workflowId: id }) });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Unknown' }));
        toast({ title: 'Execution failed', description: err.error, variant: 'destructive' });
        return;
      }
      toast({ title: 'Execution started', description: 'Workflow is now running. Open Workflow Builder to see live logs.' });
      fetchDashboard(); fetchWorkflows();
    } catch (e) {
      toast({ title: 'Network error', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    }
  };

  const deleteWorkflow = async (id: string) => {
    try {
      await fetch(`/api/workflows?id=${id}`, { method: 'DELETE' });
      toast({ title: 'Workflow deleted' });
      fetchWorkflows(); fetchDashboard();
    } catch (e) { toast({ title: 'Delete failed', description: String(e), variant: 'destructive' }); }
  };

  const deleteCase = async (id: string) => {
    try {
      await fetch(`/api/cases?id=${id}`, { method: 'DELETE' });
      toast({ title: 'Case deleted' });
      fetchCases(); fetchDashboard();
    } catch (e) { toast({ title: 'Delete failed', description: String(e), variant: 'destructive' }); }
  };

  const deleteAlert = async (id: string) => {
    try {
      await fetch(`/api/alerts?id=${id}`, { method: 'DELETE' });
      toast({ title: 'Alert deleted' });
      fetchAlerts(); fetchDashboard();
    } catch (e) { toast({ title: 'Delete failed', description: String(e), variant: 'destructive' }); }
  };

  const deletePlaybook = async (id: string) => {
    try {
      await fetch(`/api/playbooks?id=${id}`, { method: 'DELETE' });
      toast({ title: 'Playbook deleted' });
      fetchPlaybooks(); fetchDashboard();
    } catch (e) { toast({ title: 'Delete failed', description: String(e), variant: 'destructive' }); }
  };

  // Duplicate a playbook — fetches the source row, strips the id, and POSTs a copy
  const duplicatePlaybook = async (id: string) => {
    try {
      const res = await fetch(`/api/playbooks?id=${id}`);
      if (!res.ok) throw new Error('Failed to load playbook');
      const src = await res.json();
      const body = {
        name: `${src.name || 'Playbook'} (Copy)`,
        description: src.description || '',
        category: src.category || 'incident_response',
        steps: src.steps || [],
        triggers: src.triggers || [],
        tags: src.tags || [],
        status: 'draft',
      };
      const postRes = await fetch('/api/playbooks', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      });
      if (!postRes.ok) throw new Error('Failed to create copy');
      toast({ title: 'Playbook duplicated', description: body.name });
      fetchPlaybooks(); fetchDashboard();
    } catch (e) {
      toast({ title: 'Duplicate failed', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    }
  };

  // Toggle a playbook between active and draft
  const togglePlaybookStatus = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'draft' : 'active';
    try {
      const res = await fetch('/api/playbooks', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus }),
      });
      if (!res.ok) throw new Error('Failed to update status');
      toast({ title: `Playbook ${newStatus === 'active' ? 'activated' : 'deactivated'}` });
      fetchPlaybooks(); fetchDashboard();
    } catch (e) {
      toast({ title: 'Update failed', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    }
  };

  // Execute a playbook — runs the linked workflow with an optional trigger payload.
  // If the playbook has no linked workflow, shows a toast prompting the user to link one.
  const executePlaybook = async (pb: Playbook, triggerPayload?: Record<string, unknown>) => {
    if (!pb.workflowId) {
      toast({
        title: 'No linked workflow',
        description: 'This playbook is documentation-only. Link a workflow to enable execution.',
        variant: 'destructive',
      });
      return;
    }
    try {
      const res = await fetch(`/api/playbooks/${pb.id}/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ trigger: triggerPayload || {} }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Unknown' }));
        toast({ title: 'Execution failed', description: err.error, variant: 'destructive' });
        return;
      }
      const data = await res.json();
      toast({
        title: 'Playbook execution started',
        description: `"${pb.name}" is now running workflow "${data.workflowName}".`,
      });
      fetchDashboard();
    } catch (e) {
      toast({ title: 'Network error', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    }
  };

  // Link a playbook to a workflow (or unlink when workflowId is null)
  const linkPlaybookWorkflow = async (playbookId: string, workflowId: string | null) => {
    try {
      const res = await fetch('/api/playbooks', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: playbookId, workflowId }),
      });
      if (!res.ok) throw new Error('Failed to update link');
      toast({
        title: workflowId ? 'Workflow linked' : 'Workflow unlinked',
        description: workflowId ? 'Playbook can now be executed.' : 'Playbook is now documentation-only.',
      });
      fetchPlaybooks();
    } catch (e) {
      toast({ title: 'Update failed', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    }
  };

  const toggleIntegration = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'connected' ? 'disconnected' : 'connected';
    try {
      await fetch('/api/integrations', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status: newStatus }) });
      toast({ title: `Integration ${newStatus}` });
      fetchIntegrations(); fetchDashboard();
    } catch (e) { toast({ title: 'Toggle failed', description: String(e), variant: 'destructive' }); }
  };

  const updateAlertStatus = async (id: string, status: string) => {
    try {
      await fetch('/api/alerts', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status }) });
      toast({ title: `Alert marked as ${status}` });
      fetchAlerts(); fetchDashboard();
    } catch (e) { toast({ title: 'Update failed', description: String(e), variant: 'destructive' }); }
  };

  const updateCaseStatus = async (id: string, status: string) => {
    try {
      await fetch('/api/cases', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status }) });
      toast({ title: `Case marked as ${status}` });
      fetchCases(); fetchDashboard();
    } catch (e) { toast({ title: 'Update failed', description: String(e), variant: 'destructive' }); }
  };

  // Workflow Builder
  const openWorkflowBuilder = (wf?: Workflow) => {
    if (wf) {
      setEditingWorkflow(wf);
    } else {
      const newWf: Workflow = {
        id: `new-${Date.now()}`, name: 'New Workflow', description: '', status: 'draft',
        nodes: [{ id: 'n1', type: 'trigger', position: { x: 80, y: 250 }, data: { label: 'New Trigger', config: {} } }],
        edges: [], trigger: {}, tags: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      };
      setEditingWorkflow(newWf);
    }
    setPage('workflow-builder');
  };

  const saveWorkflow = async () => {
    if (!editingWorkflow) return;
    try {
      const isNew = editingWorkflow.id.startsWith('new-');
      const body = { ...editingWorkflow };
      if (isNew) {
        const { id, ...data } = body;
        const res = await fetch('/api/workflows', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
        if (!res.ok) {
          const err = await res.json().catch(() => ({ error: 'Unknown' }));
          toast({ title: 'Save failed', description: err.error, variant: 'destructive' });
          return;
        }
        toast({ title: 'Workflow created', description: editingWorkflow.name });
      } else {
        const res = await fetch('/api/workflows', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
        if (!res.ok) {
          const err = await res.json().catch(() => ({ error: 'Unknown' }));
          toast({ title: 'Save failed', description: err.error, variant: 'destructive' });
          return;
        }
        toast({ title: 'Workflow saved', description: editingWorkflow.name });
      }
      fetchWorkflows();
      setPage('workflows');
      setEditingWorkflow(null);
    } catch (e) {
      toast({ title: 'Save error', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    }
  };

  // ========== SIDEBAR ==========
  const navItems: { icon: React.ReactNode; label: string; page: Page; badge?: number }[] = [
    { icon: <LayoutDashboard className="h-5 w-5" />, label: 'Dashboard', page: 'dashboard' },
    { icon: <Radar className="h-5 w-5" />, label: 'Threat Ops', page: 'threat-ops' },
    { icon: <BarChart3 className="h-5 w-5" />, label: 'Analytics', page: 'analytics' },
    { icon: <GitBranch className="h-5 w-5" />, label: 'Workflows', page: 'workflows', badge: metrics?.activeWorkflows },
    { icon: <FolderOpen className="h-5 w-5" />, label: 'Cases', page: 'cases', badge: metrics?.openCases },
    { icon: <Bell className="h-5 w-5" />, label: 'Alerts', page: 'alerts', badge: metrics?.newAlerts },
    { icon: <Puzzle className="h-5 w-5" />, label: 'Integrations', page: 'integrations' },
    { icon: <BookOpen className="h-5 w-5" />, label: 'Playbooks', page: 'playbooks' },
    { icon: <Settings className="h-5 w-5" />, label: 'Settings', page: 'settings' },
  ];

  // ========== RENDER ==========
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        {/* Static fallback (visible before framer-motion hydrates) */}
        <noscript>
          <div className="flex flex-col items-center gap-4">
            <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-lg shadow-primary/25">
              <Shield className="h-7 w-7 text-primary-foreground" />
            </div>
            <div className="text-center space-y-1.5">
              <h2 className="text-xl font-semibold tracking-tight">CyberSOAR</h2>
              <p className="text-muted-foreground text-sm">Loading…</p>
            </div>
          </div>
        </noscript>
        <motion.div
          initial={false}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="flex flex-col items-center gap-5"
        >
          <div className="relative">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2.4, repeat: Infinity, ease: 'linear' }}
              className="absolute inset-0 -m-3 border-2 border-primary/15 border-t-primary rounded-full"
            />
            <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-lg shadow-primary/25">
              <Shield className="h-7 w-7 text-primary-foreground" />
            </div>
          </div>
          <div className="text-center space-y-1.5">
            <h2 className="text-xl font-semibold tracking-tight">CyberSOAR</h2>
            <p className="text-muted-foreground text-sm flex items-center gap-1.5 justify-center">
              <span className="h-1.5 w-1.5 rounded-full bg-primary pulse-dot" />
              Initializing security platform...
            </p>
          </div>
          <Progress className="w-56 h-1.5" />
        </motion.div>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen flex bg-background">
        {/* Mobile sidebar backdrop */}
        {mobileSidebarOpen && (
          <div
            className="md:hidden fixed inset-0 bg-black/50 z-20"
            onClick={() => setMobileSidebarOpen(false)}
          />
        )}
        {/* Sidebar */}
        <motion.aside
          initial={false}
          animate={{ width: sidebarCollapsed ? 64 : 240 }}
          className={`h-screen sticky top-0 bg-sidebar text-sidebar-foreground flex flex-col border-r border-sidebar-border z-30 shrink-0
            ${mobileSidebarOpen ? 'fixed md:static translate-x-0' : 'fixed md:static -translate-x-full md:translate-x-0'}`}
        >
          {/* Logo */}
          <div className="h-16 flex items-center gap-3 px-4 border-b border-sidebar-border">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shrink-0 shadow-sm shadow-primary/30">
              <Shield className="h-5 w-5 text-primary-foreground" />
            </div>
            {!sidebarCollapsed && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="overflow-hidden">
                <h1 className="font-bold text-base leading-tight tracking-tight">CyberSOAR</h1>
                <p className="text-[10px] text-sidebar-foreground/50 leading-tight">Security Orchestration Platform</p>
              </motion.div>
            )}
          </div>

          {/* Nav */}
          <nav className="flex-1 py-2 overflow-y-auto">
            {navItems.map(item => (
              <Tooltip key={item.page} delayDuration={0}>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => { setPage(item.page); setMobileSidebarOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors relative group
                      ${page === item.page || (page === 'workflow-builder' && item.page === 'workflows')
                        ? 'bg-sidebar-accent text-sidebar-accent-foreground font-medium'
                        : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground'}`}
                  >
                    {item.icon}
                    {!sidebarCollapsed && (
                      <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="truncate">{item.label}</motion.span>
                    )}
                    {item.badge && item.badge > 0 && (
                      <span className={`${sidebarCollapsed ? 'absolute top-1 right-1' : 'ml-auto'} bg-red-500 text-white text-[10px] font-bold rounded-full h-4 min-w-4 flex items-center justify-center px-1`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                </TooltipTrigger>
                {sidebarCollapsed && <TooltipContent side="right">{item.label}</TooltipContent>}
              </Tooltip>
            ))}
          </nav>

          {/* Bottom */}
          <div className="p-2 border-t border-sidebar-border">
            <button onClick={() => setSidebarCollapsed(!sidebarCollapsed)} className="w-full flex items-center justify-center gap-2 px-3 py-2 text-sm text-sidebar-foreground/50 hover:text-sidebar-foreground rounded-md hover:bg-sidebar-accent/50 transition-colors">
              {sidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
              {!sidebarCollapsed && <span>Collapse</span>}
            </button>
          </div>
        </motion.aside>

        {/* Main Content */}
        <main className="flex-1 min-w-0">
          {/* Top Bar */}
          <header className="h-16 sticky top-0 bg-background/80 backdrop-blur-md border-b border-border flex items-center justify-between px-4 sm:px-6 z-20">
            <div className="flex items-center gap-3 min-w-0">
              {/* Mobile sidebar toggle */}
              <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}>
                <ChevronRight className={`h-5 w-5 transition-transform ${mobileSidebarOpen ? 'rotate-180' : ''}`} />
              </Button>
              <h2 className="text-base sm:text-lg font-semibold capitalize truncate">{page === 'threat-ops' ? 'Threat Operations' : page === 'incident-detail' ? 'Incident Detail' : page.replace('-', ' ')}</h2>
              {metrics && (page === 'dashboard' || page === 'alerts') && metrics.runningExecutions > 0 && (
                <Badge variant="outline" className="hidden sm:flex bg-green-500/10 text-green-600 border-green-500/20 gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-500 pulse-dot" />
                  {metrics.runningExecutions} Running
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="relative hidden sm:block">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search..." className="pl-8 w-40 lg:w-56" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
              </div>
              <Button variant="ghost" size="icon" onClick={() => setDarkMode(!darkMode)} aria-label="Toggle dark mode">
                {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-primary text-primary-foreground text-xs">SO</AvatarFallback>
              </Avatar>
            </div>
          </header>

          {/* Page Content */}
          <div className="p-4 sm:p-6">
            <AnimatePresence mode="wait">
              <motion.div key={page} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>

                {/* ===== DASHBOARD ===== */}
                {page === 'dashboard' && metrics && (
                  <div className="space-y-6">
                    {/* Quick security access banner */}
                    <div className="flex flex-wrap items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20">
                      <Radar className="h-5 w-5 text-primary shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">Threat Operations Center</p>
                        <p className="text-xs text-muted-foreground">Real-time threat monitoring, incident queue, and global threat intel</p>
                      </div>
                      <Button size="sm" variant="default" onClick={() => setPage('threat-ops')}>
                        Open Threat Ops <ChevronRight className="h-3.5 w-3.5 ml-1" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setPage('analytics')}>
                        <BarChart3 className="h-3.5 w-3.5 mr-1" /> Analytics
                      </Button>
                    </div>

                    {/* Metric Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      {[
                        { label: 'Open Cases', value: metrics.openCases, icon: <FolderOpen className="h-5 w-5" />, color: 'text-blue-500', bg: 'bg-blue-500/10', change: '+3', up: true },
                        { label: 'Critical Alerts', value: metrics.criticalCases, icon: <AlertTriangle className="h-5 w-5" />, color: 'text-red-500', bg: 'bg-red-500/10', change: '+1', up: true },
                        { label: 'Active Workflows', value: metrics.activeWorkflows, icon: <GitBranch className="h-5 w-5" />, color: 'text-emerald-500', bg: 'bg-emerald-500/10', change: '0', up: false },
                        { label: 'New Alerts (24h)', value: metrics.recentAlerts, icon: <Bell className="h-5 w-5" />, color: 'text-amber-500', bg: 'bg-amber-500/10', change: '+5', up: true },
                      ].map((m, i) => (
                        <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                          <Card data-interactive-card>
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div className={`p-2 rounded-lg ${m.bg} ${m.color}`} aria-hidden>{m.icon}</div>
                                <span className={`text-xs flex items-center gap-0.5 font-medium ${m.up ? 'text-red-500' : 'text-emerald-500'}`}>
                                  {m.up ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                                  {m.change}
                                </span>
                              </div>
                              <div className="mt-3">
                                <p className="text-2xl font-bold tabular-nums">{m.value}</p>
                                <p className="text-xs text-muted-foreground mt-0.5">{m.label}</p>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </div>

                    {/* Charts Row */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                      {/* Alert Severity Distribution */}
                      <Card data-interactive-card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm font-semibold">Alert Severity Distribution</CardTitle>
                          <CardDescription className="text-[11px]">Total alerts grouped by severity</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {Object.entries(severityDist).map(([key, val]) => {
                              const total = Object.values(severityDist).reduce((a, b) => a + b, 0) || 1;
                              const pct = Math.round((val / total) * 100);
                              const colors: Record<string, string> = { critical: 'bg-red-500', high: 'bg-orange-500', medium: 'bg-yellow-500', low: 'bg-green-500' };
                              return (
                                <div key={key} className="space-y-1">
                                  <div className="flex justify-between text-xs">
                                    <span className="capitalize font-medium">{key}</span>
                                    <span className="text-muted-foreground">{val} ({pct}%)</span>
                                  </div>
                                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                                    <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, delay: 0.2 }} className={`h-full rounded-full ${colors[key]}`} />
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </CardContent>
                      </Card>

                      {/* Quick Stats */}
                      <Card data-interactive-card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm font-semibold">Platform Overview</CardTitle>
                          <CardDescription className="text-[11px]">System resources and counts</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-2 gap-3">
                            {[
                              { label: 'Total Workflows', value: metrics.totalWorkflows, icon: <GitBranch className="h-4 w-4" /> },
                              { label: 'Total Cases', value: metrics.totalCases, icon: <FolderOpen className="h-4 w-4" /> },
                              { label: 'Integrations', value: metrics.connectedIntegrations, icon: <Puzzle className="h-4 w-4" /> },
                              { label: 'Playbooks', value: metrics.totalPlaybooks, icon: <BookOpen className="h-4 w-4" /> },
                              { label: 'Executions (24h)', value: metrics.recentExecutions, icon: <Activity className="h-4 w-4" /> },
                              { label: 'New Cases (24h)', value: metrics.recentCases, icon: <TrendingUp className="h-4 w-4" /> },
                            ].map((s, i) => (
                              <div key={i} className="flex items-center gap-2 p-2 rounded-md bg-muted/50 hover:bg-muted transition-colors">
                                <div className="text-muted-foreground" aria-hidden>{s.icon}</div>
                                <div>
                                  <p className="text-lg font-bold leading-tight tabular-nums">{s.value}</p>
                                  <p className="text-[10px] text-muted-foreground">{s.label}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                          {/* External backend (Node.js + MongoDB) connection status */}
                          <div className="mt-3 pt-3 border-t border-border">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 min-w-0">
                                <Server className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                                <span className="text-[10px] text-muted-foreground truncate">External Backend (Node.js + Mongo)</span>
                              </div>
                              <Badge variant="outline" className={
                                metrics.externalBackendOk
                                  ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
                                  : 'bg-amber-500/10 text-amber-600 border-amber-500/20'
                              }>
                                <span className={`h-1.5 w-1.5 rounded-full mr-1 ${metrics.externalBackendOk ? 'bg-emerald-500 pulse-dot' : 'bg-amber-500'}`} />
                                {metrics.externalBackendOk ? 'Connected' : 'Offline'}
                              </Badge>
                            </div>
                            {metrics.externalBackendOk && (
                              <div className="flex items-center justify-between mt-1.5 text-[10px] text-muted-foreground">
                                <span>External incidents: <span className="font-medium text-foreground tabular-nums">{metrics.externalIncidents ?? 0}</span></span>
                                <span>External assets: <span className="font-medium text-foreground tabular-nums">{metrics.externalAssets ?? 0}</span></span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>

                      {/* Activity Feed */}
                      <Card data-interactive-card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm font-semibold">Recent Activity</CardTitle>
                          <CardDescription className="text-[11px]">Latest platform events</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <ScrollArea className="h-64">
                            <div className="space-y-3">
                              {activityFeed.map((item, i) => (
                                <div key={i} className="flex items-start gap-2">
                                  <div className={`mt-0.5 h-2 w-2 rounded-full shrink-0 ${item.severity === 'critical' ? 'bg-red-500' : item.severity === 'high' ? 'bg-orange-500' : item.severity === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'}`} />
                                  <div className="min-w-0">
                                    <p className="text-xs truncate">{item.message}</p>
                                    <p className="text-[10px] text-muted-foreground">{formatDate(item.time)}</p>
                                  </div>
                                </div>
                              ))}
                              {activityFeed.length === 0 && <p className="text-xs text-muted-foreground text-center py-8">No recent activity</p>}
                            </div>
                          </ScrollArea>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Recent Items */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      {/* Recent Workflows */}
                      <Card data-interactive-card>
                        <CardHeader className="pb-3 flex flex-row items-center justify-between">
                          <CardTitle className="text-sm font-semibold">Active Workflows</CardTitle>
                          <button className="view-all-link" type="button" onClick={() => setPage('workflows')}>View All <ChevronRight className="h-3 w-3" /></button>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {workflows.filter(w => w.status === 'active').length === 0 ? (
                              <div className="text-center py-6 text-xs text-muted-foreground">
                                No active workflows yet
                              </div>
                            ) : workflows.filter(w => w.status === 'active').slice(0, 3).map(wf => (
                              <div key={wf.id} className="flex items-center justify-between p-2 rounded-md hover:bg-muted/50 transition-colors">
                                <div className="flex items-center gap-2 min-w-0">
                                  <GitBranch className="h-4 w-4 text-primary shrink-0" aria-hidden />
                                  <span className="text-sm truncate">{wf.name}</span>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  <Badge variant="outline" className={statusColor(wf.status)}>{wf.status}</Badge>
                                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => executeWorkflow(wf.id)} aria-label="Execute workflow" data-ui-button>
                                    <Play className="h-3.5 w-3.5" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>

                      {/* Recent Cases */}
                      <Card data-interactive-card>
                        <CardHeader className="pb-3 flex flex-row items-center justify-between">
                          <CardTitle className="text-sm font-semibold">Open Cases</CardTitle>
                          <button className="view-all-link" type="button" onClick={() => setPage('cases')}>View All <ChevronRight className="h-3 w-3" /></button>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {cases.filter(c => c.status !== 'closed').length === 0 ? (
                              <div className="text-center py-6 text-xs text-muted-foreground">
                                No open cases
                              </div>
                            ) : cases.filter(c => c.status !== 'closed').slice(0, 3).map(c => (
                              <div key={c.id} className="flex items-center justify-between p-2 rounded-md hover:bg-muted/50 transition-colors">
                                <div className="flex items-center gap-2 min-w-0">
                                  <FolderOpen className="h-4 w-4 text-blue-500 shrink-0" aria-hidden />
                                  <span className="text-sm truncate">{c.title}</span>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  <Badge variant="outline" className={severityColor(c.severity)}>{c.severity}</Badge>
                                  <Badge variant="outline" className={statusColor(c.status)}>{c.status}</Badge>
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                )}

                {/* ===== THREAT OPS ===== */}
                {page === 'threat-ops' && (
                  <ThreatOpsView onInvestigate={() => setPage('incident-detail')} />
                )}

                {/* ===== ANALYTICS ===== */}
                {page === 'analytics' && (
                  <AnalyticsView />
                )}

                {/* ===== INCIDENT DETAIL ===== */}
                {page === 'incident-detail' && selectedIncidentId && (
                  <IncidentDetailView
                    incidentId={selectedIncidentId}
                    onBack={() => { setSelectedIncidentId(null); setPage('threat-ops'); }}
                    onClose={() => { setSelectedIncidentId(null); setPage('threat-ops'); }}
                    onAction={(action) => {
                      toast({
                        title: 'Action triggered',
                        description: action === 'Isolate Host'
                          ? `${action} - Host isolation command sent to EDR.`
                          : `${action} dispatched to the relevant integration.`,
                      });
                    }}
                  />
                )}
                {page === 'incident-detail' && !selectedIncidentId && (
                  <Card><CardContent className="py-12 text-center text-sm text-muted-foreground">
                    <AlertTriangle className="h-10 w-10 mx-auto mb-3 opacity-25" />
                    No incident selected. Pick one from Threat Ops or the Cases/Alerts list.
                    <div className="mt-4">
                      <Button size="sm" onClick={() => setPage('threat-ops')}>
                        <ArrowLeft className="h-4 w-4 mr-1" /> Back to Threat Ops
                      </Button>
                    </div>
                  </CardContent></Card>
                )}

                {/* ===== WORKFLOWS ===== */}
                {page === 'workflows' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-semibold">Workflows</h3>
                        <p className="text-sm text-muted-foreground">Design and automate security workflows visually</p>
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={() => openWorkflowBuilder()}>
                          <Plus className="h-4 w-4 mr-1" /> New Workflow
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                      {workflows.filter(w => !searchQuery || w.name.toLowerCase().includes(searchQuery.toLowerCase())).map(wf => (
                        <Card key={wf.id} className="hover:shadow-md transition-shadow group">
                          <CardHeader className="pb-2">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-2 min-w-0">
                                <div className={`p-1.5 rounded ${wf.status === 'active' ? 'bg-green-500/10 text-green-600' : wf.status === 'draft' ? 'bg-yellow-500/10 text-yellow-600' : 'bg-gray-500/10 text-gray-600'}`}>
                                  <GitBranch className="h-4 w-4" />
                                </div>
                                <div className="min-w-0">
                                  <CardTitle className="text-sm truncate">{wf.name}</CardTitle>
                                  <CardDescription className="text-xs truncate">{wf.description || 'No description'}</CardDescription>
                                </div>
                              </div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => openWorkflowBuilder(wf)}><Edit3 className="h-4 w-4 mr-2" /> Edit</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => executeWorkflow(wf.id)}><Play className="h-4 w-4 mr-2" /> Execute</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => { updateWorkflowStatus(wf.id, wf.status === 'active' ? 'draft' : 'active'); }}><Pause className="h-4 w-4 mr-2" /> {wf.status === 'active' ? 'Pause' : 'Activate'}</DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-red-600" onClick={() => deleteWorkflow(wf.id)}><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </CardHeader>
                          <CardContent className="pb-3">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex gap-1">
                                <Badge variant="outline" className={statusColor(wf.status)}>{wf.status}</Badge>
                                <Badge variant="outline" className="text-xs">{wf.nodes?.length || 0} nodes</Badge>
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-1 mb-3">
                              {wf.tags?.map((t, i) => (
                                <span key={i} className="text-[10px] px-1.5 py-0.5 bg-muted rounded text-muted-foreground">{t}</span>
                              ))}
                            </div>
                            <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                              <span>Updated {formatDate(wf.updatedAt)}</span>
                              <div className="flex gap-1">
                                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => executeWorkflow(wf.id)}>
                                  <Play className="h-3 w-3" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => openWorkflowBuilder(wf)}>
                                  <Edit3 className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* ===== WORKFLOW BUILDER ===== */}
                {page === 'workflow-builder' && editingWorkflow && (
                  <WorkflowBuilder
                    workflow={{
                      id: editingWorkflow.id,
                      name: editingWorkflow.name,
                      description: editingWorkflow.description,
                      status: editingWorkflow.status,
                      nodes: editingWorkflow.nodes.map(n => ({
                        id: n.id,
                        type: n.type as 'trigger' | 'action' | 'condition' | 'output',
                        subtype: (n.data.config?.subtype as string | undefined),
                        position: n.position,
                        data: {
                          label: n.data.label,
                          description: n.data.description,
                          config: n.data.config || {},
                        },
                      })),
                      edges: editingWorkflow.edges.map(e => ({
                        id: e.id,
                        source: e.source,
                        target: e.target,
                        label: e.label,
                      })),
                    }}
                    onChange={(wf) => {
                      setEditingWorkflow({
                        ...editingWorkflow,
                        name: wf.name,
                        description: wf.description,
                        status: wf.status,
                        nodes: wf.nodes.map(n => ({
                          id: n.id,
                          type: n.type,
                          position: n.position,
                          data: {
                            label: n.data.label,
                            description: n.data.description,
                            config: { ...n.data.config, subtype: n.subtype },
                          },
                        })),
                        edges: wf.edges.map(e => ({
                          id: e.id,
                          source: e.source,
                          target: e.target,
                          label: e.label,
                        })),
                      });
                    }}
                    onSave={saveWorkflow}
                    onBack={() => { setPage('workflows'); setEditingWorkflow(null); }}
                    onExecute={() => executeWorkflow(editingWorkflow.id)}
                  />
                )}

                {/* ===== CASES ===== */}
                {page === 'cases' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-semibold">Case Management</h3>
                        <p className="text-sm text-muted-foreground">Track and manage security incidents</p>
                      </div>
                      <Dialog open={showNewCase} onOpenChange={setShowNewCase}>
                        <DialogTrigger asChild>
                          <Button><Plus className="h-4 w-4 mr-1" /> New Case</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Create New Case</DialogTitle>
                            <DialogDescription>Open a new security incident case</DialogDescription>
                          </DialogHeader>
                          <NewCaseForm onSubmit={async (data) => { await fetch('/api/cases', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }); fetchCases(); fetchDashboard(); setShowNewCase(false); }} />
                        </DialogContent>
                      </Dialog>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                      {cases.length === 0 && !loading && (
                        <Card className="lg:col-span-2 xl:col-span-3"><CardContent className="py-12 text-center text-sm text-muted-foreground">
                          <FolderOpen className="h-10 w-10 mx-auto mb-3 opacity-25" />
                          No cases yet. Create a new case or trigger a workflow that creates cases automatically.
                        </CardContent></Card>
                      )}
                      {cases.filter(c => !searchQuery || c.title.toLowerCase().includes(searchQuery.toLowerCase())).map(c => (
                        <Card key={c.id} className="hover:shadow-md transition-shadow flex flex-col" data-interactive-card>
                          <CardHeader className="pb-2">
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0">
                                <CardTitle className="text-sm truncate">{c.title}</CardTitle>
                                <CardDescription className="text-xs line-clamp-2">{c.description}</CardDescription>
                              </div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" data-ui-button><MoreVertical className="h-4 w-4" /></Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => { setSelectedIncidentId(c.id); setPage('incident-detail'); }}><ExternalLink className="h-4 w-4 mr-2" /> View Incident Detail</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => updateCaseStatus(c.id, c.status === 'open' ? 'investigating' : c.status === 'investigating' ? 'contained' : c.status === 'contained' ? 'closed' : 'open')}>
                                    <RotateCcw className="h-4 w-4 mr-2" /> Change Status
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-red-600" onClick={() => deleteCase(c.id)}><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </CardHeader>
                          <CardContent className="pb-3 flex-1 flex flex-col">
                            <div className="flex flex-wrap gap-1 mb-2">
                              <Badge variant="outline" className={severityColor(c.severity)}>{c.severity}</Badge>
                              <Badge variant="outline" className={statusColor(c.status)}>{c.status}</Badge>
                              {c.assignee && <Badge variant="outline" className="bg-purple-500/10 text-purple-600 border-purple-500/20"><User className="h-3 w-3 mr-1" />{c.assignee}</Badge>}
                            </div>
                            <div className="flex flex-wrap gap-1 mb-2">
                              {c.tags?.map((t, i) => <span key={i} className="text-[10px] px-1.5 py-0.5 bg-muted rounded text-muted-foreground">{t}</span>)}
                            </div>
                            {/* Timeline */}
                            {c.timeline && c.timeline.length > 0 && (
                              <div className="border-t border-border pt-2 mt-2">
                                <p className="text-[10px] font-medium text-muted-foreground mb-1.5 flex items-center gap-1">
                                  <Clock className="h-2.5 w-2.5" /> Timeline
                                </p>
                                <div className="space-y-1 max-h-24 overflow-y-auto">
                                  {c.timeline.slice(-3).map((t, i) => (
                                    <div key={i} className="flex items-start gap-1.5 text-[10px]">
                                      <CircleDot className="h-2.5 w-2.5 mt-0.5 text-primary shrink-0" />
                                      <span className="text-muted-foreground">{new Date(t.time).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })} - {t.event}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                            {c.artifacts && c.artifacts.length > 0 && (
                              <div className="flex items-center gap-1 mt-2 text-[10px] text-muted-foreground">
                                <FileText className="h-3 w-3" />
                                {c.artifacts.length} artifact{c.artifacts.length > 1 ? 's' : ''}
                              </div>
                            )}
                            <p className="text-[10px] text-muted-foreground mt-2 pt-2 border-t border-border/40 flex items-center gap-1">
                              <Clock className="h-2.5 w-2.5" />
                              Updated {formatDate(c.updatedAt)}
                            </p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* ===== ALERTS ===== */}
                {page === 'alerts' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-semibold">Alerts</h3>
                        <p className="text-sm text-muted-foreground">Security alerts from all connected sources</p>
                      </div>
                      <Dialog open={showNewAlert} onOpenChange={setShowNewAlert}>
                        <DialogTrigger asChild>
                          <Button><Plus className="h-4 w-4 mr-1" /> Create Alert</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader><DialogTitle>Create Manual Alert</DialogTitle><DialogDescription>Manually create a security alert</DialogDescription></DialogHeader>
                          <NewAlertForm onSubmit={async (data) => { await fetch('/api/alerts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }); fetchAlerts(); fetchDashboard(); setShowNewAlert(false); }} />
                        </DialogContent>
                      </Dialog>
                    </div>

                    {/* Alert Filters */}
                    <div className="flex gap-2 flex-wrap">
                      {['all', 'critical', 'high', 'medium', 'low'].map(f => (
                        <Button key={f} variant={searchQuery === f || (f === 'all' && !searchQuery) ? 'default' : 'outline'} size="sm" onClick={() => setSearchQuery(f === 'all' ? '' : f)}>
                          {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
                          {f !== 'all' && <span className="ml-1 text-[10px] opacity-70">({alerts.filter(a => a.severity === f).length})</span>}
                        </Button>
                      ))}
                    </div>

                    <div className="space-y-2">
                      {alerts.length === 0 && !loading && (
                        <Card><CardContent className="py-12 text-center text-sm text-muted-foreground">
                          <Bell className="h-10 w-10 mx-auto mb-3 opacity-25" />
                          No alerts. New alerts from connected integrations will appear here.
                        </CardContent></Card>
                      )}
                      {alerts.filter(a => !searchQuery || a.severity === searchQuery || a.title.toLowerCase().includes(searchQuery.toLowerCase())).map(alert => (
                        <Card key={alert.id} className="hover:shadow-md transition-shadow" data-interactive-card>
                          <CardContent className="p-4">
                            <div className="flex items-start gap-3">
                              <div className={`p-2 rounded-lg shrink-0 ${severityColor(alert.severity)}`}>
                                <AlertTriangle className="h-4 w-4" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-start justify-between gap-2">
                                  <div className="min-w-0">
                                    <h4 className="text-sm font-medium truncate">{alert.title}</h4>
                                    <p className="text-xs text-muted-foreground line-clamp-1">{alert.description}</p>
                                  </div>
                                  <div className="flex items-center gap-2 shrink-0">
                                    <Badge variant="outline" className={severityColor(alert.severity)}>{alert.severity}</Badge>
                                    <DropdownMenu>
                                      <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" size="icon" className="h-7 w-7" data-ui-button><MoreVertical className="h-4 w-4" /></Button>
                                      </DropdownMenuTrigger>
                                      <DropdownMenuContent align="end">
                                        <DropdownMenuItem onClick={() => { setSelectedIncidentId(alert.id); setPage('incident-detail'); }}><ExternalLink className="h-4 w-4 mr-2" /> View Incident Detail</DropdownMenuItem>
                                        <DropdownMenuItem onClick={() => updateAlertStatus(alert.id, 'investigating')}><Eye className="h-4 w-4 mr-2" /> Investigate</DropdownMenuItem>
                                        <DropdownMenuItem onClick={() => updateAlertStatus(alert.id, 'resolved')}><CheckCircle2 className="h-4 w-4 mr-2" /> Resolve</DropdownMenuItem>
                                        <DropdownMenuItem onClick={() => updateAlertStatus(alert.id, 'new')}><RotateCcw className="h-4 w-4 mr-2" /> Reopen</DropdownMenuItem>
                                        <DropdownMenuSeparator />
                                        <DropdownMenuItem className="text-red-600" onClick={() => deleteAlert(alert.id)}><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                                      </DropdownMenuContent>
                                    </DropdownMenu>
                                  </div>
                                </div>
                                <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground flex-wrap">
                                  <span className="flex items-center gap-1"><Radar className="h-3 w-3" /> {alert.source}</span>
                                  <Badge variant="outline" className={statusColor(alert.status)}>{alert.status}</Badge>
                                  {alert.assignee && <span className="flex items-center gap-1"><User className="h-3 w-3" /> {alert.assignee}</span>}
                                  <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {formatDate(alert.createdAt)}</span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* ===== INTEGRATIONS ===== */}
                {page === 'integrations' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-semibold">Integrations</h3>
                        <p className="text-sm text-muted-foreground">Connect security tools and data sources — set real API keys here</p>
                      </div>
                      <div className="flex gap-2 items-center">
                        <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20">
                          {metrics?.connectedIntegrations || 0} Connected
                        </Badge>
                        <Dialog open={showNewIntegration} onOpenChange={setShowNewIntegration}>
                          <DialogTrigger asChild>
                            <Button size="sm" data-ui-button>
                              <Plus className="h-4 w-4 mr-1" /> Add Integration
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-md">
                            <DialogHeader>
                              <DialogTitle>Add Integration</DialogTitle>
                              <DialogDescription>Pick a connector type. You'll set credentials after it's created.</DialogDescription>
                            </DialogHeader>
                            <NewIntegrationForm
                              onSubmit={async (data) => {
                                try {
                                  const res = await fetch('/api/integrations', {
                                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify(data),
                                  });
                                  if (!res.ok) {
                                    const err = await res.json().catch(() => ({ error: 'Unknown' }));
                                    toast({ title: 'Failed to create', description: err.error, variant: 'destructive' });
                                    return;
                                  }
                                  toast({ title: 'Integration created', description: `${data.name} added — configure credentials next.` });
                                  fetchIntegrations();
                                  fetchDashboard();
                                  setShowNewIntegration(false);
                                } catch (e) {
                                  toast({ title: 'Error', description: String(e), variant: 'destructive' });
                                }
                              }}
                            />
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>

                    {/* Categories */}
                    <div className="flex gap-2 flex-wrap">
                      {['all', 'security', 'network', 'communication', 'cloud', 'endpoint', 'iam'].map(cat => (
                        <Button key={cat} variant={searchQuery === cat || (cat === 'all' && !searchQuery) ? 'default' : 'outline'} size="sm" onClick={() => setSearchQuery(cat === 'all' ? '' : cat)}>
                          {cat === 'all' ? 'All' : cat === 'iam' ? 'Identity' : cat.charAt(0).toUpperCase() + cat.slice(1)}
                        </Button>
                      ))}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                      {integrations.length === 0 && !loading && (
                        <Card className="md:col-span-2 xl:col-span-3">
                          <CardContent className="py-12 text-center text-sm text-muted-foreground">
                            <Puzzle className="h-10 w-10 mx-auto mb-3 opacity-25" />
                            No integrations configured yet. Click "Reset Demo Data" in Settings to seed sample integrations.
                          </CardContent>
                        </Card>
                      )}
                      {integrations.filter(i => !searchQuery || i.category === searchQuery || i.name.toLowerCase().includes(searchQuery.toLowerCase())).map(int => (
                        <Card key={int.id} className="hover:shadow-md transition-all duration-200 group" data-interactive-card>
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center gap-3 min-w-0">
                                <div className={`p-2.5 rounded-xl shrink-0 ${int.status === 'connected' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : int.status === 'error' ? 'bg-red-500/10 text-red-500 dark:text-red-400' : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'} transition-transform group-hover:scale-105`}>
                                  {getIconForIntegration(int.icon)}
                                </div>
                                <div className="min-w-0">
                                  <h4 className="text-sm font-medium truncate">{int.name}</h4>
                                  <p className="text-[10px] text-muted-foreground capitalize truncate">{int.type} - {int.category}</p>
                                </div>
                              </div>
                              <Badge variant="outline" className={`shrink-0 ${statusColor(int.status)}`}>
                                {int.status === 'connected' && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 mr-1 pulse-dot" />}
                                {int.status}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground mb-3 line-clamp-2 min-h-[2rem]">{int.description}</p>
                            <div className="flex items-center justify-between gap-2 pt-2 border-t border-border/60">
                              <span className="text-[10px] text-muted-foreground capitalize flex items-center gap-1">
                                <Tag className="h-2.5 w-2.5" />
                                {int.category}
                              </span>
                              <div className="flex gap-1.5">
                                <Button variant="outline" size="sm" onClick={() => setConfiguringIntegration(int.id)} data-ui-button>
                                  <Settings className="h-3 w-3 mr-1" /> Configure
                                </Button>
                                <Button
                                  variant="default"
                                  size="sm"
                                  onClick={async () => {
                                    try {
                                      setTestingId(int.id);
                                      const res = await fetch('/api/integrations/test', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: int.id }) });
                                      const data = await res.json();
                                      toast({ title: data.ok ? 'Connected' : 'Test Failed', description: data.message, variant: data.ok ? 'default' : 'destructive' });
                                      fetchIntegrations(); fetchDashboard();
                                    } catch (e) {
                                      toast({ title: 'Test error', description: String(e), variant: 'destructive' });
                                    } finally {
                                      setTestingId(null);
                                    }
                                  }}
                                  disabled={testingId === int.id}
                                  data-ui-button
                                >
                                  {testingId === int.id ? <Activity className="h-3 w-3 mr-1 animate-pulse" /> : <Zap className="h-3 w-3 mr-1" />}
                                  Test
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-muted-foreground hover:text-destructive"
                                  onClick={async () => {
                                    if (!confirm(`Delete integration "${int.name}"? This cannot be undone.`)) return;
                                    try {
                                      await fetch(`/api/integrations?id=${int.id}`, { method: 'DELETE' });
                                      toast({ title: 'Integration deleted' });
                                      fetchIntegrations(); fetchDashboard();
                                    } catch (e) {
                                      toast({ title: 'Delete failed', description: String(e), variant: 'destructive' });
                                    }
                                  }}
                                  data-ui-button
                                  aria-label="Delete integration"
                                >
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* ===== PLAYBOOKS ===== */}
                {page === 'playbooks' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-semibold">Playbooks</h3>
                        <p className="text-sm text-muted-foreground">Predefined response procedures linked to executable workflows</p>
                      </div>
                      <Dialog open={showNewPlaybook} onOpenChange={setShowNewPlaybook}>
                        <DialogTrigger asChild>
                          <Button><Plus className="h-4 w-4 mr-1" /> New Playbook</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader><DialogTitle>Create Playbook</DialogTitle><DialogDescription>Define a new response playbook</DialogDescription></DialogHeader>
                          <NewPlaybookForm onSubmit={async (data) => { await fetch('/api/playbooks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }); fetchPlaybooks(); fetchDashboard(); setShowNewPlaybook(false); }} />
                        </DialogContent>
                      </Dialog>
                    </div>

                    <div className="space-y-4">
                      {playbooks.length === 0 && !loading && (
                        <Card><CardContent className="py-12 text-center text-sm text-muted-foreground">
                          <BookOpen className="h-10 w-10 mx-auto mb-3 opacity-25" />
                          No playbooks yet. Create a new playbook to define an automated response procedure.
                        </CardContent></Card>
                      )}
                      {playbooks.filter(p => !searchQuery || p.name.toLowerCase().includes(searchQuery.toLowerCase())).map(pb => {
                        // Resolve linked workflow object (if any) so we can show its name + status
                        const linkedWf = pb.workflowId ? workflows.find(w => w.id === pb.workflowId) : null;
                        return (
                          <Card key={pb.id} className="hover:shadow-md transition-shadow" data-interactive-card>
                            <CardContent className="p-5">
                              <div className="flex items-start justify-between mb-3 gap-3">
                                <div className="flex items-center gap-3 min-w-0">
                                  <div className="p-2.5 rounded-xl bg-primary/10 text-primary shrink-0">
                                    <BookOpen className="h-5 w-5" />
                                  </div>
                                  <div className="min-w-0">
                                    <h4 className="font-medium truncate">{pb.name}</h4>
                                    <p className="text-xs text-muted-foreground line-clamp-1">{pb.description}</p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  {/* Run button — primary CTA. Disabled if no workflow linked. */}
                                  <Button
                                    size="sm"
                                    variant="default"
                                    disabled={!pb.workflowId}
                                    onClick={() => setRunningPlaybook(pb)}
                                    data-ui-button
                                    title={pb.workflowId ? 'Run linked workflow' : 'Link a workflow to enable execution'}
                                  >
                                    <Play className="h-3.5 w-3.5 mr-1" /> Run
                                  </Button>
                                  <Badge variant="outline" className={statusColor(pb.status)}>{pb.status}</Badge>
                                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 hidden sm:inline-flex">{pb.category.replace('_', ' ')}</Badge>
                                  <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                      <Button variant="ghost" size="icon" className="h-7 w-7" data-ui-button><MoreVertical className="h-4 w-4" /></Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end">
                                      <DropdownMenuItem onClick={() => duplicatePlaybook(pb.id)}><Copy className="h-4 w-4 mr-2" /> Duplicate</DropdownMenuItem>
                                      <DropdownMenuItem onClick={() => togglePlaybookStatus(pb.id, pb.status)}><Pause className="h-4 w-4 mr-2" /> {pb.status === 'active' ? 'Deactivate' : 'Activate'}</DropdownMenuItem>
                                      {pb.workflowId && linkedWf && (
                                        <DropdownMenuItem onClick={() => openWorkflowBuilder(linkedWf)}>
                                          <Edit3 className="h-4 w-4 mr-2" /> Edit Workflow
                                        </DropdownMenuItem>
                                      )}
                                      <DropdownMenuItem onClick={() => setLinkingPlaybookId(pb.id)}>
                                        <Link2 className="h-4 w-4 mr-2" /> {pb.workflowId ? 'Change linked workflow' : 'Link workflow'}
                                      </DropdownMenuItem>
                                      <DropdownMenuSeparator />
                                      <DropdownMenuItem className="text-red-600" onClick={() => deletePlaybook(pb.id)}><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                                    </DropdownMenuContent>
                                  </DropdownMenu>
                                </div>
                              </div>

                              {/* Linked Workflow Banner */}
                              <div className={`mb-3 p-2 rounded-md border text-xs flex items-center gap-2 ${pb.workflowId ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-700 dark:text-emerald-300' : 'bg-amber-500/5 border-amber-500/20 text-amber-700 dark:text-amber-300'}`}>
                                {pb.workflowId ? (
                                  <>
                                    <GitBranch className="h-3.5 w-3.5 shrink-0" />
                                    <span className="truncate">
                                      Linked workflow: <span className="font-medium">{linkedWf?.name || '(deleted)'}</span>
                                      {linkedWf && <span className="text-muted-foreground"> · {linkedWf.status}</span>}
                                    </span>
                                  </>
                                ) : (
                                  <>
                                    <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                                    <span>Documentation-only — link a workflow to enable the Run button.</span>
                                  </>
                                )}
                              </div>

                              {/* Steps */}
                              <div className="mt-4">
                                <h5 className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1.5">
                                  <Activity className="h-3 w-3" />
                                  Response Steps ({pb.steps?.length || 0})
                                </h5>
                                <div className="flex gap-2 overflow-x-auto pb-2">
                                  {pb.steps?.map((step, i) => (
                                    <div key={i} className="flex items-center gap-2 shrink-0">
                                      <div className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border bg-muted/30 min-w-[140px] hover:border-primary/30 transition-colors">
                                        <span className="flex items-center justify-center h-5 w-5 rounded-full bg-primary/10 text-primary text-[10px] font-bold shrink-0">{step.order}</span>
                                        <div className="min-w-0">
                                          <p className="text-xs font-medium truncate">{step.name}</p>
                                          <Badge variant="outline" className={`text-[8px] px-1 py-0 ${step.automation === 'auto' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : step.automation === 'semi-auto' ? 'bg-amber-500/10 text-amber-600 border-amber-500/20' : 'bg-blue-500/10 text-blue-600 border-blue-500/20'}`}>
                                            {step.automation}
                                          </Badge>
                                        </div>
                                      </div>
                                      {i < pb.steps.length - 1 && <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />}
                                    </div>
                                  ))}
                                  {(!pb.steps || pb.steps.length === 0) && (
                                    <p className="text-[11px] text-muted-foreground italic px-2 py-2">No steps defined yet.</p>
                                  )}
                                </div>
                              </div>

                              {/* Triggers & Tags */}
                              <div className="flex items-center justify-between mt-3 pt-3 border-t border-border gap-2 flex-wrap">
                                <div className="flex items-center gap-2 min-w-0">
                                  <Zap className="h-3 w-3 text-amber-500 shrink-0" />
                                  <span className="text-[10px] text-muted-foreground truncate">Triggers: <span className="font-medium text-foreground">{pb.triggers?.map(t => t.type).join(', ') || 'none'}</span></span>
                                </div>
                                <div className="flex gap-1 flex-wrap">
                                  {pb.tags?.map((t, i) => <span key={i} className="text-[10px] px-1.5 py-0.5 bg-muted rounded text-muted-foreground">{t}</span>)}
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* ===== SETTINGS ===== */}
                {page === 'settings' && (
                  <SettingsView darkMode={darkMode} setDarkMode={setDarkMode} metrics={metrics} onResetData={async () => { await seedData({ force: true }); await Promise.all([fetchDashboard(), fetchWorkflows(), fetchCases(), fetchIntegrations(), fetchPlaybooks(), fetchAlerts()]); toast({ title: 'Data reset', description: 'Demo data re-seeded.' }); }} />
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Integration Config Modal */}
      <IntegrationConfigModal
        integrationId={configuringIntegration}
        onClose={() => setConfiguringIntegration(null)}
        onSaved={async () => { fetchIntegrations(); fetchDashboard(); setConfiguringIntegration(null); toast({ title: 'Saved', description: 'Integration config updated' }); }}
      />

      {/* Playbook → Workflow Link Dialog */}
      <LinkWorkflowDialog
        playbookId={linkingPlaybookId}
        workflows={workflows}
        currentWorkflowId={linkingPlaybookId ? playbooks.find(p => p.id === linkingPlaybookId)?.workflowId ?? null : null}
        onClose={() => setLinkingPlaybookId(null)}
        onLink={async (workflowId) => {
          if (linkingPlaybookId) {
            await linkPlaybookWorkflow(linkingPlaybookId, workflowId);
          }
          setLinkingPlaybookId(null);
        }}
      />

      {/* Playbook Run Dialog — lets the user supply a trigger payload before
          executing the linked workflow. Without this, nodes that reference
          {{trigger.ip}} etc. would always receive an empty trigger. */}
      <RunPlaybookDialog
        playbook={runningPlaybook}
        workflow={runningPlaybook ? workflows.find(w => w.id === runningPlaybook.workflowId) ?? null : null}
        onClose={() => setRunningPlaybook(null)}
        onRun={async (payload) => {
          if (runningPlaybook) {
            await executePlaybook(runningPlaybook, payload);
            setRunningPlaybook(null);
            // Switch to workflow builder view so the user can see live logs
            if (runningPlaybook.workflowId) {
              const wf = workflows.find(w => w.id === runningPlaybook.workflowId);
              if (wf) {
                setEditingWorkflow(wf);
                setPage('workflow-builder');
              }
            }
          }
        }}
      />
    </TooltipProvider>
  );
}

// ========== RUN PLAYBOOK DIALOG ==========
// Modal that asks for a JSON trigger payload before running the playbook's
// linked workflow. Provides sensible defaults based on the workflow's nodes
// (e.g. if a node references {{trigger.ip}}, prefill {"ip": ""}).
function RunPlaybookDialog({
  playbook, workflow, onClose, onRun,
}: {
  playbook: Playbook | null;
  workflow: Workflow | null;
  onClose: () => void;
  onRun: (payload: Record<string, unknown>) => Promise<void>;
}) {
  const [payloadText, setPayloadText] = useState('{}');
  const [running, setRunning] = useState(false);
  const { toast } = useToast();

  // When a new playbook is selected, infer a sensible default payload by
  // scanning the workflow's nodes for {{trigger.X}} references.
  useEffect(() => {
    if (!playbook || !workflow) return;
    try {
      const nodes: { data?: { config?: Record<string, unknown> } }[] =
        typeof workflow.nodes === 'string' ? JSON.parse(workflow.nodes as string) : (workflow.nodes as unknown[]) || [];
      const triggerKeys = new Set<string>();
      const nodeStr = JSON.stringify(nodes);
      const re = /\{\{\s*trigger\.([a-zA-Z_][a-zA-Z0-9_]*)/g;
      let m: RegExpExecArray | null;
      while ((m = re.exec(nodeStr)) !== null) {
        triggerKeys.add(m[1]);
      }
      const defaultPayload: Record<string, string> = {};
      // Pre-fill common trigger keys with example values so the user just hits Run
      const examples: Record<string, string> = {
        ip: '8.8.8.8',
        hash: '',
        domain: 'example.com',
        url: 'https://example.com',
        email: 'user@example.com',
        severity: 'high',
        source: 'manual',
        title: `Manual run: ${playbook.name}`,
      };
      triggerKeys.forEach(k => {
        defaultPayload[k] = examples[k] !== undefined ? examples[k] : '';
      });
      setPayloadText(JSON.stringify(defaultPayload, null, 2));
    } catch {
      setPayloadText('{}');
    }
  }, [playbook, workflow]);

  if (!playbook) return null;

  const handleRun = async () => {
    let payload: Record<string, unknown> = {};
    try {
      payload = payloadText.trim() ? JSON.parse(payloadText) : {};
    } catch {
      toast({ title: 'Invalid JSON', description: 'Please fix the trigger payload and try again.', variant: 'destructive' });
      return;
    }
    setRunning(true);
    try {
      await onRun(payload);
    } finally { setRunning(false); }
  };

  return (
    <Dialog open={!!playbook} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Play className="h-4 w-4" /> Run Playbook: {playbook.name}
          </DialogTitle>
          <DialogDescription>
            {workflow
              ? <>Will execute workflow <span className="font-medium text-foreground">{workflow.name}</span>. Provide trigger data below.</>
              : 'No workflow linked — link one first.'}
          </DialogDescription>
        </DialogHeader>

        {workflow ? (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Trigger Payload (JSON)</Label>
              <Textarea
                value={payloadText}
                onChange={e => setPayloadText(e.target.value)}
                className="mt-1 text-xs font-mono min-h-[120px]"
                placeholder='{"ip": "8.8.8.8"}'
              />
            </div>
            <div className="p-2 bg-muted/50 rounded text-[11px] text-muted-foreground flex items-start gap-2">
              <Lightbulb className="h-3.5 w-3.5 shrink-0 mt-0.5 text-amber-500" aria-hidden />
              <span>Nodes in this workflow can reference these values via <code>{`{{trigger.ip}}`}</code>, <code>{`{{trigger.domain}}`}</code>, etc.</span>
            </div>
          </div>
        ) : (
          <div className="p-3 bg-amber-500/10 rounded text-sm text-amber-700 dark:text-amber-300 border border-amber-500/20">
            This playbook has no linked workflow. Close this dialog and use "Link workflow" first.
          </div>
        )}

        <DialogFooter className="gap-2">
          <Button variant="outline" size="sm" onClick={onClose} data-ui-button>Cancel</Button>
          <Button size="sm" disabled={!workflow || running} onClick={handleRun} data-ui-button>
            {running ? <Activity className="h-3 w-3 mr-1 animate-pulse" /> : <Play className="h-3 w-3 mr-1" />}
            {running ? 'Starting...' : 'Run Workflow'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ========== INTEGRATION CONFIG MODAL ==========
function IntegrationConfigModal({ integrationId, onClose, onSaved }: { integrationId: string | null; onClose: () => void; onSaved: () => void }) {
  const [integration, setIntegration] = useState<any>(null);
  const [configForm, setConfigForm] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (!integrationId) return;
    setLoading(true);
    fetch(`/api/integrations/${integrationId}`)
      .then(r => r.json())
      .then(data => {
        setIntegration(data);
        const cfg = typeof data.config === 'string' ? JSON.parse(data.config || '{}') : (data.config || {});
        setConfigForm(Object.fromEntries(Object.entries(cfg).map(([k, v]) => [k, String(v)])));
      })
      .finally(() => setLoading(false));
  }, [integrationId]);

  if (!integrationId) return null;

  // Field schemas per integration type — used by both the config modal and the test endpoint
  // Each entry: { key, label, placeholder?, type? }
  const typeFields: Record<string, { key: string; label: string; placeholder?: string; type?: 'text' | 'password' }[]> = {
    virustotal: [{ key: 'api_key', label: 'VirusTotal API Key', placeholder: 'abcdef1234567890abcdef1234567890...', type: 'password' }],
    abuseipdb: [{ key: 'api_key', label: 'AbuseIPDB API Key', placeholder: 'abcdef1234567890...', type: 'password' }],
    ipinfo: [{ key: 'token', label: 'IPInfo Token (optional)', placeholder: 'abcdef12345...' }],
    slack: [
      { key: 'webhook', label: 'Slack Webhook URL', placeholder: 'https://hooks.slack.com/services/T.../B.../...' },
      { key: 'channel', label: 'Default Channel (optional)', placeholder: '#soc-alerts' },
    ],
    email: [
      { key: 'smtp_host', label: 'SMTP Host (or use service below)', placeholder: 'smtp.gmail.com' },
      { key: 'service', label: 'Service (gmail|outlook|ses|zoho, optional)', placeholder: 'gmail' },
      { key: 'port', label: 'SMTP Port (465=SSL, 587=STARTTLS)', placeholder: '587' },
      { key: 'username', label: 'Username', placeholder: 'soc@corp.com' },
      { key: 'password', label: 'Password / App Password', type: 'password' },
      { key: 'from', label: 'From Address', placeholder: 'soar@corp.com' },
    ],
    jira: [
      { key: 'host', label: 'Jira Host', placeholder: 'acme.atlassian.net' },
      { key: 'email', label: 'User Email', placeholder: 'you@acme.com' },
      { key: 'api_token', label: 'API Token', type: 'password' },
    ],
    pagerduty: [
      { key: 'api_key', label: 'API Key (Token)', type: 'password' },
      { key: 'routing_key', label: 'Integration Routing Key', type: 'password', placeholder: 'used by trigger action' },
      { key: 'email', label: 'Default From Email', placeholder: 'soc@corp.com' },
    ],
    servicenow: [
      { key: 'host', label: 'Instance Host', placeholder: 'acme.service-now.com' },
      { key: 'username', label: 'Username' },
      { key: 'password', label: 'Password / API Token', type: 'password' },
    ],
    thehive: [
      { key: 'url', label: 'TheHive URL', placeholder: 'http://thehive.local:9000' },
      { key: 'api_key', label: 'API Key', type: 'password' },
    ],
    misp: [
      { key: 'url', label: 'MISP URL', placeholder: 'https://misp.corp.local' },
      { key: 'api_key', label: 'API Key', type: 'password' },
    ],
    opencti: [
      { key: 'url', label: 'OpenCTI URL', placeholder: 'https://opencti.corp.local' },
      { key: 'api_key', label: 'API Key', type: 'password' },
    ],
    wazuh: [
      { key: 'host', label: 'Manager Host', placeholder: 'wazuh.corp.local' },
      { key: 'port', label: 'API Port', placeholder: '55000' },
      { key: 'username', label: 'Username', placeholder: 'wazuh' },
      { key: 'password', label: 'Password', type: 'password' },
    ],
    splunk: [
      { key: 'host', label: 'Splunk Host', placeholder: 'splunk.corp.local' },
      { key: 'port', label: 'MGMT Port', placeholder: '8089' },
      { key: 'username', label: 'Username' },
      { key: 'password', label: 'Password', type: 'password' },
    ],
    elastic: [
      { key: 'url', label: 'Elastic URL', placeholder: 'https://elastic.corp.local:9200' },
      { key: 'username', label: 'Username (optional)' },
      { key: 'password', label: 'Password (optional)', type: 'password' },
      { key: 'api_key', label: 'API Key (optional, alternative to user/pass)', type: 'password' },
    ],
    msgraph: [
      { key: 'tenant_id', label: 'Azure Tenant ID' },
      { key: 'client_id', label: 'App Client ID' },
      { key: 'client_secret', label: 'Client Secret', type: 'password' },
    ],
    fortigate: [
      { key: 'host', label: 'FortiGate Host', placeholder: 'firewall.corp.local' },
      { key: 'port', label: 'Port', placeholder: '443' },
      { key: 'api_key', label: 'API Key', type: 'password' },
      { key: 'vdom', label: 'VDOM', placeholder: 'root' },
    ],
    opnsense: [
      { key: 'host', label: 'OPNsense Host', placeholder: 'opnsense.corp.local' },
      { key: 'port', label: 'Port', placeholder: '443' },
      { key: 'api_key', label: 'API Key' },
      { key: 'api_secret', label: 'API Secret', type: 'password' },
    ],
    digitalocean: [
      { key: 'api_token', label: 'Personal Access Token', type: 'password' },
    ],
    defectdojo: [
      { key: 'url', label: 'DefectDojo URL', placeholder: 'https://dd.corp.local' },
      { key: 'api_key', label: 'API Key', type: 'password' },
    ],
    otx: [
      { key: 'api_key', label: 'OTX API Key (optional - works anonymously without)', type: 'password' },
    ],
    velociraptor: [
      { key: 'url', label: 'Velociraptor URL', placeholder: 'https://vr.corp.local:8889' },
      { key: 'api_key', label: 'API Key', type: 'password' },
    ],
    webhook: [
      { key: 'url', label: 'Default Webhook URL', placeholder: 'https://example.com/webhook' },
      { key: 'auth_header', label: 'Authorization Header (optional)', type: 'password' },
    ],
    http: [
      { key: 'base_url', label: 'Base URL (optional)', placeholder: 'https://api.example.com' },
      { key: 'api_key', label: 'API Key (optional, sent as Bearer)', type: 'password' },
    ],
  };

  const name = (integration?.name || '').toLowerCase().replace(/[\s\-_]/g, '');
  const type = (integration?.type || '').toLowerCase();
  // Try exact type match first, then name-based fallback, then generic
  let fields = typeFields[type] || typeFields[name] || [];
  if (name.includes('virustotal')) fields = fields.length ? fields : typeFields.virustotal;
  else if (name.includes('abuseipdb')) fields = fields.length ? fields : typeFields.abuseipdb;
  else if (name.includes('ipinfo')) fields = fields.length ? fields : typeFields.ipinfo;
  else if (name.includes('slack')) fields = fields.length ? fields : typeFields.slack;
  else if (name.includes('jira')) fields = fields.length ? fields : typeFields.jira;
  else if (name.includes('pagerduty')) fields = fields.length ? fields : typeFields.pagerduty;
  else if (name.includes('servicenow')) fields = fields.length ? fields : typeFields.servicenow;
  else if (name.includes('thehive')) fields = fields.length ? fields : typeFields.thehive;
  else if (name.includes('misp')) fields = fields.length ? fields : typeFields.misp;
  else if (name.includes('opencti')) fields = fields.length ? fields : typeFields.opencti;
  else if (name.includes('wazuh')) fields = fields.length ? fields : typeFields.wazuh;
  else if (name.includes('splunk')) fields = fields.length ? fields : typeFields.splunk;
  else if (name.includes('elastic')) fields = fields.length ? fields : typeFields.elastic;
  else if (name.includes('msgraph') || name.includes('microsoft')) fields = fields.length ? fields : typeFields.msgraph;
  else if (name.includes('fortigate') || name.includes('fortios')) fields = fields.length ? fields : typeFields.fortigate;
  else if (name.includes('opnsense')) fields = fields.length ? fields : typeFields.opnsense;
  else if (name.includes('digitalocean')) fields = fields.length ? fields : typeFields.digitalocean;
  else if (name.includes('defectdojo')) fields = fields.length ? fields : typeFields.defectdojo;
  else if (name.includes('otx') || name.includes('alienvault')) fields = fields.length ? fields : typeFields.otx;
  else if (name.includes('velociraptor')) fields = fields.length ? fields : typeFields.velociraptor;
  // Generic fallback: show all existing config keys
  if (fields.length === 0) {
    for (const k of Object.keys(configForm)) {
      fields.push({ key: k, label: k.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()), type: k.toLowerCase().includes('key') || k.toLowerCase().includes('password') || k.toLowerCase().includes('secret') ? 'password' : 'text' });
    }
  }

  return (
    <Dialog open={!!integrationId} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Configure {integration?.name || 'Integration'}
          </DialogTitle>
          <DialogDescription>
            Set real credentials here. They are stored locally in SQLite and used by workflow nodes when this integration is referenced.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="py-8 text-center text-sm text-muted-foreground">Loading...</div>
        ) : (
          <div className="space-y-3">
            {fields.map(f => (
              <div key={f.key}>
                <Label className="text-xs">{f.label}</Label>
                <Input
                  type={f.type === 'password' ? 'password' : 'text'}
                  value={configForm[f.key] || ''}
                  onChange={e => setConfigForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                  placeholder={f.placeholder}
                  className="mt-1 text-xs font-mono"
                />
              </div>
            ))}
            {fields.length === 0 && (
              <p className="text-xs text-muted-foreground">No configurable fields for this integration.</p>
            )}

            <div className="p-2 bg-muted/50 rounded text-[11px] text-muted-foreground flex items-start gap-2">
              <Lightbulb className="h-3.5 w-3.5 shrink-0 mt-0.5 text-amber-500" aria-hidden />
              <span>In workflow node configs, reference values with <code>{`{{trigger.ip}}`}</code> or <code>{`{{outputs.n1.virustotal.ioc}}`}</code>. The integration API key is automatically loaded from here.</span>
            </div>
          </div>
        )}

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            size="sm"
            disabled={testing || !integration}
            onClick={async () => {
              setTesting(true);
              try {
                // Save first, then test
                await fetch(`/api/integrations/${integrationId}`, {
                  method: 'PUT',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ config: configForm }),
                });
                const res = await fetch('/api/integrations/test', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: integrationId, type: integration?.type, config: configForm, name: integration?.name }) });
                const data = await res.json();
                toast({ title: data.ok ? 'Test Passed' : 'Test Failed', description: data.message, variant: data.ok ? 'default' : 'destructive' });
              } catch (e) {
                toast({ title: 'Test error', description: String(e), variant: 'destructive' });
              } finally {
                setTesting(false);
              }
            }}
          >
            {testing ? <Activity className="h-3 w-3 mr-1 animate-pulse" /> : <Zap className="h-3 w-3 mr-1" />}
            Save & Test
          </Button>
          <Button
            size="sm"
            disabled={loading}
            onClick={async () => {
              await fetch(`/api/integrations/${integrationId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ config: configForm, status: 'connected' }),
              });
              onSaved();
            }}
          >
            <Save className="h-3 w-3 mr-1" /> Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ========== LINK WORKFLOW DIALOG ==========
// Lets the user pick which workflow backs a playbook. The chosen workflow
// is what actually runs when the user clicks "Run" on the playbook card.
function LinkWorkflowDialog({
  playbookId, workflows, currentWorkflowId, onClose, onLink,
}: {
  playbookId: string | null;
  workflows: Workflow[];
  currentWorkflowId: string | null;
  onClose: () => void;
  onLink: (workflowId: string | null) => Promise<void>;
}) {
  const [selected, setSelected] = useState<string | null>(currentWorkflowId);
  const [search, setSearch] = useState('');
  const [saving, setSaving] = useState(false);

  // Keep local selection in sync when the dialog opens for a different playbook
  useEffect(() => { setSelected(currentWorkflowId); setSearch(''); }, [playbookId, currentWorkflowId]);

  if (!playbookId) return null;

  const filtered = workflows.filter(w =>
    !search || w.name.toLowerCase().includes(search.toLowerCase()) || (w.description || '').toLowerCase().includes(search.toLowerCase())
  );

  const handleSave = async () => {
    setSaving(true);
    try { await onLink(selected); } finally { setSaving(false); }
  };

  return (
    <Dialog open={!!playbookId} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Link2 className="h-4 w-4" /> Link Workflow
          </DialogTitle>
          <DialogDescription>
            Pick the workflow that implements this playbook's automated steps. The playbook's "Run" button will execute this workflow.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search workflows..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-8 h-8 text-xs"
            />
          </div>

          <ScrollArea className="h-72 border rounded-md">
            <div className="p-1.5">
              {/* "None" option to unlink */}
              <button
                onClick={() => setSelected(null)}
                className={`w-full flex items-center gap-2 p-2 rounded-md text-left text-xs transition-colors ${selected === null ? 'bg-primary/10 border border-primary/30' : 'hover:bg-muted/50 border border-transparent'}`}
              >
                <div className="p-1.5 rounded bg-muted text-muted-foreground">
                  <X className="h-3.5 w-3.5" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">No workflow (documentation only)</p>
                  <p className="text-[10px] text-muted-foreground">Playbook steps will be shown but cannot be executed.</p>
                </div>
                {selected === null && <CheckCircle2 className="h-3.5 w-3.5 text-primary" />}
              </button>

              {filtered.length === 0 && (
                <div className="text-center py-8 text-xs text-muted-foreground">
                  <GitBranch className="h-8 w-8 mx-auto mb-2 opacity-25" />
                  No workflows found.
                </div>
              )}

              {filtered.map(w => (
                <button
                  key={w.id}
                  onClick={() => setSelected(w.id)}
                  className={`w-full flex items-center gap-2 p-2 rounded-md text-left text-xs transition-colors mt-1 ${selected === w.id ? 'bg-primary/10 border border-primary/30' : 'hover:bg-muted/50 border border-transparent'}`}
                >
                  <div className={`p-1.5 rounded ${w.status === 'active' ? 'bg-emerald-500/10 text-emerald-600' : 'bg-yellow-500/10 text-yellow-600'}`}>
                    <GitBranch className="h-3.5 w-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{w.name}</p>
                    <p className="text-[10px] text-muted-foreground truncate">
                      {w.description || 'No description'} · {w.nodes?.length || 0} nodes
                    </p>
                  </div>
                  <Badge variant="outline" className={`text-[9px] ${statusColor(w.status)}`}>{w.status}</Badge>
                  {selected === w.id && <CheckCircle2 className="h-3.5 w-3.5 text-primary shrink-0" />}
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>

        <DialogFooter>
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button size="sm" disabled={saving} onClick={handleSave}>
            <Save className="h-3.5 w-3.5 mr-1" /> {saving ? 'Saving...' : 'Save link'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ========== FORM COMPONENTS ==========
function NewCaseForm({ onSubmit }: { onSubmit: (data: Record<string, unknown>) => void }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [severity, setSeverity] = useState('medium');
  const [assignee, setAssignee] = useState('');

  return (
    <div className="space-y-4">
      <div><Label>Title</Label><Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Case title" /></div>
      <div><Label>Description</Label><Textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Case description" /></div>
      <div><Label>Severity</Label><Select value={severity} onValueChange={setSeverity}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="low">Low</SelectItem><SelectItem value="medium">Medium</SelectItem><SelectItem value="high">High</SelectItem><SelectItem value="critical">Critical</SelectItem></SelectContent></Select></div>
      <div><Label>Assignee</Label><Input value={assignee} onChange={e => setAssignee(e.target.value)} placeholder="Assign to..." /></div>
      <DialogFooter>
        <Button onClick={() => onSubmit({ title, description, severity, assignee: assignee || null })} disabled={!title}>Create Case</Button>
      </DialogFooter>
    </div>
  );
}

function NewAlertForm({ onSubmit }: { onSubmit: (data: Record<string, unknown>) => void }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [severity, setSeverity] = useState('medium');
  const [source, setSource] = useState('manual');

  return (
    <div className="space-y-4">
      <div><Label>Title</Label><Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Alert title" /></div>
      <div><Label>Description</Label><Textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Alert description" /></div>
      <div><Label>Severity</Label><Select value={severity} onValueChange={setSeverity}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="low">Low</SelectItem><SelectItem value="medium">Medium</SelectItem><SelectItem value="high">High</SelectItem><SelectItem value="critical">Critical</SelectItem></SelectContent></Select></div>
      <div><Label>Source</Label><Input value={source} onChange={e => setSource(e.target.value)} placeholder="Alert source" /></div>
      <DialogFooter>
        <Button onClick={() => onSubmit({ title, description, severity, source })} disabled={!title}>Create Alert</Button>
      </DialogFooter>
    </div>
  );
}

function NewPlaybookForm({ onSubmit }: { onSubmit: (data: Record<string, unknown>) => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('incident_response');

  return (
    <div className="space-y-4">
      <div><Label>Name</Label><Input value={name} onChange={e => setName(e.target.value)} placeholder="Playbook name" /></div>
      <div><Label>Description</Label><Textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Playbook description" /></div>
      <div><Label>Category</Label><Select value={category} onValueChange={setCategory}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="incident_response">Incident Response</SelectItem><SelectItem value="investigation">Investigation</SelectItem><SelectItem value="remediation">Remediation</SelectItem><SelectItem value="compliance">Compliance</SelectItem></SelectContent></Select></div>
      <DialogFooter>
        <Button onClick={() => onSubmit({ name, description, category })} disabled={!name}>Create Playbook</Button>
      </DialogFooter>
    </div>
  );
}

// Helper for workflow status update
async function updateWorkflowStatus(id: string, status: string) {
  await fetch('/api/workflows', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status }) });
}

// ========== SETTINGS VIEW ==========
interface SystemServiceStatus {
  ok: boolean;
  configured: boolean;
  latencyMs?: number;
  detail?: unknown;
}
interface SystemStatus {
  ok: boolean;
  uptime_sec: number;
  services: Record<string, SystemServiceStatus>;
  latency_ms?: number;
}

function SettingsView({ darkMode, setDarkMode, metrics, onResetData }: {
  darkMode: boolean;
  setDarkMode: (v: boolean) => void;
  metrics: DashboardMetrics | null;
  onResetData: () => Promise<void>;
}) {
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
  const [checking, setChecking] = useState(false);

  // Fetch on mount. The async call writes state through setters inside a microtask
  // (after the first await), so React 19's set-state-in-effect rule is satisfied:
  // the synchronous body of the effect does NOT call setState.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (cancelled) return;
      setChecking(true);
      try {
        const res = await fetch('/api/system/status');
        if (cancelled) return;
        if (res.ok) setSystemStatus(await res.json());
      } catch (e) { console.error('System status fetch error', e); }
      if (!cancelled) setChecking(false);
    })();
    return () => { cancelled = true; };
  }, []);

  // Expose an imperative refetch for the Refresh button. Re-implements the same
  // logic so the button works without re-running the mount effect.
  const refreshStatus = useCallback(async () => {
    setChecking(true);
    try {
      const res = await fetch('/api/system/status');
      if (res.ok) setSystemStatus(await res.json());
    } catch (e) { console.error('System status fetch error', e); }
    setChecking(false);
  }, []);

  const serviceLabel = (key: string) => {
    const map: Record<string, string> = {
      database: 'Prisma Database',
      mongodb: 'MongoDB',
      external_backend: 'External Backend',
    };
    return map[key] || key;
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h3 className="text-lg font-semibold">Settings</h3>
        <p className="text-sm text-muted-foreground">Configure your SOAR platform and monitor connected services</p>
      </div>

      {/* Service Status */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <div>
            <CardTitle className="text-sm">Service Status</CardTitle>
            <CardDescription className="text-xs">Real-time connectivity to backing services</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={refreshStatus} disabled={checking}>
            <RefreshCw className={`h-3.5 w-3.5 mr-1 ${checking ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </CardHeader>
        <CardContent className="space-y-3">
          {!systemStatus ? (
            <div className="space-y-2">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-12 bg-muted animate-pulse rounded" />
              ))}
            </div>
          ) : (
            <>
              {Object.entries(systemStatus.services).map(([key, svc]) => (
                <div key={key} className="flex items-center justify-between p-3 rounded-md border bg-card">
                  <div className="flex items-center gap-3">
                    <div className={`h-2 w-2 rounded-full ${svc.ok ? 'bg-green-500 pulse-dot' : svc.configured ? 'bg-red-500' : 'bg-muted-foreground/40'}`} />
                    <div>
                      <p className="text-sm font-medium">{serviceLabel(key)}</p>
                      <p className="text-xs text-muted-foreground">
                        {svc.ok ? `Connected${svc.latencyMs ? ` · ${svc.latencyMs}ms` : ''}` :
                         svc.configured ? 'Configured but not reachable' :
                         'Not configured (optional)'}
                      </p>
                    </div>
                  </div>
                  <Badge variant="outline" className={
                    svc.ok ? 'bg-green-500/10 text-green-600 border-green-500/20' :
                    svc.configured ? 'bg-red-500/10 text-red-600 border-red-500/20' :
                    'bg-muted text-muted-foreground'
                  }>
                    {svc.ok ? 'OK' : svc.configured ? 'DOWN' : 'OFF'}
                  </Badge>
                </div>
              ))}
              <div className="text-xs text-muted-foreground pt-1 border-t">
                Platform uptime: {Math.floor(systemStatus.uptime_sec / 60)}m {systemStatus.uptime_sec % 60}s ·
                Check latency: {systemStatus.latency_ms}ms
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-sm">Appearance</CardTitle></CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Dark Mode</p>
              <p className="text-xs text-muted-foreground">Toggle between light and dark themes (persisted)</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setDarkMode(!darkMode)}>
              {darkMode ? <Sun className="h-4 w-4 mr-1" /> : <Moon className="h-4 w-4 mr-1" />}
              {darkMode ? 'Light' : 'Dark'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-sm">Platform Info</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Version</span><span>1.0.0</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Workflows</span><span>{metrics?.totalWorkflows || 0}</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Cases</span><span>{metrics?.totalCases || 0}</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Alerts</span><span>{metrics?.totalAlerts || 0}</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Integrations</span><span>{metrics?.connectedIntegrations || 0} connected</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Playbooks</span><span>{metrics?.totalPlaybooks || 0}</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Primary DB</span><span>SQLite (Prisma)</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Secondary DB</span><span>MongoDB (optional)</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">External Backend</span><span>Node.js + Express (optional)</span></div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-sm">Architecture</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-xs text-muted-foreground">
          <p><span className="font-medium text-foreground">Next.js (this app)</span> — primary web UI + API + workflow engine. Prisma/SQLite holds authoritative relational state (workflows, cases, integrations, alerts, audit).</p>
          <p><span className="font-medium text-foreground">MongoDB</span> — optional high-volume document store. Used for execution traces, raw alert payloads, connector call samples, and external sync mirror. Enabled when MONGODB_URI is set.</p>
          <p><span className="font-medium text-foreground">External Backend</span> — separate Node.js + Express service (mini-services/soar-backend) that exposes incidents / assets / threat intel / SOAR event ingestion APIs. Enabled when NEXT_PUBLIC_EXTERNAL_API_URL is set. Calls are best-effort and never block the main app.</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-sm">Data Management</CardTitle></CardHeader>
        <CardContent>
          <Button variant="outline" onClick={onResetData}>
            <RefreshCw className="h-4 w-4 mr-1" /> Reset Demo Data
          </Button>
          <p className="text-xs text-muted-foreground mt-2">Re-seeds integrations, workflows, cases, alerts, playbooks, MITRE ATT&CK patterns, roles, and permissions.</p>
        </CardContent>
      </Card>
    </div>
  );
}

// ========== NEW INTEGRATION FORM ==========
// Lets the user create a brand new integration by picking from the catalog of
// supported connector types. After creation they configure credentials via the
// standard "Configure" modal.
const INTEGRATION_CATALOG: { type: string; name: string; category: string; description: string; icon: string }[] = [
  // Threat Intel
  { type: 'virustotal', name: 'VirusTotal', category: 'security', description: 'Real-time malware & IOC reputation (IP/hash/domain/url)', icon: 'shield' },
  { type: 'abuseipdb', name: 'AbuseIPDB', category: 'security', description: 'IP abuse confidence score', icon: 'bug' },
  { type: 'ipinfo', name: 'IPInfo', category: 'security', description: 'IP geolocation & ASN (FREE - no key required)', icon: 'globe' },
  { type: 'otx', name: 'AlienVault OTX', category: 'security', description: 'Open Threat Exchange pulses', icon: 'radar' },
  { type: 'misp', name: 'MISP', category: 'security', description: 'Open-source threat intel platform', icon: 'database' },
  { type: 'opencti', name: 'OpenCTI', category: 'security', description: 'Open-source CTI platform (GraphQL)', icon: 'database' },
  // SIEM
  { type: 'splunk', name: 'Splunk', category: 'security', description: 'Enterprise SIEM - SPL searches via REST', icon: 'radar' },
  { type: 'elastic', name: 'Elasticsearch', category: 'security', description: 'Search logs via _search API', icon: 'database' },
  { type: 'wazuh', name: 'Wazuh', category: 'security', description: 'Open-source SIEM & XDR', icon: 'radar' },
  // ITSM
  { type: 'jira', name: 'Jira', category: 'communication', description: 'Create issues + comments', icon: 'ticket' },
  { type: 'servicenow', name: 'ServiceNow', category: 'communication', description: 'Create/query incidents', icon: 'ticket' },
  { type: 'pagerduty', name: 'PagerDuty', category: 'communication', description: 'Trigger/ack/resolve incidents', icon: 'bell' },
  { type: 'thehive', name: 'TheHive', category: 'security', description: 'Create cases + observables', icon: 'shield' },
  { type: 'defectdojo', name: 'DefectDojo', category: 'security', description: 'List/create findings + engagements', icon: 'bug' },
  // Cloud
  { type: 'msgraph', name: 'Microsoft Graph', category: 'iam', description: 'Users, alerts, sign-ins, send mail', icon: 'users' },
  { type: 'digitalocean', name: 'DigitalOcean', category: 'cloud', description: 'List droplets, add FW rules', icon: 'cloud' },
  // Network
  { type: 'fortigate', name: 'FortiGate', category: 'network', description: 'Block/unblock IPs via FortiOS REST', icon: 'shield' },
  { type: 'opnsense', name: 'OPNsense', category: 'network', description: 'Block IPs via firewall aliases', icon: 'shield' },
  // EDR
  { type: 'velociraptor', name: 'Velociraptor', category: 'endpoint', description: 'VQL hunts + client listing', icon: 'monitor' },
  // Comms
  { type: 'slack', name: 'Slack', category: 'communication', description: 'Post messages via incoming webhook', icon: 'message-square' },
  { type: 'email', name: 'Email (SMTP)', category: 'communication', description: 'Send email via SMTP', icon: 'mail' },
  // Generic
  { type: 'http', name: 'HTTP Request', category: 'security', description: 'Generic HTTP request to any URL', icon: 'globe' },
  { type: 'webhook', name: 'Webhook', category: 'security', description: 'Send HTTP webhook with auth header', icon: 'webhook' },
];

function NewIntegrationForm({ onSubmit }: { onSubmit: (data: { name: string; type: string; category: string; description: string; icon: string }) => Promise<void> }) {
  const [selected, setSelected] = useState<string>('');
  const [customName, setCustomName] = useState('');
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');

  const filtered = INTEGRATION_CATALOG.filter(c =>
    !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.type.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreate = async () => {
    const catalog = INTEGRATION_CATALOG.find(c => c.type === selected);
    if (!catalog) return;
    setSaving(true);
    try {
      await onSubmit({
        name: customName.trim() || catalog.name,
        type: catalog.type,
        category: catalog.category,
        description: catalog.description,
        icon: catalog.icon,
      });
    } finally { setSaving(false); }
  };

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search connectors..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-8 h-9 text-sm"
        />
      </div>
      <ScrollArea className="h-72 border rounded-md">
        <div className="p-1.5 space-y-1">
          {filtered.map(c => (
            <button
              key={c.type}
              onClick={() => { setSelected(c.type); setCustomName(''); }}
              className={`w-full flex items-start gap-2 p-2 rounded-md border text-left transition-colors ${selected === c.type ? 'border-primary bg-primary/5' : 'border-transparent hover:bg-muted/50'}`}
            >
              <div className="p-1.5 rounded shrink-0 bg-primary/10 text-primary">
                {getIconForIntegration(c.icon)}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium">{c.name}</p>
                <p className="text-[10px] text-muted-foreground line-clamp-1">{c.description}</p>
              </div>
              {selected === c.type && <CheckCircle2 className="h-3.5 w-3.5 text-primary shrink-0" />}
            </button>
          ))}
          {filtered.length === 0 && (
            <div className="p-4 text-center text-xs text-muted-foreground">No connectors match "{search}"</div>
          )}
        </div>
      </ScrollArea>
      {selected && (
        <div>
          <Label className="text-xs">Custom Name (optional)</Label>
          <Input
            value={customName}
            onChange={e => setCustomName(e.target.value)}
            placeholder={INTEGRATION_CATALOG.find(c => c.type === selected)?.name}
            className="mt-1 text-sm"
          />
        </div>
      )}
      <div className="flex justify-end gap-2 pt-2 border-t">
        <Button size="sm" disabled={!selected || saving} onClick={handleCreate} data-ui-button>
          {saving ? <Activity className="h-3 w-3 mr-1 animate-pulse" /> : <Plus className="h-3 w-3 mr-1" />}
          Create Integration
        </Button>
      </div>
    </div>
  );
}
