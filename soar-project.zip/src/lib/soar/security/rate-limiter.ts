/**
 * Rate Limiter — token bucket per integration
 * ---------------------------------------------------------------------------
 * Enforces per-integration rate limits defined in the node manifest. Uses
 * MongoDB atomic operations so multiple workflow engine instances share the
 * same counters (distributed rate limiting).
 *
 * Algorithm: sliding window counter (cheaper than sliding window log,
 * more accurate than fixed window). Maintains two adjacent fixed windows
 * and interpolates the count.
 *
 * Compliance: SOC2 CC6.6 (resource access controls), protects external APIs
 * from being hammered by runaway workflows.
 */
import { getDb } from '../repositories/mongo-client';
import { Logger } from '../observability/logger';

const log = new Logger({ component: 'rate-limiter' });

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: Date;
  retryAfterMs?: number;
}

/**
 * Acquire a token from the bucket. Returns allowed=true if the request fits
 * within the rate limit; allowed=false with retryAfterMs otherwise.
 */
export async function acquireToken(
  key: string, // e.g., "integration:vt:tenant:default"
  requestsPerWindow: number,
  windowMs: number,
): Promise<RateLimitResult> {
  const db = await getDb();
  const coll = db.collection('rate_limits');
  const now = Date.now();
  const windowStart = Math.floor(now / windowMs) * windowMs;
  const windowEnd = windowStart + windowMs;
  const prevWindowStart = windowStart - windowMs;

  // Atomic increment in current window
  const result = await coll.findOneAndUpdate(
    { key, windowStart },
    { $inc: { count: 1 }, $setOnInsert: { windowStart, windowEnd } },
    { upsert: true, returnDocument: 'after' },
  );
  const currentCount = (result?.value as { count?: number } | null)?.count || 1;
  // Fetch previous window count for sliding window calc
  const prev = await coll.findOne({ key, windowStart: prevWindowStart });
  const prevCount = (prev as { count?: number } | null)?.count || 0;

  // Sliding window: weighted sum of current + previous window
  const elapsedInWindow = now - windowStart;
  const prevWindowWeight = Math.max(0, 1 - elapsedInWindow / windowMs);
  const effectiveCount = prevCount * prevWindowWeight + currentCount;

  if (effectiveCount > requestsPerWindow) {
    const retryAfterMs = Math.ceil(windowEnd - now);
    log.warn(`Rate limited: ${key} (count=${effectiveCount.toFixed(2)}, limit=${requestsPerWindow})`);
    return {
      allowed: false,
      remaining: 0,
      resetAt: new Date(windowEnd),
      retryAfterMs,
    };
  }

  return {
    allowed: true,
    remaining: Math.max(0, requestsPerWindow - Math.ceil(effectiveCount)),
    resetAt: new Date(windowEnd),
  };
}

/** Check without consuming — useful for "would this request succeed?" probes. */
export async function checkRateLimit(
  key: string,
  requestsPerWindow: number,
  windowMs: number,
): Promise<RateLimitResult> {
  const db = await getDb();
  const coll = db.collection('rate_limits');
  const now = Date.now();
  const windowStart = Math.floor(now / windowMs) * windowMs;
  const windowEnd = windowStart + windowMs;
  const prevWindowStart = windowStart - windowMs;

  const [current, prev] = await Promise.all([
    coll.findOne({ key, windowStart }),
    coll.findOne({ key, windowStart: prevWindowStart }),
  ]);
  const currentCount = (current as { count?: number } | null)?.count || 0;
  const prevCount = (prev as { count?: number } | null)?.count || 0;

  const elapsedInWindow = now - windowStart;
  const prevWindowWeight = Math.max(0, 1 - elapsedInWindow / windowMs);
  const effectiveCount = prevCount * prevWindowWeight + currentCount;

  if (effectiveCount >= requestsPerWindow) {
    return {
      allowed: false,
      remaining: 0,
      resetAt: new Date(windowEnd),
      retryAfterMs: Math.ceil(windowEnd - now),
    };
  }

  return {
    allowed: true,
    remaining: Math.max(0, requestsPerWindow - Math.ceil(effectiveCount)),
    resetAt: new Date(windowEnd),
  };
}
