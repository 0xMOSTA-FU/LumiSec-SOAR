/**
 * SOAR Node Bootstrap
 * ---------------------------------------------------------------------------
 * On application startup, this module registers every production node with
 * the node registry. This is the SINGLE source of truth for which nodes
 * are available — adding a new node = adding one line here.
 *
 * The bootstrap is idempotent (calling it twice is safe).
 */
import { nodeRegistry } from './registry';
import { virustotalExecutor, virustotalManifest } from './virustotal';

let bootstrapped = false;

export function bootstrapNodes(): void {
  if (bootstrapped) return;

  // Production nodes — full manifest + executor
  nodeRegistry.register(virustotalExecutor);

  // TODO: migrate remaining nodes to the manifest system:
  // nodeRegistry.register(abuseipdbExecutor);
  // nodeRegistry.register(ipinfoExecutor);
  // nodeRegistry.register(slackExecutor);
  // ... etc (27 nodes total)
  //
  // Until migrated, the legacy engine dispatch (src/lib/executors/engine.ts)
  // continues to handle calls for nodes not yet in the new registry.

  bootstrapped = true;
  console.log(`[soar] Bootstrapped ${nodeRegistry.size()} production node(s)`);
}

export { virustotalManifest };
