// Trigger + Log + Block/IP-Isolate executors
// - trigger: just emits a "fired" log
// - log: writes a message to execution logs
// - block: simulates firewall block (no real firewall API in sandbox)
// - isolate: simulates host isolation

import { NodeExecutorResult, WFNode, ExecutionContext, resolveTemplate } from '../types';

export async function executeTrigger(
  node: WFNode,
  ctx: ExecutionContext
): Promise<NodeExecutorResult> {
  const cfg = node.data.config;
  const subtype = node.subtype || 'manual';
  const logs: NodeExecutorResult['logs'] = [];
  const start = Date.now();

  // For webhook triggers, the request body is in ctx.trigger
  // For schedule, no input. For alert, alert data is in ctx.trigger
  // For manual, ctx.trigger may contain optional input

  let triggerMsg = `Trigger fired: ${subtype}`;
  if (subtype === 'webhook') {
    const path = (cfg.path as string) || '/webhook';
    triggerMsg = `Webhook trigger fired on ${path} (body keys: ${Object.keys(ctx.trigger).join(', ') || 'none'})`;
  } else if (subtype === 'schedule') {
    triggerMsg = `Schedule trigger fired (interval: ${cfg.interval || 'on-demand'})`;
  } else if (subtype === 'alert') {
    triggerMsg = `Alert trigger fired (severity: ${cfg.severity || 'any'}, source: ${cfg.source || 'any'})`;
  } else if (subtype === 'manual') {
    triggerMsg = `Manual trigger fired by user`;
  }

  logs.push({
    time: new Date().toISOString(),
    nodeId: node.id,
    nodeLabel: node.data.label,
    message: triggerMsg,
    level: 'info',
    duration: Date.now() - start,
    data: ctx.trigger,
  });

  // Echo trigger data as output so downstream nodes can use it
  return {
    success: true,
    output: { trigger: ctx.trigger },
    logs,
  };
}

export async function executeLog(
  node: WFNode,
  ctx: ExecutionContext
): Promise<NodeExecutorResult> {
  const cfg = node.data.config;
  let message = (cfg.message as string) || '';
  const level = (cfg.level as string) || 'info';
  message = resolveTemplate(message, ctx);

  const logs: NodeExecutorResult['logs'] = [{
    time: new Date().toISOString(),
    nodeId: node.id,
    nodeLabel: node.data.label,
    message: `LOG: ${message}`,
    level: level as 'info' | 'success' | 'warning' | 'error',
    duration: 0,
  }];

  return { success: true, output: { log: { message, level } }, logs };
}

export async function executeBlock(
  node: WFNode,
  ctx: ExecutionContext
): Promise<NodeExecutorResult> {
  const cfg = node.data.config;
  let target = (cfg.target as string) || (cfg.ip as string) || (cfg.domain as string) || '';
  const type = (cfg.type as string) || 'ip';
  target = resolveTemplate(target, ctx);

  const logs: NodeExecutorResult['logs'] = [];
  const start = Date.now();

  if (!target) {
    logs.push({ time: new Date().toISOString(), nodeId: node.id, nodeLabel: node.data.label, message: 'Block: no target specified', level: 'error', duration: Date.now() - start });
    return { success: false, logs };
  }

  // Try each known firewall integration type until we find a connected one.
  // The generic Block IP node is firewall-agnostic — it delegates to whichever
  // real firewall (FortiGate / OPNsense) the user has connected.
  const candidates = [
    { key: 'fortigate', executor: async () => {
      const { executeFortiGate } = await import('./fortigate');
      return executeFortiGate({
        ...node,
        subtype: 'fortigate',
        data: { ...node.data, config: { ...cfg, action: 'block_ip', ip: target } },
      }, ctx);
    }},
    { key: 'opnsense', executor: async () => {
      const { executeOPNsense } = await import('./opnsense');
      return executeOPNsense({
        ...node,
        subtype: 'opnsense',
        data: { ...node.data, config: { ...cfg, action: 'block_ip', ip: target } },
      }, ctx);
    }},
  ];

  for (const c of candidates) {
    const integ = ctx.getIntegration(c.key);
    if (integ && integ.status === 'connected') {
      const result = await c.executor();
      // Re-label the log lines so they show "Block IP via <firewall>"
      result.logs = result.logs.map(l => ({
        ...l,
        message: l.message.replace(/^.*(Block|block_ip).*:/i, `Block ${type} "${target}" via ${c.key}:`),
      }));
      return result;
    }
  }

  // No firewall integration connected — record the action as queued so
  // workflows don't crash. The operator can wire up a firewall later.
  logs.push({
    time: new Date().toISOString(),
    nodeId: node.id,
    nodeLabel: node.data.label,
    message: `Block: ${type} "${target}" queued (no firewall integration connected — connect FortiGate or OPNsense on the Integrations page to enable real blocks)`,
    level: 'warning',
    duration: Date.now() - start,
    data: { target, type },
  });

  return {
    success: true,
    output: { block: { target, type, queued: true } },
    logs,
  };
}

export async function executeIsolate(
  node: WFNode,
  ctx: ExecutionContext
): Promise<NodeExecutorResult> {
  const cfg = node.data.config;
  let hostname = (cfg.hostname as string) || (cfg.host as string) || (cfg.target as string) || '';
  hostname = resolveTemplate(hostname, ctx);

  const logs: NodeExecutorResult['logs'] = [];
  const start = Date.now();

  if (!hostname) {
    logs.push({ time: new Date().toISOString(), nodeId: node.id, nodeLabel: node.data.label, message: 'Isolate: no hostname specified', level: 'error', duration: Date.now() - start });
    return { success: false, logs };
  }

  const integration = ctx.getIntegration('edr') || ctx.getIntegration('crowdstrike');
  logs.push({
    time: new Date().toISOString(),
    nodeId: node.id,
    nodeLabel: node.data.label,
    message: `Isolate: host "${hostname}" isolation ${integration?.status === 'connected' ? 'requested via EDR' : 'queued (no EDR connected)'}`,
    level: integration?.status === 'connected' ? 'success' : 'warning',
    duration: Date.now() - start,
    data: { hostname, edr: integration?.name },
  });

  return {
    success: true,
    output: { isolate: { hostname, queued: true } },
    logs,
  };
}
