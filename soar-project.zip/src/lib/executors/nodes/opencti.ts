// Real OpenCTI executor - create entities + relationships via GraphQL
// Docs: https://docs.opencti.io/latest/usage/

import { IntegrationConfig, NodeExecutorResult, WFNode, ExecutionContext, resolveTemplate } from '../types';

function getCreds(integration: IntegrationConfig | null) {
  const c = integration?.config || {};
  const url = (c.url as string) || (c.host as string) || '';
  const api_key = (c.api_key as string) || (c.token as string) || '';
  return { url: url.replace(/\/$/, ''), api_key };
}

export async function callOpenCTI(
  integration: IntegrationConfig | null,
  query: string,
  variables: Record<string, unknown> = {}
): Promise<{ ok: boolean; status: number; data: unknown; durationMs: number }> {
  const start = Date.now();
  const creds = getCreds(integration);
  if (!creds.url || !creds.api_key) return { ok: false, status: 401, data: { error: 'OpenCTI url+api_key required' }, durationMs: 0 };
  if (integration?.status !== 'connected') return { ok: false, status: 503, data: { error: 'OpenCTI not connected' }, durationMs: 0 };

  try {
    const res = await fetch(`${creds.url}/graphql`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${creds.api_key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, variables }),
      cache: 'no-store',
    });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok && !(data as { errors?: unknown[] })?.errors?.length, status: res.status, data, durationMs: Date.now() - start };
  } catch (err: unknown) {
    return { ok: false, status: 0, data: { error: err instanceof Error ? err.message : String(err) }, durationMs: Date.now() - start };
  }
}

export async function executeOpenCTI(node: WFNode, ctx: ExecutionContext): Promise<NodeExecutorResult> {
  const cfg = node.data.config;
  const action = (cfg.action as string) || 'create_indicator';
  const logs: NodeExecutorResult['logs'] = [];
  const start = Date.now();
  const integration = ctx.getIntegration('opencti');

  if (action === 'create_indicator') {
    const pattern = resolveTemplate((cfg.pattern as string) || '', ctx);
    const name = resolveTemplate((cfg.name as string) || pattern, ctx);
    const pattern_type = (cfg.pattern_type as string) || 'stix';
    const x_opencti_main_observable_type = (cfg.observable_type as string) || 'IPv4-Addr';
    if (!pattern) {
      logs.push({ time: new Date().toISOString(), nodeId: node.id, nodeLabel: node.data.label, message: 'OpenCTI: pattern required', level: 'error', duration: Date.now() - start });
      return { success: false, logs };
    }
    logs.push({ time: new Date().toISOString(), nodeId: node.id, nodeLabel: node.data.label, message: `OpenCTI: creating indicator "${name}"...`, level: 'info' });

    const query = `mutation CreateIndicator($input: IndicatorAddInput!) { indicatorAdd(input: $input) { id standard_id } }`;
    const result = await callOpenCTI(integration, query, {
      input: { name, pattern, pattern_type, x_opencti_main_observable_type, valid_from: new Date().toISOString() },
    });
    if (!result.ok) {
      const errData = result.data as { errors?: { message: string }[] };
      const err = errData.errors?.[0]?.message || `HTTP ${result.status}`;
      logs.push({ time: new Date().toISOString(), nodeId: node.id, nodeLabel: node.data.label, message: `OpenCTI error: ${err}`, level: 'error', duration: result.durationMs, data: result.data });
      return { success: false, output: { opencti: { ok: false, error: err } }, logs };
    }
    const ind = (result.data as { data: { indicatorAdd: { id: string; standard_id: string } } }).data.indicatorAdd;
    logs.push({ time: new Date().toISOString(), nodeId: node.id, nodeLabel: node.data.label, message: `OpenCTI: indicator created (id=${ind.id})`, level: 'success', duration: result.durationMs, data: { id: ind.id } });
    return { success: true, output: { opencti: { ok: true, indicator_id: ind.id, standard_id: ind.standard_id } }, logs };
  }

  if (action === 'search') {
    const search_value = resolveTemplate((cfg.search as string) || (cfg.value as string) || '', ctx);
    if (!search_value) {
      logs.push({ time: new Date().toISOString(), nodeId: node.id, nodeLabel: node.data.label, message: 'OpenCTI: search value required', level: 'error', duration: Date.now() - start });
      return { success: false, logs };
    }
    const query = `query Search($search: String) { indicators(search: $search) { edges { node { id name pattern } } } }`;
    const result = await callOpenCTI(integration, query, { search: search_value });
    if (!result.ok) {
      logs.push({ time: new Date().toISOString(), nodeId: node.id, nodeLabel: node.data.label, message: `OpenCTI search error: HTTP ${result.status}`, level: 'error', duration: result.durationMs });
      return { success: false, logs };
    }
    const edges = (result.data as { data: { indicators: { edges: { node: { id: string; name: string; pattern: string } }[] } } }).data.indicators.edges;
    logs.push({ time: new Date().toISOString(), nodeId: node.id, nodeLabel: node.data.label, message: `OpenCTI: ${edges?.length || 0} indicators found`, level: 'success', duration: result.durationMs });
    return { success: true, output: { opencti: { ok: true, count: edges?.length, indicators: edges?.slice(0, 10) } }, logs };
  }

  logs.push({ time: new Date().toISOString(), nodeId: node.id, nodeLabel: node.data.label, message: `OpenCTI: unknown action "${action}"`, level: 'error', duration: Date.now() - start });
  return { success: false, logs };
}
