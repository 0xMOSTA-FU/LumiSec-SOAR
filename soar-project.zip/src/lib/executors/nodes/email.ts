// Email executor - sends real email via SMTP using nodemailer.
// Pulls SMTP credentials from the `email`/`smtp` integration row in the DB.
// Supports plain SMTP, SMTPS, and OAuth2 (if `service: 'gmail'` etc).
// All template fields (to, subject, body, cc, bcc) are resolved against the
// execution context so {{trigger.ip}} / {{outputs.n1.field}} work.

import nodemailer from 'nodemailer';
import { NodeExecutorResult, WFNode, ExecutionContext, resolveTemplate } from '../types';

// Build (and memoize) a nodemailer transporter from an integration config.
// Returns null if no SMTP host was provided — caller treats that as "skip send".
function buildTransporter(cfg: Record<string, unknown>) {
  const host = (cfg.smtp_host as string) || (cfg.host as string) || '';
  const port = Number(cfg.port || 587);
  const username = (cfg.username as string) || '';
  const password = (cfg.password as string) || '';
  const secure = Number(cfg.port) === 465 || cfg.secure === true;
  const service = (cfg.service as string) || '';
  if (!host && !service) return null;

  const opts: Record<string, unknown> = { secure };
  if (service) {
    opts.service = service;
  } else {
    opts.host = host;
    opts.port = port;
  }
  if (username || password) {
    opts.auth = { user: username, pass: password };
  }
  // Allow TLS bypass for self-signed corp SMTP servers (off by default)
  if (cfg.reject_unauthorized === false) {
    opts.tls = { rejectUnauthorized: false };
  }
  return nodemailer.createTransport(opts as nodemailer.TransportOptions);
}

export async function executeEmail(
  node: WFNode,
  ctx: ExecutionContext
): Promise<NodeExecutorResult> {
  const cfg = node.data.config;
  const start = Date.now();
  const logs: NodeExecutorResult['logs'] = [];

  // Resolve all template variables in the email fields
  const to = resolveTemplate(String(cfg.to || ''), ctx);
  const cc = resolveTemplate(String(cfg.cc || ''), ctx);
  const bcc = resolveTemplate(String(cfg.bcc || ''), ctx);
  const subject = resolveTemplate(String(cfg.subject || ''), ctx);
  const body = resolveTemplate(String(cfg.body || cfg.message || ''), ctx);
  const isHtml = cfg.html === true || cfg.format === 'html';

  if (!to) {
    logs.push({
      time: new Date().toISOString(),
      nodeId: node.id, nodeLabel: node.data.label,
      message: 'Email: no recipient configured (cfg.to is empty after template resolution)',
      level: 'error', duration: Date.now() - start,
    });
    return { success: false, logs };
  }

  // Look up SMTP integration from the DB-backed context map
  const integration = ctx.getIntegration('email') || ctx.getIntegration('smtp');
  const smtpCfg = (integration?.config || {}) as Record<string, unknown>;
  const from = resolveTemplate(String(cfg.from || smtpCfg.from || smtpCfg.username || ''), ctx);

  // No SMTP integration configured - record as a queued/simulated notification
  // so workflows don't crash just because SMTP isn't set up.
  if (!integration || (!smtpCfg.smtp_host && !smtpCfg.host && !smtpCfg.service)) {
    logs.push({
      time: new Date().toISOString(),
      nodeId: node.id, nodeLabel: node.data.label,
      message: `Email queued (no SMTP integration configured): to=${to}, subject="${subject}"`,
      level: 'warning', duration: Date.now() - start,
      data: { to, cc, subject, body_preview: body.slice(0, 200) },
    });
    return {
      success: true,
      output: { email: { ok: true, queued: true, to, cc, subject, body, reason: 'no_smtp_configured' } },
      logs,
    };
  }

  // Build transporter and send
  try {
    const transporter = buildTransporter(smtpCfg);
    if (!transporter) {
      logs.push({
        time: new Date().toISOString(),
        nodeId: node.id, nodeLabel: node.data.label,
        message: `Email failed: SMTP integration exists but host/service missing`,
        level: 'error', duration: Date.now() - start,
      });
      return { success: false, logs };
    }

    const mailOptions: nodemailer.SendMailOptions = {
      from,
      to,
      cc: cc || undefined,
      bcc: bcc || undefined,
      subject,
      ...(isHtml ? { html: body } : { text: body }),
    };

    const info = await transporter.sendMail(mailOptions);
    logs.push({
      time: new Date().toISOString(),
      nodeId: node.id, nodeLabel: node.data.label,
      message: `Email sent via ${smtpCfg.smtp_host || smtpCfg.host || smtpCfg.service}: to=${to}, subject="${subject}" (messageId=${info.messageId})`,
      level: 'success', duration: Date.now() - start,
      data: { to, cc, subject, from, messageId: info.messageId, response: info.response },
    });
    return {
      success: true,
      output: { email: { ok: true, sent: true, to, cc, subject, from, messageId: info.messageId, response: info.response } },
      logs,
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    logs.push({
      time: new Date().toISOString(),
      nodeId: node.id, nodeLabel: node.data.label,
      message: `Email send failed: ${msg}`,
      level: 'error', duration: Date.now() - start,
      data: { to, subject, error: msg },
    });
    return { success: false, logs };
  }
}

// Send a single test email - used by the integrations/test endpoint.
// Returns a structured result so the UI can show a meaningful toast.
export async function sendTestEmail(
  integration: { config: Record<string, unknown>; name: string },
  to: string,
): Promise<{ ok: boolean; message: string; data?: unknown }> {
  const cfg = integration.config || {};
  const transporter = buildTransporter(cfg);
  if (!transporter) {
    return { ok: false, message: 'Email: SMTP host/service is required to send test mail' };
  }
  try {
    const from = (cfg.from as string) || (cfg.username as string) || 'soar@localhost';
    const info = await transporter.sendMail({
      from,
      to,
      subject: `[SOAR] Test email from ${integration.name}`,
      text: `This is a test email sent from your SOAR platform at ${new Date().toISOString()}.\n\nIf you received this, your SMTP integration is working correctly.\n\nIntegration: ${integration.name}`,
    });
    return {
      ok: true,
      message: `Email sent to ${to} (messageId=${info.messageId})`,
      data: { messageId: info.messageId, response: info.response, from },
    };
  } catch (err: unknown) {
    return { ok: false, message: `Email send failed: ${err instanceof Error ? err.message : String(err)}` };
  }
}
