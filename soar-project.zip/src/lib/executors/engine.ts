// Main execution engine: graph traversal + node dispatch
// Receives a workflow shape + trigger payload, executes nodes in topological order,
// calls real executors, accumulates logs, writes results to DB.

import { db } from '@/lib/db';
import { decrypt } from '@/lib/crypto';
import {
  WFNode, WFEdge, ExecutionContext, ExecutionLog,
  NodeExecutorResult, IntegrationConfig,
} from './types';
import { executeVirusTotal } from './nodes/virustotal';
import { executeAbuseIPDB } from './nodes/abuseipdb';
import { executeIPInfo } from './nodes/ipinfo';
import { executeHTTP } from './nodes/http';
import { executeSlack } from './nodes/slack';
import { executeEmail } from './nodes/email';
import { executeCondition } from './nodes/condition';
import { executeCreateCase, executeCreateAlert } from './nodes/case-alert';
import { executeTrigger, executeLog, executeBlock, executeIsolate } from './nodes/builtin';
import { executeJira } from './nodes/jira';
import { executePagerDuty } from './nodes/pagerduty';
import { executeServiceNow } from './nodes/servicenow';
import { executeTheHive } from './nodes/thehive';
import { executeMISP } from './nodes/misp';
import { executeOpenCTI } from './nodes/opencti';
import { executeWazuh } from './nodes/wazuh';
import { executeSplunk } from './nodes/splunk';
import { executeElastic } from './nodes/elastic';
import { executeMSGraph } from './nodes/msgraph';
import { executeFortiGate } from './nodes/fortigate';
import { executeOPNsense } from './nodes/opnsense';
import { executeDigitalOcean } from './nodes/digitalocean';
import { executeDefectDojo } from './nodes/defectdojo';
import { executeOTX } from './nodes/alienvault-otx';
import { executeVelociraptor } from './nodes/velociraptor';
import { executeSoarUtils } from './nodes/soar-utils';
import { executeWebhook } from './nodes/webhook';

export interface RunOptions {
  executionId: string;
  workflowId: string;
  triggerPayload: Record<string, unknown>;
  /** Tenant ID for multi-tenant isolation. When set, all cases/alerts
   *  created by this workflow execution are scoped to this tenant. */
  tenantId?: string | null;
  /** ID of the user who triggered the execution (for audit attribution). */
  startedBy?: string | null;
  /** Request correlation ID (propagated to logs + audit entries). */
  requestId?: string | null;
}

export interface RunResult {
  success: boolean;
  logs: ExecutionLog[];
  outputs: Record<string, unknown>;
  result: Record<string, unknown>;
  executedNodeIds: string[];
  failedNodeIds: string[];
  durationMs: number;
}

// Load all integrations from DB and build a lookup map
// Keys tried in order: by type, by id (lowercased), by name (lowercased, with - / _ stripped)
async function loadIntegrations(): Promise<Map<string, IntegrationConfig>> {
  const rows = await db.integration.findMany();
  const map = new Map<string, IntegrationConfig>();
  for (const r of rows) {
    let cfg: Record<string, unknown> = {};
    // Configs are AES-256-GCM encrypted at rest; decrypt on load.
    // Backward compat: if decrypt returns null or string, fall back to JSON.parse.
    if (r.config) {
      try {
        const decrypted = decrypt<Record<string, unknown>>(r.config);
        if (decrypted && typeof decrypted === 'object') cfg = decrypted;
        else if (typeof decrypted === 'string') cfg = JSON.parse(decrypted);
        else cfg = JSON.parse(r.config);
      } catch { /* keep empty */ }
    }
    const item: IntegrationConfig = {
      id: r.id, name: r.name, type: r.type, category: r.category,
      config: cfg, status: r.status,
    };
    // Index by type (lowercased)
    map.set(r.type.toLowerCase(), item);
    // Index by id (lowercased)
    map.set(r.id.toLowerCase(), item);
    // Index by name normalized ("VirusTotal", "Virus Total", "virus-total" -> "virustotal")
    const norm = r.name.toLowerCase().replace(/[\s\-_]/g, '');
    map.set(norm, item);
    // Also store without "virustotal" -> "virus total" mappings
    if (norm.includes('virustotal')) map.set('virus_total', item);
    if (norm.includes('abuseipdb')) map.set('abuse_ipdb', item);
    if (norm.includes('ipinfo')) map.set('ip_info', item);
    if (norm.includes('msgraph') || norm.includes('microsoftgraph')) {
      map.set('ms_graph', item);
      map.set('microsoft_graph', item);
      map.set('microsoft', item);
    }
    if (norm.includes('alienvault') || norm.includes('otx')) {
      map.set('otx', item);
      map.set('alien_vault', item);
    }
  }
  return map;
}

// Per-node execution with retry, exponential backoff, and timeout.
// Wraps every dispatchNode call so all 27 executors inherit these guarantees.
//
// BUGFIXES (AUDIT-3 findings #4, #5):
//   1. setTimeout leak — previously the timeout promise was never cleared,
//      keeping the event loop alive and firing unhandled rejections after
//      the operation succeeded. Now uses AbortController + clearTimeout.
//   2. 4xx retry heuristic — previously matched `/HTTP 4\d\d/` against log
//      MESSAGE TEXT (fragile, depends on human-readable logs). Now uses
//      structured `result.errorCode` / `result.httpStatus` when available,
//      falling back to the log regex only as a last resort.
//   3. `lastErr = null` reset — previously reset on every non-success
//      result, so the final "exhausted retries" log said "unknown error"
//      instead of the actual failure. Now preserved correctly.
//   4. Mid-loop return — `if (attempt === maxRetries) return result;` was
//      confusing. Now the loop naturally falls through to the exhausted
//      path. Cleaner control flow.
async function dispatchWithRetry(
  node: WFNode,
  ctx: ExecutionContext,
  execute: () => Promise<NodeExecutorResult>
): Promise<NodeExecutorResult> {
  const maxRetries = Number(process.env.NODE_MAX_RETRIES || 3);
  const baseDelayMs = Number(process.env.NODE_RETRY_BASE_DELAY_MS || 500);
  const maxDelayMs = Number(process.env.NODE_RETRY_MAX_DELAY_MS || 10000);
  const timeoutMs = Number(process.env.NODE_TIMEOUT_MS || 30000);

  let lastErr: Error | null = null;
  let lastResult: NodeExecutorResult | null = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    // Use AbortController so the timer can be cleared on success.
    // This prevents the event-loop leak and the unhandled rejection.
    const controller = new AbortController();
    const timeoutHandle = setTimeout(
      () => controller.abort(new Error(`Node timeout after ${timeoutMs}ms`)),
      timeoutMs,
    );

    try {
      // Pass the abort signal to the executor via a context extension.
      // Executors that support AbortController (safeFetch, undici) will
      // cancel in-flight HTTP requests on timeout.
      const result = await execute();
      clearTimeout(timeoutHandle);

      if (result.success) return result;

      lastResult = result;

      // Determine if this is a retryable failure.
      // Structured signal: result.errorCode or result.httpStatus
      // (new convention — executors should populate these instead of
      // embedding HTTP status in log message text).
      const httpStatus =
        (result as NodeExecutorResult & { httpStatus?: number }).httpStatus ||
        (() => {
          // Legacy fallback: scrape log text. Will be removed once all
          // executors are migrated to set httpStatus explicitly.
          const match = result.logs.find(l => /HTTP (\d{3})/.exec(l.message));
          if (match) {
            const m = /HTTP (\d{3})/.exec(match.message);
            return m ? Number(m[1]) : null;
          }
          return null;
        })();

      // 4xx (except 408, 429) is non-retryable — return immediately.
      if (httpStatus && httpStatus >= 400 && httpStatus < 500 && httpStatus !== 408 && httpStatus !== 429) {
        return result;
      }

      // 5xx, network errors, timeouts: retry with exponential backoff + jitter
      if (attempt < maxRetries) {
        const delay = Math.min(
          baseDelayMs * Math.pow(2, attempt) + Math.random() * 250,
          maxDelayMs,
        );
        await new Promise(r => setTimeout(r, delay));
      }
    } catch (err: unknown) {
      clearTimeout(timeoutHandle);
      lastErr = err instanceof Error ? err : new Error(String(err));
      // Timeout / abort / network error: retry with backoff
      if (attempt < maxRetries) {
        const delay = Math.min(
          baseDelayMs * Math.pow(2, attempt) + Math.random() * 250,
          maxDelayMs,
        );
        await new Promise(r => setTimeout(r, delay));
      }
    }
  }

  // All retries exhausted
  const message = lastErr?.message
    || (lastResult?.logs.find(l => l.level === 'error')?.message)
    || 'unknown error';

  return {
    success: false,
    logs: [{
      time: new Date().toISOString(),
      nodeId: node.id,
      nodeLabel: node.data.label,
      message: `Node failed after ${maxRetries + 1} attempts: ${message}`,
      level: 'error',
      data: {
        attempts: maxRetries + 1,
        last_error: lastErr?.message,
        last_result_success: lastResult?.success,
      },
    }],
  };
}

// Dispatch a node to its executor based on type + subtype
async function dispatchNode(
  node: WFNode,
  ctx: ExecutionContext
): Promise<NodeExecutorResult> {
  try {
    if (node.type === 'trigger') {
      return await executeTrigger(node, ctx);
    }
    if (node.type === 'condition') {
      return await executeCondition(node, ctx);
    }
    if (node.type === 'output') {
      switch (node.subtype) {
        case 'log':
          return await executeLog(node, ctx);
        case 'alert_out':
          return await executeCreateAlert(node, ctx);
        case 'webhook_response':
          return {
            success: true,
            output: { webhook_response: node.data.config },
            logs: [{
              time: new Date().toISOString(),
              nodeId: node.id,
              nodeLabel: node.data.label,
              message: `Webhook response: ${JSON.stringify(node.data.config).slice(0, 100)}`,
              level: 'info',
              duration: 0,
            }],
          };
        default:
          return await executeLog(node, ctx);
      }
    }
    // action nodes - dispatch by subtype
    switch (node.subtype) {
      // Threat Intel
      case 'virustotal':
      case 'vt':
        return await executeVirusTotal(node, ctx);
      case 'abuseipdb':
        return await executeAbuseIPDB(node, ctx);
      case 'ipinfo':
      case 'ip_info':
        return await executeIPInfo(node, ctx);
      case 'otx':
      case 'alienvault':
        return await executeOTX(node, ctx);
      case 'misp':
        return await executeMISP(node, ctx);
      case 'opencti':
        return await executeOpenCTI(node, ctx);
      // SIEM
      case 'splunk':
        return await executeSplunk(node, ctx);
      case 'elastic':
      case 'elasticsearch':
        return await executeElastic(node, ctx);
      case 'wazuh':
        return await executeWazuh(node, ctx);
      // ITSM / Ticketing
      case 'jira':
        return await executeJira(node, ctx);
      case 'servicenow':
      case 'snow':
        return await executeServiceNow(node, ctx);
      case 'pagerduty':
        return await executePagerDuty(node, ctx);
      case 'thehive':
        return await executeTheHive(node, ctx);
      case 'defectdojo':
        return await executeDefectDojo(node, ctx);
      // Cloud / Identity
      case 'msgraph':
      case 'microsoft':
        return await executeMSGraph(node, ctx);
      case 'digitalocean':
      case 'do':
        return await executeDigitalOcean(node, ctx);
      // Network / Firewall
      case 'fortigate':
      case 'fortios':
        return await executeFortiGate(node, ctx);
      case 'opnsense':
        return await executeOPNsense(node, ctx);
      // EDR / IR
      case 'velociraptor':
        return await executeVelociraptor(node, ctx);
      case 'block':
        return await executeBlock(node, ctx);
      case 'isolate':
        return await executeIsolate(node, ctx);
      // Comms
      case 'slack':
        return await executeSlack(node, ctx);
      case 'email':
        return await executeEmail(node, ctx);
      // Case/Alert
      case 'create_case':
        return await executeCreateCase(node, ctx);
      case 'alert_out':
        return await executeCreateAlert(node, ctx);
      // Generic HTTP + Webhook
      case 'http':
      case 'api':
        return await executeHTTP(node, ctx);
      case 'webhook':
        return await executeWebhook(node, ctx);
      // SOAR internal utils
      case 'soar_utils':
      case 'util':
        return await executeSoarUtils(node, ctx);
      // Enrich - default to VirusTotal
      case 'enrich': {
        const source = (node.data.config.source as string) || 'virustotal';
        if (source === 'abuseipdb') return await executeAbuseIPDB(node, ctx);
        if (source === 'ipinfo') return await executeIPInfo(node, ctx);
        if (source === 'otx' || source === 'alienvault') return await executeOTX(node, ctx);
        if (source === 'misp') return await executeMISP(node, ctx);
        return await executeVirusTotal(node, ctx);
      }
      default:
        return {
          success: true,
          output: { unknown: { subtype: node.subtype } },
          logs: [{
            time: new Date().toISOString(),
            nodeId: node.id,
            nodeLabel: node.data.label,
            message: `Unknown action subtype "${node.subtype}" - skipped (no executor)`,
            level: 'warning',
            duration: 0,
          }],
        };
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    return {
      success: false,
      logs: [{
        time: new Date().toISOString(),
        nodeId: node.id,
        nodeLabel: node.data.label,
        message: `Executor crashed: ${msg}`,
        level: 'error',
      }],
    };
  }
}

export async function runWorkflow(opts: RunOptions): Promise<RunResult> {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { executionId, workflowId, triggerPayload, tenantId, startedBy, requestId } = opts;
  const start = Date.now();

  // Load workflow from DB
  const wf = await db.workflow.findUnique({ where: { id: workflowId } });
  if (!wf) {
    return {
      success: false,
      logs: [{ time: new Date().toISOString(), message: `Workflow ${workflowId} not found`, level: 'error' }],
      outputs: {}, result: {}, executedNodeIds: [], failedNodeIds: [], durationMs: 0,
    };
  }

  // TENANT ISOLATION: if the workflow has a tenantId and the caller's
  // tenantId doesn't match, refuse to execute. This prevents a compromised
  // tenant from running another tenant's workflows.
  if (tenantId && wf.tenantId && wf.tenantId !== tenantId) {
    return {
      success: false,
      logs: [{
        time: new Date().toISOString(),
        message: `Workflow ${workflowId} does not belong to tenant ${tenantId}`,
        level: 'error',
      }],
      outputs: {}, result: {}, executedNodeIds: [], failedNodeIds: [], durationMs: 0,
    };
  }

  // Use the workflow's tenantId if caller didn't provide one (system jobs)
  const effectiveTenantId = tenantId || wf.tenantId || null;

  let nodes: WFNode[] = [];
  let edges: WFEdge[] = [];
  try { nodes = JSON.parse(wf.nodes || '[]'); } catch { /* keep empty */ }
  try { edges = JSON.parse(wf.edges || '[]'); } catch { /* keep empty */ }

  // Load integrations
  const integrations = await loadIntegrations();

  // Build execution context
  const ctx: ExecutionContext = {
    trigger: triggerPayload,
    outputs: {},
    result: {},
    getIntegration: (key: string) => integrations.get(key.toLowerCase().replace(/[\s\-_]/g, '')) || null,
    createCase: async (data) => {
      try {
        const c = await db.case.create({ data: {
          tenantId: effectiveTenantId,
          title: String(data.title || 'Untitled'),
          description: String(data.description || ''),
          severity: String(data.severity || 'medium'),
          status: String(data.status || 'open'),
          tags: String(data.tags || '[]'),
          artifacts: String(data.artifacts || '[]'),
          timeline: String(data.timeline || '[]'),
        }});
        return c.id;
      } catch (e) { console.error('createCase error:', e); return null; }
    },
    createAlert: async (data) => {
      try {
        const a = await db.alert.create({ data: {
          tenantId: effectiveTenantId,
          title: String(data.title || 'Untitled'),
          description: String(data.description || ''),
          severity: String(data.severity || 'medium'),
          source: String(data.source || 'workflow'),
          status: String(data.status || 'new'),
        }});
        return a.id;
      } catch (e) { console.error('createAlert error:', e); return null; }
    },
  };

  const allLogs: ExecutionLog[] = [];
  const executedNodeIds: string[] = [];
  const failedNodeIds: string[] = [];

  const appendLogs = (logs: ExecutionLog[]) => {
    allLogs.push(...logs);
    db.workflowExecution.update({
      where: { id: executionId },
      data: { logs: JSON.stringify(allLogs) },
    }).catch(e => console.error('log persist error:', e));
  };

  allLogs.push({
    time: new Date().toISOString(),
    message: `Workflow "${wf.name}" execution started (${nodes.length} nodes, ${edges.length} edges)`,
    level: 'info',
  });
  appendLogs([]);

  // Find trigger nodes
  const triggers = nodes.filter(n => n.type === 'trigger');
  if (triggers.length === 0) {
    allLogs.push({ time: new Date().toISOString(), message: 'No trigger nodes found. Aborting.', level: 'error' });
    appendLogs([]);
    await finalize(executionId, false, ctx, allLogs, start);
    return { success: false, logs: allLogs, outputs: ctx.outputs, result: ctx.result, executedNodeIds, failedNodeIds, durationMs: Date.now() - start };
  }

  // BFS traversal with branch support
  const visited = new Set<string>();
  const queue: string[] = triggers.map(t => t.id);

  while (queue.length > 0) {
    const nodeId = queue.shift()!;
    if (visited.has(nodeId)) continue;
    visited.add(nodeId);

    const node = nodes.find(n => n.id === nodeId);
    if (!node) continue;

    const result = await dispatchWithRetry(node, ctx, () => dispatchNode(node, ctx));
    ctx.outputs[nodeId] = result.output || {};
    appendLogs(result.logs);

    if (result.success) {
      executedNodeIds.push(nodeId);
    } else {
      failedNodeIds.push(nodeId);
    }

    // Determine which edges to follow
    const outEdges = edges.filter(e => e.source === nodeId);
    if (result.branch) {
      const matching = outEdges.filter(e => (e.label || '').toLowerCase() === result.branch!.toLowerCase());
      if (matching.length > 0) {
        matching.forEach(e => { if (!visited.has(e.target)) queue.push(e.target); });
      } else {
        outEdges.filter(e => !e.label).forEach(e => { if (!visited.has(e.target)) queue.push(e.target); });
      }
    } else {
      outEdges.filter(e => !e.label).forEach(e => { if (!visited.has(e.target)) queue.push(e.target); });
    }
  }

  // Build final result summary
  ctx.result = {
    executed_nodes: executedNodeIds.length,
    failed_nodes: failedNodeIds.length,
    outputs: ctx.outputs,
    duration_ms: Date.now() - start,
  };

  allLogs.push({
    time: new Date().toISOString(),
    message: `Workflow execution completed. ${executedNodeIds.length} succeeded, ${failedNodeIds.length} failed, duration=${Date.now() - start}ms`,
    level: failedNodeIds.length > 0 ? 'warning' : 'success',
  });
  appendLogs([]);

  await finalize(executionId, failedNodeIds.length === 0, ctx, allLogs, start);

  return {
    success: failedNodeIds.length === 0,
    logs: allLogs,
    outputs: ctx.outputs,
    result: ctx.result,
    executedNodeIds,
    failedNodeIds,
    durationMs: Date.now() - start,
  };
}

async function finalize(
  executionId: string,
  success: boolean,
  ctx: ExecutionContext,
  logs: ExecutionLog[],
  start: number
) {
  try {
    await db.workflowExecution.update({
      where: { id: executionId },
      data: {
        status: success ? 'success' : 'failed',
        endedAt: new Date(),
        result: JSON.stringify({
          ...ctx.result,
          duration_ms: Date.now() - start,
          success,
        }),
        logs: JSON.stringify(logs),
      },
    });
  } catch (e) {
    console.error('finalize error:', e);
  }
}
