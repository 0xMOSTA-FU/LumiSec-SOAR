// API key authentication middleware.
// Requests must include X-API-Key header matching EXTERNAL_API_KEY.
// Public endpoints (/api/info, /api/health) bypass auth.

const EXTERNAL_API_KEY = process.env.EXTERNAL_API_KEY || '';

const PUBLIC_PATHS = new Set(['/api/info', '/api/health']);

export function apiKeyAuth(req, res, next) {
  if (PUBLIC_PATHS.has(req.path)) return next();

  if (!EXTERNAL_API_KEY) {
    // No key configured = open mode (dev only). Warn but allow.
    console.warn('[auth] EXTERNAL_API_KEY not set — running in open mode (dev only!)');
    return next();
  }

  const provided = req.headers['x-api-key'];
  if (!provided || provided !== EXTERNAL_API_KEY) {
    return res.status(401).json({ error: 'Missing or invalid API key' });
  }

  next();
}
