// Threat Intel API — IOC lookup with cached verdicts.
// Provides a unified lookup endpoint that the main Next.js app can call
// to enrich IOCs. Caches verdicts in Mongo with a TTL.

import express from 'express';
import crypto from 'crypto';
import { getThreatIntelModel, useMongo, getMemoryStores } from '../models.js';
import { asyncHandler } from '../middleware/util.js';

const router = express.Router();

function detectIocType(ioc) {
  const v = String(ioc).trim();
  // IPv4
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(v) && v.split('.').every(n => Number(n) <= 255)) return 'ip';
  // IPv6 (simple check)
  if (/^[0-9a-f:]+$/i.test(v) && v.includes(':')) return 'ip';
  // SHA256 / SHA1 / MD5 hash
  if (/^[a-f0-9]{64}$/i.test(v)) return 'hash';
  if (/^[a-f0-9]{40}$/i.test(v)) return 'hash';
  if (/^[a-f0-9]{32}$/i.test(v)) return 'hash';
  // URL
  if (/^https?:\/\//i.test(v)) return 'url';
  // Email
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return 'email';
  // Default: domain
  return 'domain';
}

// Compute a deterministic verdict from the IOC itself (placeholder logic —
// replace with real TI feed integration in production).
// For known-malicious test IOCs returns 'malicious'; for known-benign returns 'clean';
// otherwise returns 'unknown' with low confidence.
function heuristicVerdict(ioc, iocType) {
  const v = String(ioc).trim().toLowerCase();
  // Known good
  const GOOD = ['8.8.8.8', '1.1.1.1', '8.8.4.4', '1.0.0.1', 'google.com', 'cloudflare.com', 'microsoft.com', 'github.com'];
  if (GOOD.includes(v)) return { verdict: 'clean', confidence: 95, source: 'builtin-good-list' };
  // Known bad
  const BAD = ['1.2.3.4', '6.6.6.6', '198.51.100.1', '203.0.113.5'];
  if (BAD.includes(v)) return { verdict: 'malicious', confidence: 88, source: 'builtin-bad-list' };
  // Sample EICAR test file
  if (v === '275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f') {
    return { verdict: 'malicious', confidence: 100, source: 'eicar-test' };
  }
  // Default
  return { verdict: 'unknown', confidence: 0, source: 'heuristic' };
}

// GET /api/threat-intel/lookup?ioc=8.8.8.8
router.get('/lookup', asyncHandler(async (req, res) => {
  const ioc = String(req.query.ioc || '').trim();
  if (!ioc) return res.status(400).json({ error: 'ioc query parameter is required' });

  const iocType = detectIocType(ioc);
  const checksum = crypto.createHash('sha256').update(`${iocType}:${ioc}`).digest('hex');

  if (useMongo() && getThreatIntelModel()) {
    // Try cache (within TTL)
    const cached = await getThreatIntelModel().findOne({ ioc, iocType }).lean();
    const now = Date.now();
    const ttlMs = (cached?.ttl || 86400) * 1000;
    if (cached && cached.lastSeenAt && (now - new Date(cached.lastSeenAt).getTime()) < ttlMs) {
      return res.json({
        ioc, iocType, ...cached, cached: true, checksum,
      });
    }

    // Compute fresh verdict
    const heuristic = heuristicVerdict(ioc, iocType);
    const fresh = await getThreatIntelModel().findOneAndUpdate(
      { ioc, iocType },
      {
        $set: {
          verdict: heuristic.verdict,
          confidence: heuristic.confidence,
          source: heuristic.source,
          lastSeenAt: new Date(),
        },
        $setOnInsert: {
          firstSeenAt: new Date(),
          ttl: 86400,
        },
      },
      { new: true, upsert: true }
    ).lean();

    return res.json({ ioc, iocType, ...fresh, cached: false, checksum });
  }

  // In-memory fallback
  const stores = getMemoryStores();
  let record = stores.threatIntel.find(t => t.ioc === ioc && t.iocType === iocType);
  if (!record) {
    const heuristic = heuristicVerdict(ioc, iocType);
    record = {
      _id: crypto.randomUUID(),
      ioc, iocType,
      verdict: heuristic.verdict,
      confidence: heuristic.confidence,
      source: heuristic.source,
      firstSeenAt: new Date().toISOString(),
      lastSeenAt: new Date().toISOString(),
      ttl: 86400,
    };
    stores.threatIntel.push(record);
  } else {
    record.lastSeenAt = new Date().toISOString();
  }
  res.json({ ioc, iocType, ...record, cached: false, checksum });
}));

// GET /api/threat-intel/recent — latest verdicts
router.get('/recent', asyncHandler(async (req, res) => {
  const limit = Math.min(100, Number(req.query.limit || 50));
  if (useMongo() && getThreatIntelModel()) {
    const items = await getThreatIntelModel().find().sort({ lastSeenAt: -1 }).limit(limit).lean();
    return res.json({ data: items, total: items.length });
  }
  const stores = getMemoryStores();
  const items = [...stores.threatIntel]
    .sort((a, b) => new Date(b.lastSeenAt).getTime() - new Date(a.lastSeenAt).getTime())
    .slice(0, limit);
  res.json({ data: items, total: items.length });
}));

export default router;
