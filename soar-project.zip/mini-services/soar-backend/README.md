# External SOAR Backend (Node.js + MongoDB)

This is the **secondary backend** for the SOAR platform. The main app is
Next.js (this repo's root). This service exposes extra REST endpoints that
the Next.js app calls via `src/lib/external-api.ts`.

## Why a separate backend?

The user explicitly asked for:
1. Backend logic in **Node.js** (not just Next.js API routes)
2. **MongoDB** for high-volume / schema-flexible data
3. A second backend that already exists (this is the placeholder for it)

The Next.js app remains the source of truth for relational state
(workflows, cases, integrations, RBAC). This Node.js service handles:

- **Incidents** — read/write incidents, mirror to MongoDB
- **Assets** — CMDB-style asset inventory
- **Threat Intel** — IOC lookup with cached verdicts
- **SOAR Events** — webhook receiver for events pushed from the main app
- **Health & Info** — discovery endpoint

## Quick start

```bash
cd mini-services/soar-backend
cp .env.example .env
npm install
npm start
# → SOAR backend listening on http://localhost:4000
```

Then in the main Next.js app's `.env`:

```
NEXT_PUBLIC_EXTERNAL_API_URL=http://localhost:4000
EXTERNAL_API_KEY=change-me-in-prod
```

Restart Next.js. The dashboard will now show "External backend:
Connected" in the settings page, and incidents / assets fetched from
this service will be merged into the UI.

## Endpoints

| Method | Path                       | Description                            |
|--------|----------------------------|----------------------------------------|
| GET    | /api/info                  | Backend name, version, endpoint list   |
| GET    | /api/health                | Liveness + MongoDB ping                |
| GET    | /api/incidents             | List incidents (latest first)          |
| GET    | /api/incidents/:id         | Get one incident                       |
| POST   | /api/incidents             | Create incident (called by Next.js)    |
| PUT    | /api/incidents/:id         | Update incident                        |
| GET    | /api/assets                | List assets                            |
| GET    | /api/assets/:id            | Get one asset                          |
| GET    | /api/threat-intel/lookup   | ?ioc=8.8.8.8 → verdict                 |
| POST   | /api/soar-events           | Ingest event from Next.js SOAR engine  |
| GET    | /api/soar-events           | List recent events                     |

All endpoints (except `/api/info` and `/api/health`) require the
`X-API-Key` header matching `EXTERNAL_API_KEY` on the Next.js side.

## Deployment

Run as a separate Docker container / process. See `docker-compose.yml`
at the repo root for an example service definition.

## License

Proprietary — internal use only.
